import sys, string

projects = ('avtexceptions', 'avtmath_ser', 'cli', 'comm', 'database_ser', 'dbatts', \
'engine', 'engineproxy', 'enginerpc', 'gui',  'guilib', 'mdserver', 'mdsproxy', \
'mdsrpc', 'misc', 'pipeline_ser', 'plotter', 'plugin', 'splashproxy', 'splashrpc', \
'splashscreen', 'state', 'utility', 'viewer', 'viewerlib', 'viewerproxy', 'viewerrpc', \
'viewerparser', 'visit_vtk', 'viswindow', 'vtkqt', 'winutil')

targetPentiumPro = 1

for arg in sys.argv[1:]:
    if(arg == "/G6"):
        targetPentiumPro = 1
    elif (arg == "/GB"):
        targetPentiumPro = 0

def FileReplaceString(file, oldstrings, newstring):
    f = open(file, "r")
    lines = f.readlines()
    f.close()

    altered = 0
    i = 0
    for line in lines:
        for oldstring in oldstrings:
            loc = string.find(line, oldstring)
            if(loc != -1):
                lines[i] = line[0:loc] + newstring + line[loc + len(oldstring):]
                altered = 1
        i = i + 1

    if(altered == 1):
        f = open(file, "w")
        for line in lines:
            f.write(line)
        f.close()

# Update the target for each project.
if targetPentiumPro == 1:
    print 'Target = Pentium Pro, Pentium II, Pentium III'
    replaceStrings = ('# ADD CPP /nologo /GB', '# ADD CPP /nologo')
    for p in projects:
        file = '..\\%s\\%s.dsp' % (p, p)
        FileReplaceString(file, replaceStrings, '# ADD CPP /nologo /G6')
else:
    print 'Target = Blend (Pentium and later)'
    replaceStrings = ('# ADD CPP /nologo /G6', '# ADD CPP /nologo')
    for p in projects:
        file = '..\\%s\%s.dsp' % (p, p)
        FileReplaceString(file, replaceStrings, '# ADD CPP /nologo /GB')
