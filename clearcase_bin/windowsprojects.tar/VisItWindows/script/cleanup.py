import os, sys

# Unix
Slash='/'
VisItWindows='/home/whitlocb/vtmp/VisItWindows'
RM='rm -f'

# Override values if we're on Windows
if(sys.platform == 'win32'):
    VisItWindows='C:\VisItWindows'
    Slash='\\'
    RM='del /F /Q'

dirs = ("VisIt", \
"avtexceptions", \
"avtmath_ser", \
"cli", \
"comm", \
"database_ser", \
"dbatts", \
"engine", \
"engineproxy", \
"enginerpc", \
"gui", \
"guilib", \
"mdserver", \
"mdsproxy", \
"mdsrpc", \
"misc", \
"pipeline_ser", \
"plotter", \
"plugin", \
"splashproxy", \
"splashrpc", \
"splashscreen", \
"state", \
"utility", \
"viewer", \
"viewerlib", \
"viewerparser", \
"viewerproxy", \
"viewerrpc", \
"visit", \
"visit_vtk", \
"viswindow", \
"vtkqt", \
"winutil")

visitdlls = ("pipeline_ser", \
"plotter", \
"avtexceptions", \
"plugin", \
"avtmath_ser", \
"comm", \
"database_ser", \
"splashproxy", \
"dbatts", \
"splashrpc", \
"state", \
"engineproxy", \
"utility", \
"enginerpc", \
"viewer", \
"vtkqt", \
"gui", \
"viewerparser", \
"viewerproxy", \
"mdsproxy", \
"mdsrpc", \
"viewerrpc", \
"visit_vtk", \
"misc", \
"viswindow")

def SYSTEM(command):
    #print command
	os.system(command)

# Clean up the bin directory.
print 'Cleaning up the bin directory...'
command = '%s %s%sbin%s*.exe' % (RM, VisItWindows, Slash, Slash)
SYSTEM(command)
command = '%s %s%sbin%s*.log' % (RM, VisItWindows, Slash, Slash)
SYSTEM(command)
command = '%s %s%sbin%splots%s*.dll' % (RM, VisItWindows, Slash, Slash, Slash)
SYSTEM(command)
command = '%s %s%sbin%soperators%s*.dll' % (RM, VisItWindows, Slash, Slash, Slash)
SYSTEM(command)
for dll in visitdlls:
    command = '%s %s%sbin%s%s.dll' % (RM, VisItWindows, Slash, Slash, dll)
    SYSTEM(command)


# Clean up the lib directory.
print 'Cleaning up the lib directory...'
command = '%s %s%slib%s*.lib' % (RM, VisItWindows, Slash, Slash)
SYSTEM(command)

# Clean up each project directory.
print 'Cleaning up the project directories'
for d in dirs:
    command = '%s %s%s%s%s*.plg' % (RM, VisItWindows, Slash, d, Slash)
    SYSTEM(command)
    command = '%s %s%s%s%sDebug%s*' % (RM, VisItWindows, Slash, d, Slash, Slash)
    SYSTEM(command)
    command = '%s %s%s%s%sRelease%s*' % (RM, VisItWindows, Slash, d, Slash, Slash)
    SYSTEM(command)
