import os, sys, string

Project = \
"# Microsoft Developer Studio Project File - Name=\"Pseudocolor\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Generic Project\" 0x010a\n"  \
"\n"  \
"CFG=Pseudocolor - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"Pseudocolor.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"Pseudocolor.mak\" CFG=\"Pseudocolor - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"Pseudocolor - Win32 Release\" (based on \"Win32 (x86) Generic Project\")\n"  \
"!MESSAGE \"Pseudocolor - Win32 Debug\" (based on \"Win32 (x86) Generic Project\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"MTL=midl.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"Pseudocolor - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Target_Dir \"\"\n"  \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"Pseudocolor - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Target_Dir \"\"\n"  \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"Pseudocolor - Win32 Release\"\n"  \
"# Name \"Pseudocolor - Win32 Debug\"\n"  \
"# End Target\n"  \
"# End Project\n"

IProject = \
"# Microsoft Developer Studio Project File - Name=\"PseudocolorI\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=PseudocolorI - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorI.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorI.mak\" CFG=\"PseudocolorI - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"PseudocolorI - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"PseudocolorI - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"PseudocolorI - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib plugin.lib /nologo /dll /machine:I386 /out:\"Release/libIPseudocolor.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libIPseudocolor.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"PseudocolorI - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib plugin.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libIPseudocolor.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libIPseudocolor.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"PseudocolorI - Win32 Release\"\n"  \
"# Name \"PseudocolorI - Win32 Debug\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorPluginInfo.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"

GProject = \
"# Microsoft Developer Studio Project File - Name=\"PseudocolorG\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=PseudocolorG - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorG.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorG.mak\" CFG=\"PseudocolorG - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"PseudocolorG - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"PseudocolorG - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"PseudocolorG - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"GUI_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib gui.lib viewerproxy.lib viewerrpc.lib qt-mt302.lib /nologo /dll /machine:I386 /out:\"Release/libGPseudocolor.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libGPseudocolor.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"PseudocolorG - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"GUI_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib gui.lib viewerproxy.lib viewerrpc.lib qt-mt302.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libGPseudocolor.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libGPseudocolor.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"PseudocolorG - Win32 Release\"\n"  \
"# Name \"PseudocolorG - Win32 Debug\"\n"  \
"# Begin Group \"moc\"\n"  \
"\n"  \
"# PROP Default_Filter \"\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\QvisPseudocolorPlotWindow_moc.C\n"  \
"# End Source File\n"  \
"# End Group\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorAttributes.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorCommonPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorGUIPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\QvisPseudocolorPlotWindow.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"


VProject = \
"# Microsoft Developer Studio Project File - Name=\"PseudocolorV\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=PseudocolorV - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorV.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorV.mak\" CFG=\"PseudocolorV - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"PseudocolorV - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"PseudocolorV - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"PseudocolorV - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"VIEWER_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib plotter.lib pipeline_ser.lib avtexceptions.lib /nologo /dll /machine:I386 /out:\"Release/libVPseudocolor.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libVPseudocolor.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"PseudocolorV - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"VIEWER_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib plotter.lib pipeline_ser.lib avtexceptions.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libVPseudocolor.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libVPseudocolor.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"PseudocolorV - Win32 Release\"\n"  \
"# Name \"PseudocolorV - Win32 Debug\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\avtPseudocolorPlot.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorAttributes.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorCommonPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorViewerPluginInfo.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"

EProject = \
"# Microsoft Developer Studio Project File - Name=\"PseudocolorE\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=PseudocolorE - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorE.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorE.mak\" CFG=\"PseudocolorE - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"PseudocolorE - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"PseudocolorE - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"PseudocolorE - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"ENGINE_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib plotter.lib pipeline_ser.lib avtexceptions.lib /nologo /dll /machine:I386 /out:\"Release/libEPseudocolor_ser.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libEPseudocolor_ser.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"PseudocolorE - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"ENGINE_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib plotter.lib pipeline_ser.lib avtexceptions.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libEPseudocolor_ser.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libEPseudocolor_ser.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"PseudocolorE - Win32 Release\"\n"  \
"# Name \"PseudocolorE - Win32 Debug\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\avtPseudocolorPlot.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorAttributes.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorCommonPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorEnginePluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorPluginInfo.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"


SProject = \
"# Microsoft Developer Studio Project File - Name=\"PseudocolorS\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=PseudocolorS - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorS.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"PseudocolorS.mak\" CFG=\"PseudocolorS - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"PseudocolorS - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"PseudocolorS - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"PseudocolorS - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"SCRIPTING_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib /nologo /dll /machine:I386 /out:\"Release/libSPseudocolor.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libSPseudocolor.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"PseudocolorS - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\plots\\Pseudocolor\" /D \"WIN32\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"SCRIPTING_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /U \"_DEBUG\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libSPseudocolor.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libSPseudocolor.dll ..\\..\\..\\VisItWindows\\bin\\plots\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"PseudocolorS - Win32 Release\"\n"  \
"# Name \"PseudocolorS - Win32 Debug\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorAttributes.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorCommonPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PseudocolorScriptingPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\plots\\Pseudocolor\\PyPseudocolorAttributes.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"


#
# Now get the command line for the name of the plugin project files to create.
#
if(len(sys.argv) < 2):
    print "Usage: projectmaker pluginname\n"
    sys.exit(0)

pluginName = sys.argv[1]

#
# Create the top level directory and go into it.
#
topdir = os.curdir +  os.sep + pluginName
os.mkdir(topdir)
os.chdir(topdir)
s = string.replace(Project, "Pseudocolor", pluginName)
pname = '%s.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()

#
# Create the I project
#
d = '%sI' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(IProject, "Pseudocolor", pluginName)
pname = '%sI.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)

#
# Create the G project
#
d = '%sG' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(GProject, "Pseudocolor", pluginName)
pname = '%sG.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)

#
# Create the V project
#
d = '%sV' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(VProject, "Pseudocolor", pluginName)
pname = '%sV.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)

#
# Create the E project
#
d = '%sE' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(EProject, "Pseudocolor", pluginName)
pname = '%sE.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)

#
# Create the S project
#
d = '%sS' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(SProject, "Pseudocolor", pluginName)
pname = '%sS.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)