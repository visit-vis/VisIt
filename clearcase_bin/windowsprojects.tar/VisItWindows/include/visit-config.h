#ifndef VISIT_CONFIG_H
#define VISIT_CONFIG_H
/* include/visit-config.h.  Custom generated for Intel 686 running MS Windows 2000
 */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
/*#define TIME_WITH_SYS_TIME 1*/

/* Define SPLASHSCREEN if the splash screen is enabled */
#define SPLASHSCREEN 1

/* Define USE_PTY if we want to use PTYs */
/*#define USE_PTY 1*/

/* Define for the VERSION number of the package. */
#define VERSION "1.0"

/* The number of bytes in a boolean.  */
#define SIZEOF_BOOLEAN 0

/* The number of bytes in a char.  */
#define SIZEOF_CHAR 1

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

/* The number of bytes in a long long.  */
#define SIZEOF_LONG_LONG 8

/* The number of bytes in a unsigned char.  */
#define SIZEOF_UNSIGNED_CHAR 1

/* The number of bytes in a unsigned short.  */
#define SIZEOF_UNSIGNED_SHORT 2

/* The number of bytes in a unsigned int.  */
#define SIZEOF_UNSIGNED_INT 4

/* The number of bytes in a unsigned long.  */
#define SIZEOF_UNSIGNED_LONG 4

/* The number of bytes in a unsigned long long.  */
#define SIZEOF_UNSIGNED_LONG_LONG 8

/* The number of bytes in a float.  */
#define SIZEOF_FLOAT 4

/* The number of bytes in a long float.  */
#define SIZEOF_LONG_FLOAT 0

/* The number of bytes in a double.  */
#define SIZEOF_DOUBLE 8

/* The number of bytes in a long double.  */
#define SIZEOF_LONG_DOUBLE 12

/* The number of bytes in a void *.  */
#define SIZEOF_VOID_P 4

/* The number of bytes in a boolean.  */
/*#define SIZEOF_BOOLEAN 1*/

/* Define if you have the div function.  */
/*#define HAVE_DIV 1*/

/* Define if you have the memmove function.  */
/*#define HAVE_MEMMOVE 1*/

/* Define if you have the select function.  */
#define HAVE_SELECT 1

/* Define if you have the strerror function.  */
/*#define HAVE_STRERROR 1*/

/* Define if you have the <fcntl.h> header file.  */
/*#define HAVE_FCNTL_H 1*/

/* Define if you have the <limits.h> header file.  */
/*#define HAVE_LIMITS_H 1*/

/* Define if you have the <sys/time.h> header file.  */
/*#define HAVE_SYS_TIME_H 1*/

/* Define if you have the <sys/types.h> header file.  */
/*#define HAVE_SYS_TYPES_H 1*/

/* Define if you have the <unistd.h> header file.  */
/*#define HAVE_UNISTD_H 1*/

/* Define if you have the prototype for ftime in the <sys/timeb.h>.  */
/*#define HAVE_FTIME_PROTOTYPE 1*/

/* Define if socklen_t is defined */
/*#define HAVE_SOCKLEN_T 1*/

/* Define the extension for plugins */
#define PLUGIN_EXTENSION ".dll" 

/* Define the backslash used in filenames. (char version) */
#define SLASH_CHAR '\\'

/* Define the backslash used in filenames. (string version) */
#define SLASH_STRING "\\"

/* Define if you have the <zlib.h> header file.  */
/*#define HAVE_ZLIB_H 1*/

/* Define if you have the z library (-lz).  */
/*#define HAVE_LIBZ 1*/

#endif

/* end of file */
