import os, sys

# Unix
Slash='/'
VisItWindows='/home/whitlocb/vtmp/VisItPlotPlugins'
RM='rm -f'

# Override values if we're on Windows
if(sys.platform == 'win32'):
    VisItWindows='C:\VisItPlotPlugins'
    Slash='\\'
    RM='del /F /Q'

dirs = ("Contour", "Curve", "FastVolume", "Mesh", "Pseudocolor", "Subset", "Surface", "Vector")

def SYSTEM(command):
    #print command
	os.system(command)

# Delete certain files at the top level
command = '%s %s%s*.ncb %s%s*.opt' % (RM, VisItWindows, Slash, VisItWindows, Slash)
SYSTEM(command)

# Clean up each plugin directory.
print 'Cleaning up the plugin directories'
for d in dirs:
    command = '%s %s%s%s%s*.plg' % (RM, VisItWindows, Slash, d, Slash)
    SYSTEM(command)
    for p in ('E', 'G', 'I', 'S', 'V'):
        command = '%s %s%s%s%s%s%s%sDebug%s*' % (RM, VisItWindows, Slash, d, Slash, d, p, Slash, Slash)
        SYSTEM(command)
        command = '%s %s%s%s%s%s%s%sRelease%s*' % (RM, VisItWindows, Slash, d, Slash, d, p, Slash, Slash)
        SYSTEM(command)
