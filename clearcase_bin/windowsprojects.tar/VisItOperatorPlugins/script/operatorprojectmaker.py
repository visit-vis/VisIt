import os, sys, string

Project = \
"# Microsoft Developer Studio Project File - Name=\"Aslice\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Generic Project\" 0x010a\n"  \
"\n"  \
"CFG=Aslice - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"Aslice.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"Aslice.mak\" CFG=\"Aslice - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"Aslice - Win32 Release\" (based on \"Win32 (x86) Generic Project\")\n"  \
"!MESSAGE \"Aslice - Win32 Debug\" (based on \"Win32 (x86) Generic Project\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"MTL=midl.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"Aslice - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Target_Dir \"\"\n"  \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"Aslice - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Target_Dir \"\"\n"  \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"Aslice - Win32 Release\"\n"  \
"# Name \"Aslice - Win32 Debug\"\n"  \
"# End Target\n"  \
"# End Project\n"

IProject = \
"# Microsoft Developer Studio Project File - Name=\"AsliceI\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=AsliceI - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceI.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceI.mak\" CFG=\"AsliceI - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"AsliceI - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"AsliceI - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"AsliceI - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib plugin.lib /nologo /dll /machine:I386 /out:\"Release/libIAslice.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libIAslice.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"AsliceI - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib plugin.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libIAslice.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libIAslice.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"AsliceI - Win32 Release\"\n"  \
"# Name \"AsliceI - Win32 Debug\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AslicePluginInfo.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"

GProject = \
"# Microsoft Developer Studio Project File - Name=\"AsliceG\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=AsliceG - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceG.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceG.mak\" CFG=\"AsliceG - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"AsliceG - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"AsliceG - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"AsliceG - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"GUI_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib gui.lib viewerproxy.lib viewerrpc.lib qt-mt302.lib /nologo /dll /machine:I386 /out:\"Release/libGAslice.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libGAslice.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"AsliceG - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"GUI_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib gui.lib viewerproxy.lib viewerrpc.lib qt-mt302.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libGAslice.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libGAslice.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"AsliceG - Win32 Release\"\n"  \
"# Name \"AsliceG - Win32 Debug\"\n"  \
"# Begin Group \"moc\"\n"  \
"\n"  \
"# PROP Default_Filter \"\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\QvisAsliceWindow_moc.C\n"  \
"# End Source File\n"  \
"# End Group\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceAttributes.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceCommonPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceGUIPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AslicePluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\QvisAsliceWindow.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"


VProject = \
"# Microsoft Developer Studio Project File - Name=\"AsliceV\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=AsliceV - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceV.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceV.mak\" CFG=\"AsliceV - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"AsliceV - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"AsliceV - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"AsliceV - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"VIEWER_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib plotter.lib pipeline_ser.lib avtexceptions.lib dbatts.lib vtkCommon.lib vtkGraphics.lib vtkFiltering.lib /nologo /dll /machine:I386 /out:\"Release/libVAslice.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libVAslice.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"AsliceV - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"VIEWER_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib plotter.lib pipeline_ser.lib avtexceptions.lib dbatts.lib vtkCommon.lib vtkGraphics.lib vtkFiltering.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libVAslice.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libVAslice.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"AsliceV - Win32 Release\"\n"  \
"# Name \"AsliceV - Win32 Debug\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\avtAsliceFilter.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceAttributes.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceCommonPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AslicePluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceViewerPluginInfo.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"

EProject = \
"# Microsoft Developer Studio Project File - Name=\"AsliceE\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=AsliceE - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceE.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceE.mak\" CFG=\"AsliceE - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"AsliceE - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"AsliceE - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"AsliceE - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"ENGINE_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib plotter.lib pipeline_ser.lib avtexceptions.lib vtkCommon.lib vtkGraphics.lib vtkFiltering.lib /nologo /dll /machine:I386 /out:\"Release/libEAslice_ser.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libEAslice_ser.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"AsliceE - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"ENGINE_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib plotter.lib pipeline_ser.lib avtexceptions.lib vtkCommon.lib vtkGraphics.lib vtkFiltering.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libEAslice_ser.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libEAslice_ser.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"AsliceE - Win32 Release\"\n"  \
"# Name \"AsliceE - Win32 Debug\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\avtAsliceFilter.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceAttributes.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceCommonPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceEnginePluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AslicePluginInfo.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"


SProject = \
"# Microsoft Developer Studio Project File - Name=\"AsliceS\" - Package Owner=<4>\n"  \
"# Microsoft Developer Studio Generated Build File, Format Version 6.00\n"  \
"# ** DO NOT EDIT **\n"  \
"\n"  \
"# TARGTYPE \"Win32 (x86) Dynamic-Link Library\" 0x0102\n"  \
"\n"  \
"CFG=AsliceS - Win32 Debug\n"  \
"!MESSAGE This is not a valid makefile. To build this project using NMAKE,\n"  \
"!MESSAGE use the Export Makefile command and run\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceS.mak\".\n"  \
"!MESSAGE \n"  \
"!MESSAGE You can specify a configuration when running NMAKE\n"  \
"!MESSAGE by defining the macro CFG on the command line. For example:\n"  \
"!MESSAGE \n"  \
"!MESSAGE NMAKE /f \"AsliceS.mak\" CFG=\"AsliceS - Win32 Debug\"\n"  \
"!MESSAGE \n"  \
"!MESSAGE Possible choices for configuration are:\n"  \
"!MESSAGE \n"  \
"!MESSAGE \"AsliceS - Win32 Release\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \"AsliceS - Win32 Debug\" (based on \"Win32 (x86) Dynamic-Link Library\")\n"  \
"!MESSAGE \n"  \
"\n"  \
"# Begin Project\n"  \
"# PROP AllowPerConfigDependencies 0\n"  \
"# PROP Scc_ProjName \"\"\n"  \
"# PROP Scc_LocalPath \"\"\n"  \
"CPP=cl.exe\n"  \
"MTL=midl.exe\n"  \
"RSC=rc.exe\n"  \
"\n"  \
"!IF  \"$(CFG)\" == \"AsliceS - Win32 Release\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 0\n"  \
"# PROP BASE Output_Dir \"Release\"\n"  \
"# PROP BASE Intermediate_Dir \"Release\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 0\n"  \
"# PROP Output_Dir \"Release\"\n"  \
"# PROP Intermediate_Dir \"Release\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /c\n"  \
"# ADD CPP /nologo /MD /W3 /GX /O2 /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"NDEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"SCRIPTING_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /YX /FD /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"NDEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"NDEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"NDEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /machine:I386\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib /nologo /dll /machine:I386 /out:\"Release/libSAslice.dll\"\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Release\\libSAslice.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ELSEIF  \"$(CFG)\" == \"AsliceS - Win32 Debug\"\n"  \
"\n"  \
"# PROP BASE Use_MFC 0\n"  \
"# PROP BASE Use_Debug_Libraries 1\n"  \
"# PROP BASE Output_Dir \"Debug\"\n"  \
"# PROP BASE Intermediate_Dir \"Debug\"\n"  \
"# PROP BASE Target_Dir \"\"\n"  \
"# PROP Use_MFC 0\n"  \
"# PROP Use_Debug_Libraries 1\n"  \
"# PROP Output_Dir \"Debug\"\n"  \
"# PROP Intermediate_Dir \"Debug\"\n"  \
"# PROP Ignore_Export_Lib 0\n"  \
"# PROP Target_Dir \"\"\n"  \
"# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D \"WIN32\" /D \"_DEBUG\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /YX /FD /GZ /c\n"  \
"# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I \"..\\..\\..\\visit\\operators\\Aslice\" /D \"WIN32\" /D \"_WINDOWS\" /D \"_MBCS\" /D \"_USRDLL\" /D \"USING_MSVC6\" /D \"SCRIPTING_PLUGIN_EXPORTS\" /D \"GENERAL_PLUGIN_EXPORTS\" /U \"_DEBUG\" /YX /FD /GZ /TP /c\n"  \
"# ADD BASE MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD MTL /nologo /D \"_DEBUG\" /mktyplib203 /win32\n"  \
"# ADD BASE RSC /l 0x409 /d \"_DEBUG\"\n"  \
"# ADD RSC /l 0x409 /d \"_DEBUG\"\n"  \
"BSC32=bscmake.exe\n"  \
"# ADD BASE BSC32 /nologo\n"  \
"# ADD BSC32 /nologo\n"  \
"LINK32=link.exe\n"  \
"# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /debug /machine:I386 /pdbtype:sept\n"  \
"# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib state.lib misc.lib plugin.lib /nologo /dll /debug /machine:I386 /out:\"Debug/libSAslice.dll\" /pdbtype:sept\n"  \
"# Begin Special Build Tool\n" \
"SOURCE=\"$(InputPath)\"\n" \
"PostBuild_Cmds=copy Debug\\libSAslice.dll ..\\..\\..\\VisItWindows\\bin\\operators\n" \
"# End Special Build Tool\n" \
"\n"  \
"!ENDIF \n"  \
"\n"  \
"# Begin Target\n"  \
"\n"  \
"# Name \"AsliceS - Win32 Release\"\n"  \
"# Name \"AsliceS - Win32 Debug\"\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceAttributes.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceCommonPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AslicePluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\AsliceScriptingPluginInfo.C\n"  \
"# End Source File\n"  \
"# Begin Source File\n"  \
"\n"  \
"SOURCE=..\\..\\..\\visit\\operators\\Aslice\\PyAsliceAttributes.C\n"  \
"# End Source File\n"  \
"# End Target\n"  \
"# End Project\n"


#
# Now get the command line for the name of the plugin project files to create.
#
if(len(sys.argv) < 2):
    print "Usage: projectmaker pluginname\n"
    sys.exit(0)

pluginName = sys.argv[1]

#
# Create the top level directory and go into it.
#
topdir = os.curdir +  os.sep + pluginName
os.mkdir(topdir)
os.chdir(topdir)
s = string.replace(Project, "Aslice", pluginName)
pname = '%s.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()

#
# Create the I project
#
d = '%sI' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(IProject, "Aslice", pluginName)
pname = '%sI.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)

#
# Create the G project
#
d = '%sG' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(GProject, "Aslice", pluginName)
pname = '%sG.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)

#
# Create the V project
#
d = '%sV' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(VProject, "Aslice", pluginName)
pname = '%sV.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)

#
# Create the E project
#
d = '%sE' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(EProject, "Aslice", pluginName)
pname = '%sE.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)

#
# Create the S project
#
d = '%sS' % pluginName
os.mkdir(d)
os.chdir(d)
os.mkdir("Debug")
os.mkdir("Release")
s = string.replace(SProject, "Aslice", pluginName)
pname = '%sS.dsp' % pluginName
f = open(pname, 'w')
f.write(s)
f.close()
os.chdir(os.pardir)