import os, sys

# Unix
Slash='/'
VisItWindows='/home/whitlocb/vtmp/VisItOperatorPlugins'
RM='rm -f'

# Override values if we're on Windows
if(sys.platform == 'win32'):
    VisItWindows='C:\VisItOperatorPlugins'
    Slash='\\'
    RM='del /F /Q'

dirs = ('Aslice', 'Box', 'Cone', 'Context', 'Displace', 'Erase', 'IndexSelect',\
'InverseGhostZone', 'IsoSurface', 'Lineout', 'OnionPeel', 'Reflect', 'SiloDump',\
'SphereSlice', 'Threshold', 'Transform')

def SYSTEM(command):
    #print command
	os.system(command)

# Clean up each plugin directory.
print 'Cleaning up the plugin directories'
for d in dirs:
    command = '%s %s%s%s%s*.plg' % (RM, VisItWindows, Slash, d, Slash)
    SYSTEM(command)
    for p in ('E', 'G', 'I', 'S', 'V'):
        command = '%s %s%s%s%s%s%s%sDebug%s*' % (RM, VisItWindows, Slash, d, Slash, d, p, Slash, Slash)
        SYSTEM(command)
        command = '%s %s%s%s%s%s%s%sRelease%s*' % (RM, VisItWindows, Slash, d, Slash, d, p, Slash, Slash)
        SYSTEM(command)
