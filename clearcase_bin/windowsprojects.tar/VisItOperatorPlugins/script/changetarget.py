import sys, string

projects = ('Aslice', 'Box', 'Cone', 'Context', 'Displace', 'Erase', \
'IndexSelect', 'InverseGhostZone', 'IsoSurface', 'Lineout', 'OnionPeel', \
'Reflect', 'SiloDump', 'SphereSlice', 'Threshold', 'Transform')

targetPentiumPro = 1

if(len(sys.argv) <= 1):
    print "Usage: changetarget.py [/Gb | /G6]"
    print ""
    print "This script changes the machine target for all of the operator"
    print "plugin project files. If /Gb is supplied, a blend of machine code"
    print "used and the resulting binaries can run on any machine Pentium and"
    print "later. The /G6 option produces binaries that are optimized for the"
    print "Pentium Pro/II/III. These binaries are larger but a little faster."
    print ""
    sys.exit(0)

for arg in sys.argv[1:]:
    if(arg == "/G6"):
        targetPentiumPro = 1
    elif (arg == "/GB"):
        targetPentiumPro = 0

def FileReplaceString(file, oldstrings, newstring):
    f = open(file, "r")
    lines = f.readlines()
    f.close()

    altered = 0
    i = 0
    for line in lines:
        for oldstring in oldstrings:
            loc = string.find(line, oldstring)
            if(loc != -1):
                lines[i] = line[0:loc] + newstring + line[loc + len(oldstring):]
                altered = 1
        i = i + 1

    if(altered == 1):
        f = open(file, "w")
        for line in lines:
            f.write(line)
        f.close()

# Update the target for each project.
if targetPentiumPro == 1:
    print 'Target = Pentium Pro, Pentium II, Pentium III'
    replaceStrings = ('# ADD CPP /nologo /GB', '# ADD CPP /nologo')
    for p in projects:
        for plugin in ('I', 'E', 'G', 'V', 'S'):
            file = '..\\%s\\%s%s\\%s%s.dsp' % (p, p, plugin, p, plugin)
            FileReplaceString(file, replaceStrings, '# ADD CPP /nologo /G6')
else:
    print 'Target = Blend (Pentium and later)'
    replaceStrings = ('# ADD CPP /nologo /G6', '# ADD CPP /nologo')
    for p in projects:
        for plugin in ('I', 'E', 'G', 'V', 'S'):
            file = '..\\%s\\%s%s\\%s%s.dsp' % (p, p, plugin, p, plugin)
            FileReplaceString(file, replaceStrings, '# ADD CPP /nologo /GB')
