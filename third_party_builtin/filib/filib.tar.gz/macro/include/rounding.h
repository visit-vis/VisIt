#ifndef _FILIB_ROUNDING_H
#define _FILIB_ROUNDING_H

#include "config.h"

#if defined(FILIB_NATIVE_ROUNDING)

 #if defined(__i386__) || defined(__sparc__) || defined(__x86_64__)

   // 387 control word for directed roundings; no interrupts and double
   // precision rounding 
   #define CW_ROUND_NEAR 0x027F
   #define CW_ROUND_DOWN 0x067F
   #define CW_ROUND_UP   0x0A7F

   

   #if defined (__GNUC__)

    #if defined (FILIB_MULT_ROUNDING)
    #define ROUND_DOWN
    #define ROUND_UP
    #define ROUND_NEAR

#ifndef FILIB_NAMESPACES
    static const double ZERO_SUCC=Double::succ(0.0);
    static const double ZERO_PRED=Double::pred(0.0);
     
    static const double ONE_SUCC=Double::succ(1.0);
    static const double ONE_PRED=Double::pred(1.0);
#else
    static const double ZERO_SUCC=filib::Double::succ(0.0);
    static const double ZERO_PRED=filib::Double::pred(0.0);
     
    static const double ONE_SUCC=filib::Double::succ(1.0);
    static const double ONE_PRED=filib::Double::pred(1.0);
#endif
    
#define low(a) ((a)>0)?((a)*ONE_PRED):((a)=0?ZERO_PRED:(a)*ONE_SUCC)
#define high(a) ((a)>0)?((a)*ONE_SUCC):((a)=0?ZERO_SUCC:(a)*ONE_PRED)                                 

#define MUL_DOWN_UPD(x, y) { \
   x *= y; x=low(x);\
}

#define MUL_UP_UPD(x, y) { \
   x *= y; x=high(x);\
}

#define MUL_DOWN(z, x, y) { \
   z = x * y; z=low(z);\
}

#define MUL_UP(z, x, y) { \
   z = x * y; z=high(z);\
}                                                                                                     

#define DIV_DOWN_UPD(x, y) { \
   x /= y; x=low(x);\
}

#define DIV_UP_UPD(x, y) { \
   x /= y; x=high(x);\
}                                                                                                     

#define DIV_DOWN(z, x, y) { \
   z = x / y; z=low(z);\
}

#define DIV_UP(z, x, y) { \
   z = x / y; z=high(z);\
}                                                                                                        

#define ADD_DOWN_UPD(x, y) { \
   x += y; x=low(x);\
}

#define ADD_UP_UPD(x, y) { \
   x += y; x=high(x);\
}

#define SUB_DOWN_UPD(x, y) { \
   x -= y; x=low(x);\
}

#define SUB_UP_UPD(x, y) { \
   x -= y; x=high(x);\
}                                                                                                    

#define ADD_DOWN(z, x, y) { \
   z = x + y; z=low(z);\
}

#define ADD_UP(z, x, y) { \
   z = x + y; z=high(z);\
}

#define SUB_DOWN(z, x, y) { \
   z = x - y; z=low(z);\
}

#define SUB_UP(z, x, y) { \
   z = x - y; z=high(z);\
}

    #else
     #if defined (FILIB_NO_ROUNDING)
     // empty Macros for switching rounding mode 
     #define ROUND_DOWN\
     

     #define ROUND_UP\
    

     #define ROUND_NEAR\
    

     #else


// Macros for switching rounding mode 
     #define ROUND_DOWN\
     asm("fldcw %0" : : "m" (CW_ROUND_DOWN))

     #define ROUND_UP\
     asm("fldcw %0" : : "m" (CW_ROUND_UP))

     #define ROUND_NEAR\
     asm("fldcw %0" : : "m" (CW_ROUND_NEAR))

   #endif  // FILIB_NO_ROUNDING 
 
#if defined (FILIB_ONESIDED)

// Macros for updating arithmetic operations with directed roundings
     // x op= y
     #define ADD_DOWN_UPD(x, y) { \
     ROUND_DOWN;  x += y; \
     }

     #define ADD_UP_UPD(x, y) { \
        x  =-( -x + - y); \
     }

     #define SUB_DOWN_UPD(x, y) { \
     ROUND_DOWN;  x -= y; \
     }

     #define SUB_UP_UPD(x, y) { \
        x =  -( -x - - y); \
     }

     #define MUL_DOWN_UPD(x, y) { \
      ROUND_DOWN; x *= y; \
     }

     #define MUL_UP_UPD(x, y) { \
       x = -(-x* y); \
     }

     #define DIV_DOWN_UPD(x, y) { \
      ROUND_DOWN;  x /= y; \
     }

     #define DIV_UP_UPD(x, y) { \
        x = -(-x/ y); \
     }

     // Macros for arithmetic operations with directed roundings
     // z = x op y  
     #define ADD_DOWN(z, x, y) { \
      ROUND_DOWN;  z = x + y; \
     } 

     #define ADD_UP(z, x, y) { \
        z =- (- x + -y); \
     } 

     #define SUB_DOWN(z, x, y) { \
     ROUND_DOWN;   z = x - y; \
     } 

     #define SUB_UP(z, x, y) { \
        z = -(-x - - y); \
     } 

     #define MUL_DOWN(z, x, y) { \
     ROUND_DOWN;   z = x * y; \
     } 

     #define MUL_UP(z, x, y) { \
        z = - (-x * y); \
     } 

     #define DIV_DOWN(z, x, y) { \
      ROUND_DOWN;  z = x / y; \
     } 

     #define DIV_UP(z, x, y) { \
       z = -(-x / y); \
     }   
#else //FILIB_ONESIDED

 // Macros for updating arithmetic operations with directed roundings
     // x op= y
     #define ADD_DOWN_UPD(x, y) { \
       ROUND_DOWN; x += y; \
     }

     #define ADD_UP_UPD(x, y) { \
       ROUND_UP; x += y; \
     }

     #define SUB_DOWN_UPD(x, y) { \
       ROUND_DOWN; x -= y; \
     }

     #define SUB_UP_UPD(x, y) { \
       ROUND_UP; x -= y; \
     }

     #define MUL_DOWN_UPD(x, y) { \
       ROUND_DOWN; x *= y; \
     }

     #define MUL_UP_UPD(x, y) { \
       ROUND_UP; x *= y; \
     }

     #define DIV_DOWN_UPD(x, y) { \
       ROUND_DOWN; x /= y; \
     }

     #define DIV_UP_UPD(x, y) { \
       ROUND_UP; x /= y; \
     }

     // Macros for arithmetic operations with directed roundings
     // z = x op y  
     #define ADD_DOWN(z, x, y) { \
       ROUND_DOWN; z = x + y; \
     } 

     #define ADD_UP(z, x, y) { \
       ROUND_UP; z = x + y; \
     } 

     #define SUB_DOWN(z, x, y) { \
       ROUND_DOWN; z = x - y; \
     } 

     #define SUB_UP(z, x, y) { \
       ROUND_UP; z = x - y; \
     } 

     #define MUL_DOWN(z, x, y) { \
       ROUND_DOWN; z = x * y; \
     } 

     #define MUL_UP(z, x, y) { \
       ROUND_UP; z = x * y; \
     } 

     #define DIV_DOWN(z, x, y) { \
       ROUND_DOWN; z = x / y; \
     } 

     #define DIV_UP(z, x, y) { \
       ROUND_UP; z = x / y; \
     }   



#endif //ONE
  #endif  //MULT
   #elif defined (__KCC)

     extern "C" void * __kai_apply(const char *,...);

     // Macros for switching rounding mode 
     #define ROUND_NEAR\
     __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_NEAR);
     #define ROUND_UP\
     __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP);
     #define ROUND_DOWN\
     __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN);


     // Macros for updating arithmetic operations with directed roundings
     // x op= y
     #define ADD_DOWN_UPD(x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN); \
       __kai_apply("(%a) += (%e);", &(x), (y)); \
     }

     #define ADD_UP_UPD(x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP); \
       __kai_apply("(%a) += (%e);", &(x), (y)); \
     }

     #define SUB_DOWN_UPD(x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN); \
       __kai_apply("(%a) -= (%e);", &(x), (y)); \
     }

     #define SUB_UP_UPD(x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP); \
       __kai_apply("(%a) -= (%e);", &(x), (y)); \
     }

     #define MUL_DOWN_UPD(x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN); \
       __kai_apply("(%a) *= (%e);", &(x), (y)); \
     }

     #define MUL_UP_UPD(x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP); \
       __kai_apply("(%a) *= (%e);", &(x), (y)); \
     }

     #define DIV_DOWN_UPD(x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN); \
       __kai_apply("(%a) /= (%e);", &(x), (y)); \
     }

     #define DIV_UP_UPD(x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP); \
       __kai_apply("(%a) /= (%e);", &(x), (y)); \
     }


     // Macros for arithmetic operations with directed roundings
     // z = x op y 
     #define ADD_DOWN(z, x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN); \
       __kai_apply("(%a) = (%e) + (%e);", &(z), (x), (y)); \
     }

     #define ADD_UP(z, x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP); \
       __kai_apply("(%a) = (%e) + (%e);", &(z), (x), (y)); \
     }

     #define SUB_DOWN(z, x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN); \
       __kai_apply("(%a) = (%e) - (%e);", &(z), (x), (y)); \
     }

     #define SUB_UP(z, x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP); \
       __kai_apply("(%a) = (%e) - (%e);", &(z), (x), (y)); \
     }

     #define MUL_DOWN(z, x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN); \
       __kai_apply("(%a) = (%e) * (%e);", &(z), (x), (y)); \
     }

     #define MUL_UP(z, x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP); \
       __kai_apply("(%a) = (%e) * (%e);", &(z), (x), (y)); \
     }

     #define DIV_DOWN(z, x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_DOWN); \
       __kai_apply("(%a) = (%e) / (%e);", &(z), (x), (y)); \
     }

     #define DIV_UP(z, x, y) { \
       __kai_apply("__asm__(\"fldcw %%0\" : : \"m\" (%e));", CW_ROUND_UP); \
       __kai_apply("(%a) = (%e) / (%e);", &(z), (x), (y)); \
     }

   #else 
   
     #error Compiler not supported for directed rounding !

   #endif 

 #else 

  #error Architecture not supported for directed rounding !

 #endif // __i386__ || __sparc__


 #ifdef FILIB_ENSURE_ROUND_NEAR
   #define POSS_ROUND_NEAR ROUND_NEAR
 #else
   #define POSS_ROUND_NEAR 
 #endif

#endif // FILIB_NATIVE_ROUNDING


#endif
