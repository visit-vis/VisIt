/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval acot(Interval x)
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty()) 
    return Interval::EMPTY();
#endif

  Interval res;
  if (x.isPoint())
    { 
          res.INF=q_acot(x.INF);
          res.SUP=res.INF*q_cctp;
          res.INF*=q_cctm;
    }
  else
    {
      res.INF=q_acot(x.SUP)*q_cctm;
      res.SUP=q_acot(x.INF)*q_cctp;
    }   
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif




