#include <config.h>

#ifdef FILIB_STD_HEADERS
  #include <iostream>
  #include <iomanip>
  #include <sstream>
#else
  #include <iostream.h>
  #include <iomanip.h>
  #include <strstream>
#endif

using namespace std;

#include "Interval.h"
#include "ieee.h"
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

// -----------------------------------------------------------------------
// Instantiation of static members
// -----------------------------------------------------------------------

#ifdef FILIB_EXTENDED
Interval Interval::empty(Double::computeQNaN(), 
			 Double::computeQNaN(), true);
Interval Interval::entire(Double::computeNegInf(), 
			  Double::computePosInf(), true);
Interval Interval::ninf(Double::computeNegInf(), 
			-Double::computeMax(), true);
Interval Interval::pinf(Double::computeMax(), 
			Double::computePosInf(), true); 
#endif
Interval Interval::zero(0.0, 0.0, true);
Interval Interval::one(1.0, 1.0, true);
Interval Interval::pi(q_pi, Double::basic_succ(q_pi), true);

int Interval::dec = 3;


// -----------------------------------------------------------------------
// I/O
// -----------------------------------------------------------------------

int Interval::precision(int decimals) 
{
  int oldval = dec;
  dec = decimals;
  return oldval;
}

int Interval::precision()
{
  return dec;
}


#ifdef FILIB_USE_LIBI77_IO
// I/O from libI77
// (see http://www.eecs.lehigh.edu/~mschulte/compiler)
typedef struct { double inf, sup; } interval;

extern "C" {
  void wrt_VE_int(char *, interval, int, int, int); 
  interval v_read_fmtv(char *);
}


char my_buf[1024];    

ostream &operator <<(ostream &os, INTV_ARG x) 
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty())
    os << "[ EMPTY ]";
  else if (x == Interval::NEG_INFTY())
    os << "[ -INF ]";
  else if (x == Interval::POS_INFTY())
    os << "[ +INF ]";
  else if (x == Interval::ENTIRE())
    os << "[ ENTIRE ]";
  else
#else
  if (!(Double::isRegular(x.INF) && Double::isRegular(x.SUP)) || 
      x.INF > x.SUP)
    os << "[ UNDEFINED ]";
  else
#endif
  {
    interval xx;
    xx.inf = x.inf();
    xx.sup = x.sup();
    
    int bufLen = 2*Interval::dec+20;
    //static char my_buf[1024];    
    
    wrt_VE_int(my_buf, xx, bufLen, Interval::dec, 0);
    os << my_buf;
    //delete [] buf;
  }
  
  return os;
}


istream &operator >>(istream &is, Interval &x)
{
  // read character string from is
  char ch;  
  strstream s;
  do {
    cin.get(ch);
    s << ch;
  } while (ch != '\n');
  char *buffer = s.str();
  
  // parse Interval
  interval xx = v_read_fmtv(buffer);
  x = Interval(xx.inf, xx.sup);
  
  return is;
}

#else

ostream &operator <<(ostream &os, INTV_ARG x) 
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty())
    os << "[ EMPTY ]";
  else if (x == Interval::NEG_INFTY())
    os << "[ -INF ]";
  else if (x == Interval::POS_INFTY())
    os << "[ +INF ]";
  else if (x == Interval::ENTIRE())
    os << "[ ENTIRE ]";
  else
#else
  if (!(Double::isRegular(x.INF) && Double::isRegular(x.SUP)) || 
      x.INF > x.SUP)
    os << "[ UNDEFINED ]";
  else
#endif
  {
    int old_dec = os.precision();
    os.precision(Interval::dec);
    os << '[' << x.INF << ", " << x.SUP << ']';
    os.precision(old_dec);
  }
  return os;
}


istream &operator >>(istream &is, Interval &x)
{
  double inf, sup;
  char ch;

  is >> ch;

  if (ch == '[') {
    is >> inf >> ch;
    if (ch == ',')
      is >> sup >> ch;
    else
      sup = inf;    
    if (ch != ']')
      is.clear(istream::failbit);
  }
  
  else {
    is.putback(ch);
    is >> inf;
    sup = inf;
  }

  if (!(is.fail() || is.bad())) {
    x = Interval(inf, sup);
  }
    
  return is;
}
#endif


void Interval::bitImage(ostream &os) const 
{
  os << "[ ";
  Double::basicBitImage(INF, os);
  os << " ," << endl << "  ";
  Double::basicBitImage(SUP, os);
  os << " ]" << endl;
}

#ifdef FILIB_NAMESPACES
}
#endif


// -----------------------------------------------------------------------
// Include implementations as specified in config.h 
// -----------------------------------------------------------------------

#ifndef FILIB_INLINE_ALL
#include "Interval.icc"
#ifndef FILIB_INLINE_ARITH
#include "IntvAri.icc"
#endif
#endif
