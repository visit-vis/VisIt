/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval asinh(Interval x)
{
#ifdef FILIB_NATIVE_ROUNDING
#ifndef FILIB_ENSURE_ROUND_NEAR
  ROUND_NEAR;
#endif
#endif

#ifdef FILIB_EXTENDED
  if (x.isEmpty()) 
    return Interval::EMPTY();
#endif

  Interval res;
  if (x.INF==x.SUP)             /* point interval */
    { 
       if (x.INF<0)
        {
          if (x.INF>-q_minr)
            {
               res.INF=x.INF;
               res.SUP=r_succ(x.INF);
            }
          else
            {
              res.INF=q_asnh(x.INF);
              res.SUP=res.INF*q_asnm;
              res.INF*=q_asnp;
              if (res.INF<x.INF) res.INF=x.INF;
            } 
        }
       else 
         {
           if (x.INF<q_minr)
             {         
               res.SUP=x.INF;
               if (x.INF==0)
                  res.INF=0; 
               else
                  res.INF=r_pred(x.INF);
             }
           else
             {
                res.INF=q_asnh(x.INF);
                res.SUP=res.INF*q_asnp;
                res.INF*=q_asnm;
                if (res.SUP>x.INF) res.SUP=x.INF;
              }
        }
    }
  else
    {
      if (x.INF<=0)
        {
          if (x.INF>-q_minr)
            res.INF=x.INF;         /* includes the case x.INF=0  */
          else
            {
              res.INF=q_asnh(x.INF)*q_asnp;
              if (res.INF<x.INF) res.INF=x.INF;
            }          
        }
      else  /* now x.INF>0 */
        {
          if (x.INF<q_minr)
            res.INF=r_pred(x.INF);      
          else 
            res.INF=q_asnh(x.INF)*q_asnm;
        }
      if (x.SUP<0)
        {
          if (x.SUP>-q_minr)
            res.SUP=r_succ(x.SUP);
          else
            res.SUP=q_asnh(x.SUP)*q_asnm;          
        }
      else  /* now x.SUP>=0 */
        {
          if (x.SUP<q_minr)
            res.SUP=x.SUP;         /* includes the case x.SUP=0 */    
          else
            { 
              res.SUP=q_asnh(x.SUP)*q_asnp;
              if (res.SUP>x.SUP) res.SUP=x.SUP;
            }
        }
    }   
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif















