/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval asin(Interval x)
{
#ifdef FILIB_EXTENDED
  static Interval ASIN_DOMAIN(-1, 1);
  x = intersect(x, ASIN_DOMAIN);
  if (x.isEmpty())
    return Interval::EMPTY();
#endif

  Interval res;
  if (x.isPoint())
    { 
       if (x.INF<0)
        {
          if (x.INF>-q_atnt)
            {
               res.INF=r_pred(x.INF);
               res.SUP=x.INF;
            }
          else
            {
              res.INF=q_asin(x.INF);
              res.SUP=res.INF*q_csnm;
              res.INF*=q_csnp;
              if (res.SUP>x.INF) res.SUP=x.INF;
            } 
        }
       else 
         {
           if (x.INF<q_atnt)
             {         
               res.INF=x.INF;
               if (x.INF==0)
                  res.SUP=0; 
               else
                  res.SUP=r_succ(x.INF);
             }
           else
             {
                res.INF=q_asin(x.INF);
                res.SUP=res.INF*q_csnp;
                res.INF*=q_csnm;
                if (res.INF<x.INF) res.INF=x.INF;
              }
        }
    }
  else
    {
      if (x.INF<0)
        {
          if (x.INF>-q_atnt)
            res.INF=r_pred(x.INF); 
          else
            res.INF=q_asin(x.INF)*q_csnp;          
        }
      else  /* x.INF>=0 */
        {
          if (x.INF<q_atnt)
            res.INF=x.INF;      
          else 
            {
              res.INF=q_asin(x.INF)*q_csnm;
              if (res.INF<x.INF) res.INF=x.INF;
            }
        }
      if (x.SUP<=0)
        {
          if (x.SUP>-q_atnt)
            res.SUP=x.SUP;
          else
            {
              res.SUP=q_asin(x.SUP)*q_csnm;
              if (res.SUP>x.SUP) res.SUP=x.SUP;
            }          
        }
      else  /* x.SUP>0 */
        {
          if (x.SUP<q_atnt)
            res.SUP=r_succ(x.SUP);         /* includes the case x.SUP=0 */       
          else 
            res.SUP=q_asin(x.SUP)*q_csnp;
        }
    }   
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
