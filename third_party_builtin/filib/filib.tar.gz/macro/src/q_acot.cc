/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "ieee.h"
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

double q_acot(double x)
{
  double res;

  if (Double::isNaN(x))
#ifdef FILIB_EXTENDED
    return Double::QUIET_NAN();
#else  
    res=q_abortnan(INV_ARG,&x,16);
#endif

  else 
  {
    /* main program with different cases */
    if ((-1e-17<x)&&(x<1e-17)) res=q_piha;
    else if (x<0) res=q_pi+q_atn1(1.0/x);
    else if (x<1e10) res= q_atn1(1.0/x); 
    else        res=1.0/x;     
  }
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
