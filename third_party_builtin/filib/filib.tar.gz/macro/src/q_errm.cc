/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 

#ifdef FILIB_STD_HEADERS
  #include <iostream>
  #include <iomanip>
  #include <cstdlib>
  using namespace std;
#else
  #include <iostream.h>
  #include <iomanip.h>
  #include <stdlib.h> 
#endif

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

#ifdef FILIB_EXIT_ON_ERROR
#define FILIB_EXIT exit(-1)
#else
#define FILIB_EXIT
#endif


static const char *filib_err = "*** Error in fi_lib++ (V1.0): ";  

static Interval undefinedInterval() 
{
  return Interval(Double::QUIET_NAN(), Double::QUIET_NAN());
}

static double undefinedDouble()  
{
  return Double::QUIET_NAN();
}
     

/* ----------- error handling for argument == NaN ---------------*/
double q_abortnan(int n, const double *x, int fctn)
{
  cerr << endl << filib_err << "Function: ";
  switch(fctn){
     case  0: cerr << "q_sqrt"; break; 
     case  1: cerr << "q_sqr "; break; 
     case  2: cerr << "q_exp "; break; 
     case  3: cerr << "q_epm1"; break; 
     case  4: cerr << "q_exp2"; break; 
     case  5: cerr << "q_ex10"; break; 
     case  6: cerr << "q_log "; break; 
     case  7: cerr << "q_lg1p"; break; 
     case  8: cerr << "q_log2"; break; 
     case  9: cerr << "q_lg10"; break; 
     case 10: cerr << "q_sin "; break; 
     case 11: cerr << "q_cos "; break; 
     case 12: cerr << "q_tan "; break; 
     case 13: cerr << "q_cot "; break; 
     case 14: cerr << "q_asin"; break; 
     case 15: cerr << "q_acos"; break; 
     case 16: cerr << "q_atan"; break; 
     case 17: cerr << "q_acot"; break; 
     case 18: cerr << "q_sinh"; break; 
     case 19: cerr << "q_cosh"; break; 
     case 20: cerr << "q_tanh"; break; 
     case 21: cerr << "q_coth"; break; 
     case 22: cerr << "q_asnh"; break; 
     case 23: cerr << "q_acnh"; break; 
     case 24: cerr << "q_atnh"; break; 
     case 25: cerr << "q_acth"; break; 
  }
  cerr << endl << filib_err << "Argument == NaN !" << endl;
  FILIB_EXIT;
  return undefinedDouble(); 
}

/* ------------ error handling for point arguments ---------------*/
double q_abortr1(int n, const double *x, int fctn)
{
  cerr << endl << filib_err << "Function: ";
  switch(fctn){
     case  0: cerr << "q_sqrt"; break; 
     case  1: cerr << "q_sqr "; break; 
     case  2: cerr << "q_exp "; break; 
     case  3: cerr << "q_epm1"; break; 
     case  4: cerr << "q_exp2"; break; 
     case  5: cerr << "q_ex10"; break; 
     case  6: cerr << "q_log "; break; 
     case  7: cerr << "q_lg1p"; break; 
     case  8: cerr << "q_log2"; break; 
     case  9: cerr << "q_lg10"; break; 
     case 10: cerr << "q_sin "; break; 
     case 11: cerr << "q_cos "; break; 
     case 12: cerr << "q_tan "; break; 
     case 13: cerr << "q_cot "; break; 
     case 14: cerr << "q_asin"; break; 
     case 15: cerr << "q_acos"; break; 
     case 16: cerr << "q_atan"; break; 
     case 17: cerr << "q_acot"; break; 
     case 18: cerr << "q_sinh"; break; 
     case 19: cerr << "q_cosh"; break; 
     case 20: cerr << "q_tanh"; break; 
     case 21: cerr << "q_coth"; break; 
     case 22: cerr << "q_asnh"; break; 
     case 23: cerr << "q_acnh"; break; 
     case 24: cerr << "q_atnh"; break; 
     case 25: cerr << "q_acth"; break; 
     case 26: cerr << "q_comp"; break;
  }
  cerr << endl;
  if (n==INV_ARG) 
    cerr << filib_err << "Invalid argument !" << endl;
  else
    cerr << filib_err << "Overflow (result) !" << endl;
  cerr << filib_err << "Argument x = " << setprecision(15) << *x << endl;
  FILIB_EXIT;
  return undefinedDouble();
}


/* ------------- error handling for interval arguments -------------*/

Interval q_abortr2(int n, const double *x1, const double *x2, int fctn)
{
  cerr << endl << filib_err;  
  switch(fctn){
     case  0: cerr << "sqrt"; break; 
     case  1: cerr << "sqr "; break; 
     case  2: cerr << "exp "; break; 
     case  3: cerr << "epm1"; break; 
     case  4: cerr << "exp2"; break; 
     case  5: cerr << "exp10"; break; 
     case  6: cerr << "log "; break; 
     case  7: cerr << "log1p"; break; 
     case  8: cerr << "log2"; break; 
     case  9: cerr << "log10"; break; 
     case 10: cerr << "sin "; break; 
     case 11: cerr << "cos "; break; 
     case 12: cerr << "tan "; break; 
     case 13: cerr << "cot "; break; 
     case 14: cerr << "asin"; break; 
     case 15: cerr << "acos"; break; 
     case 16: cerr << "atan"; break; 
     case 17: cerr << "acot"; break; 
     case 18: cerr << "sinh"; break; 
     case 19: cerr << "cosh"; break; 
     case 20: cerr << "tanh"; break; 
     case 21: cerr << "coth"; break; 
     case 22: cerr << "asinh"; break; 
     case 23: cerr << "acosh"; break; 
     case 24: cerr << "atanh"; break; 
     case 25: cerr << "acoth"; break; 
  }
  cerr << endl;
  if (n==INV_ARG) 
    cerr << filib_err << "Invalid argument !" << endl;
  else 
    cerr << filib_err << "Overflow (result) !" << endl;
  cerr << filib_err << "Argument x.INF: " << setprecision(15) << *x1 << endl;
  cerr << filib_err << "Argument x.SUP: " << setprecision(15) << *x2 << endl;

  FILIB_EXIT;

  return undefinedInterval();
}

/* ------------ error handling for point arguments ---------------*/
double q_abortdivd(int n, const double *x)
{
  cerr << endl << filib_err << "interval division" << endl;
  cerr << filib_err << "Division by zero !" << endl;
  cerr << filib_err << "x = " << setprecision(15) << *x << endl;

  return undefinedDouble();
}

/* ------------- error handling for interval arguments -------------*/
Interval q_abortdivi(int n, const double *x1, const double *x2)
{
  cerr << endl << filib_err << "interval division" << endl;
  cerr << filib_err << "Division by zero !" << endl;
  cerr << filib_err << "x.INF = " << setprecision(15) << *x1 << endl;
  cerr << filib_err << "x.SUP = " << setprecision(15) << *x2 << endl;

  FILIB_EXIT;

  return undefinedInterval();
}



// error handling for empty interval intersection
Interval errorIntersect(Interval x, Interval y) 
{
  cerr << endl << filib_err << "interval intersection" << endl;
  cerr << filib_err << "Empty intersection !" << endl;
  cerr << filib_err << "Argument x = " << x << endl;
  cerr << filib_err << "Argument y = " << y << endl;
  
  FILIB_EXIT;
  
  return undefinedInterval();
}

#ifdef FILIB_NAMESPACES
}
#endif








