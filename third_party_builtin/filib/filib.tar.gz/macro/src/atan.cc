/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval atan(Interval x)
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty()) 
    return Interval::EMPTY();
#endif

  Interval res;
  if (x.isPoint())
    { 
       if (x.INF<0)
        {
          if (x.INF>-q_atnt)
            {
               res.INF=x.INF;
               res.SUP=r_succ(x.INF);
            }
          else
            {
              res.INF=q_atan(x.INF);
              res.SUP=res.INF*q_ctnm;
              res.INF*=q_ctnp;
              if (res.INF<x.INF) res.INF=x.INF;
            } 
        }
       else 
         {
           if (x.INF<q_atnt)
             {         
               res.SUP=x.INF;
               if (x.INF==0)
                  res.INF=0; 
               else
                  res.INF=r_pred(x.INF);
             }
           else
             {
                res.INF=q_atan(x.INF);
                res.SUP=res.INF*q_ctnp;
                res.INF*=q_ctnm;
                if (res.SUP>x.INF) res.SUP=x.INF;
             }
        }
    }
  else
    {
      if (x.INF<=0)
        {
          if (x.INF>-q_atnt)
            res.INF=x.INF;         /* includes the case x.INF=0 */
          else
            {
              res.INF=q_atan(x.INF)*q_ctnp;
              if (res.INF<x.INF) res.INF=x.INF;
            }          
        }
      else  /* now x.INF>0 */
        {
          if (x.INF<q_atnt)
            res.INF=r_pred(x.INF);      
          else 
            res.INF=q_atan(x.INF)*q_ctnm;
        }
      if (x.SUP<0)
        {
          if (x.SUP>-q_atnt)
            res.SUP=r_succ(x.SUP);
          else
            res.SUP=q_atan(x.SUP)*q_ctnm;          
        }
      else  /* x.SUP>=0 */
        {
          if (x.SUP<q_atnt)
            res.SUP=x.SUP;          /* includes the case x.SUP=0  */       
          else
            { 
              res.SUP=q_atan(x.SUP)*q_ctnp;
              if (res.SUP>x.SUP) res.SUP=x.SUP;
            }
        }
    }   
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
