/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval exp2(Interval x)
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty()) 
    return Interval::EMPTY();
#endif

  Interval res;
  if (x.isPoint())
    { 
      if (x.INF<-1022)
        { 
          res.INF=0.0;
          res.SUP=q_minr;
        }
      else if (CUTINT(x.INF)==x.INF) 
        res.INF=res.SUP=q_exp2(x.INF);
      else 
        { 
          res.INF=q_exp2(x.INF);
          res.SUP=res.INF*q_e2ep;
          res.INF*=q_e2em;
        }
    }
  else
    {
      if (x.INF<-1022) 
        res.INF=0.0;
      else if (CUTINT(x.INF)==x.INF)
        res.INF=q_exp2(x.INF);
      else
        res.INF=q_exp2(x.INF)*q_e2em;
      if (x.SUP<-1022)
        res.SUP=q_minr;
      else if (CUTINT(x.SUP)==x.SUP)
        res.SUP=q_exp2(x.SUP);
      else
        res.SUP=q_exp2(x.SUP)*q_e2ep;
    }   
 if (res.INF<0.0) res.INF=0.0;
 if ((x.SUP<=0.0) && (res.SUP>1.0)) res.SUP=1.0;
 if ((x.INF>=0.0) && (res.INF<1.0)) res.INF=1.0;

#ifdef FILIB_EXTENDED
 if (res.INF == Double::POS_INFTY())
   res.INF = Double::MAX();
#endif

 return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
