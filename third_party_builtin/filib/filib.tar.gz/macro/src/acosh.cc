/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval acosh(Interval x)
{

  Interval res;

#ifdef FILIB_EXTENDED
  static Interval ACSH_DOMAIN(1, Double::POS_INFTY());
  x = intersect(x, ACSH_DOMAIN);
  if (x.isEmpty())
    return Interval::EMPTY();
#else
  if (x.INF<1)                    /* Invalid argument */
    res=q_abortr2(INV_ARG,&x.INF,&x.SUP,23);
#endif
  
  if (x.isPoint())
    { 
      if (x.INF==1) 
	res.INF=res.SUP=0;
      else
        { 
          res.INF=q_acsh(x.INF);
          res.SUP=res.INF*q_acsp;
          res.INF*=q_acsm;
        }
    }
  else
    {
      res.INF=q_acsh(x.INF)*q_acsm;
      res.SUP=q_acsh(x.SUP)*q_acsp;
    }   
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
