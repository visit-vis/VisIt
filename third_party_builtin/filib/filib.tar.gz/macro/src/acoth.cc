/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval acoth(Interval x)
{
 Interval res;

#ifdef FILIB_EXTENDED
 if ((x.INF > -1 && x.SUP < 1) || x.isEmpty())
   return Interval::EMPTY();
#endif

 if (x.SUP<-1)
 {
   if (x.isPoint())
    { 
      res.INF=q_acth(x.INF);
      res.SUP=res.INF*q_actm;
      res.INF*=q_actp;
    }
   else
    {
      res.INF=q_acth(x.SUP)*q_actp;
      res.SUP=q_acth(x.INF)*q_actm;
    } 
 }    
 else if(x.INF>1)
 {
   if (x.isPoint())
    { 
      res.INF=q_acth(x.INF);
      res.SUP=res.INF*q_actp;
      res.INF*=q_actm;
    }
   else
    {
      res.INF=q_acth(x.SUP)*q_actm;
      res.SUP=q_acth(x.INF)*q_actp;
    }  
 }
 else   
 {
#ifdef FILIB_EXTENDED
   if (x.INF < -1.0) {
     if (x.SUP < 1.0) {
       res.INF = Double::NEG_INFTY();
       res.SUP = q_acth(x.INF)*q_actm;
     }
     else 
       res = Interval::ENTIRE();
   }
   else if (x.INF == -1.0) {
     if (x.SUP < 1.0)
       res = Interval::NEG_INFTY();
     else
       res = Interval::ENTIRE();
   }
   else {  // -1 < x.INF < 1
     if (x.SUP == 1.0)
       res = Interval::POS_INFTY();
     else { // x.SUP >= 1
       res.INF = q_acth(x.SUP)*q_actp;
       res.SUP = Double::POS_INFTY();
     }
   }
#else
      res=q_abortr2(INV_ARG,&x.INF,&x.SUP,25);  /* invalid argument */
#endif

 }
 return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif




