// ---------------------------------------------------------------------------
// Modified code from i_util.cpp from C-XSC
// ---------------------------------------------------------------------------

#include "Interval.h"

//----------------------------------------------------------------------------
// Purpose: The local function 'Power()' is used to compute a lower or an
//    upper bound for the power function with real argument and integer
//    exponent, respectively.
// Parameters:
//    In: 'x'      : real argument
//        'n'      : integer exponent
//        'RndMode': rounding mode,
//                   (-1 = downwardly directed, +1 = upwardly directed)
// Description:
//    This function is used to speed up the interval power function defined
//    below. The exponentiation is reduced to multiplications using the
//    binary shift method. Depending on 'n', this function is up to 40 times
//    as fast as the standard power function for real argument and real
//    exponent. However, its accuracy is less than one ulp (unit in the last
//    place of the mantissa) since about log2(n) multiplications are executed
//    during computation. Since directed roundings are antisymmetric, one
//    gets
//
//       down(x^n) = -up((-x)^n)   and   up(x^n) = -down((-x)^n)
//
//    for x < 0 and odd n, where 'down' and 'up' denote the downwardly and
//    upwardly directed roundings, respectively.
//----------------------------------------------------------------------------
static double Power ( double x, int n, int RndMode )
{                         // Signals change of the rounding mode
  int  ChangeRndMode;     // for x < 0 and odd n
  double p, z;

  // special case x == 0
  if (x == 0.0)
    return n == 0 ? 1.0 : 0.0;


  ChangeRndMode = ( (x < 0.0) && (n % 2 == 1) );

  if (ChangeRndMode) {
    z = -x;
    RndMode = -RndMode;
  }
  else
    z = x;

  p = 1.0;
  switch (RndMode) {                    // Separate while-loops used
     case -1 : while (n > 0) {          // to gain speed at runtime
       if (n % 2 == 1)                  //--------------------------
#ifdef FILIB_NATIVE_ROUNDING
	 MUL_DOWN_UPD(p, z);
#else
         p = Double::pred(p * z);
#endif
       n = n / 2;
       if (n > 0) 
#ifdef FILIB_NATIVE_ROUNDING
	 MUL_DOWN_UPD(z, z)
#else
         z = Double::pred(z * z);
#endif
     }
     break;
     
     case 1 : while (n > 0) {
       if (n % 2 == 1)
#ifdef FILIB_NATIVE_ROUNDING
	 MUL_UP_UPD(p, z)
#else 
         p = Double::succ(p * z);
#endif
       n = n / 2;
       if (n > 0) 
#ifdef FILIB_NATIVE_ROUNDING
	 MUL_UP_UPD(z, z);
#else
         z = Double::succ(z * z);
#endif
     }
     break;
  }

  if (ChangeRndMode)
    return -p;
  else
    return p;
}

//----------------------------------------------------------------------------
// Purpose: This version of the function 'pow()' is used to compute an
//    enclosure for the power function with interval argument and integer
//    exponent.
// Parameters:
//    In: 'x': interval argument
//        'n': integer exponent
// Description:
//    In general, this implementation does not deliver a result of maximum
//    accuracy, but it is about 30-40 times faster than the standard power
//    function for interval arguments and interval exponents. The resulting
//    interval has a width of approximately 2*log2(n) ulps. Since x^n is
//    considered as a monomial, we define x^0 := 1. For negative exponents
//    and 0 in 'x', the division at the end of the function will cause a
//    runtime error (division by zero).
//----------------------------------------------------------------------------

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval power(Interval x, int n)
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty())
    return Interval::EMPTY();
#endif

  if (n == 0) 
    return(Interval(1.0,1.0));

  if (n == 1)
    return x;

  int  m;
  Interval res(false, false, false);  
  
  if (n > 0)  
    m = n;  
  else  
    m = -n;
  
  if ( (0.0 < inf(x)) || (m % 2 == 1) ) {
    res.INF = Power(inf(x),m,-1);
    res.SUP = Power(sup(x),m,+1);
  }
  else if (0.0 > sup(x)) {
    res.INF = Power(sup(x),m,-1);
    res.SUP = Power(inf(x),m,+1);
  }
  else {
    res.INF = 0.0;
    res.SUP = Power(mag(x),m,+1);
  }

  if (n < 0) {
    if (n % 2)
      res = 1.0/res;
    else {
      if (x.contains(0.0)) {
	res.INF = 0.0;
	res.SUP = Double::POS_INFTY();
      }
      else
	res = 1.0/res;
    }
  }

#ifdef FILIB_NATIVE_ROUNDING
  POSS_ROUND_NEAR;
#endif

  return res;
}

Interval pow(Interval x, Interval y) 
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty() || y.isEmpty())
    return Interval::EMPTY();
  else 
#endif

#if ! defined(FILIB_EXTENDED)
  if ( inf(x) <= 0.0 )
  {
    std::cerr << "base is not positive in pow()." << std::endl;
    std::terminate();
  }
#endif

    return exp(y * log(x));
}

#ifdef FILIB_NAMESPACES
}
#endif
















