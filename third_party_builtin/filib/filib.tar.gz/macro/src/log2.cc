/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval log2(Interval x)
{
#ifdef FILIB_EXTENDED
  static Interval LOG2_DOMAIN(0, Double::POS_INFTY());
  x = intersect(x, LOG2_DOMAIN);
  if (x.isEmpty())
    return Interval::EMPTY();
#endif

  Interval res;
  if (x.isPoint()) { 
    res.INF=q_log2(x.INF);

#ifdef FILIB_EXTENDED
    if (Double::isNaN(res.INF))
      res = Interval::NEG_INFTY();
    else
#endif
      {
	if (res.INF>=0) {
	  res.SUP=res.INF*q_lg2p;
	  res.INF*=q_lg2m;
	}
	else {
	  res.SUP=res.INF*q_lg2m;
	  res.INF*=q_lg2p;
	}
      }
  }

  else {
    res.INF=q_log2(x.INF);
    if (res.INF>=0)
      res.INF*=q_lg2m;
    else
      res.INF*=q_lg2p;

#ifdef FILIB_EXTENDED
    if (x.SUP == Double::POS_INFTY())
      res.SUP = Double::POS_INFTY();
    else
#endif
      {
	res.SUP=q_log2(x.SUP);
	if (res.SUP>=0)
	  res.SUP*=q_lg2p;
	else
	  res.SUP*=q_lg2m;
      }
  
#ifdef FILIB_EXTENDED
    if (Double::isNaN(res.INF))
      res.INF = Double::NEG_INFTY();
    if (Double::isNaN(res.SUP))
      res.SUP = Double::POS_INFTY();
#endif

}


 return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif


