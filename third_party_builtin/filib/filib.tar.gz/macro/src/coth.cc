/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval coth(Interval x)
{
#ifdef FILIB_NATIVE_ROUNDING
#ifndef FILIB_ENSURE_ROUND_NEAR
  ROUND_NEAR;
#endif
#endif

#ifdef FILIB_EXTENDED
  if (x.isEmpty()) 
    return Interval::EMPTY();
#endif

  Interval res;
  
 if (x.SUP<0)
 {
   if (x.isPoint())
     { 
       res.INF=q_coth(x.INF);

#ifdef FILIB_EXTENDED
       // this may be the case for x > -q_ctht
       if (Double::isNaN(res.INF))
	 res = Interval::NEG_INFTY();
       else
#endif
       {
	 res.SUP=res.INF*q_cthm;
	 res.INF*=q_cthp;
       }
       
     }
   else
    {
      res.INF=q_coth(x.SUP)*q_cthp;
      res.SUP=q_coth(x.INF)*q_cthm;

#ifdef FILIB_EXTENDED
      // this may be the case for x.SUP > -q_ctht
      if (Double::isNaN(res.INF))
	res.INF = Double::NEG_INFTY();

      // this may be the case for x.INF > -q_ctht
      if (Double::isNaN(res.SUP))
	res.SUP = -Double::MAX();
#endif
	
    } 
   if (res.SUP>-1) res.SUP=-1.0;
 }    /* end  if (x.SUP<0) */

 else if(x.INF>0)
 {
   if (x.isPoint())
    { 
      res.INF=q_coth(x.INF);

#ifdef FILIB_EXTENDED
       // this may be the case for x < q_ctht
       if (Double::isNaN(res.INF))
	 res = Interval::POS_INFTY();
       else
#endif
     {
       res.SUP=res.INF*q_cthp;
       res.INF*=q_cthm;
     }
       
    }
   else
    {
      res.INF=q_coth(x.SUP)*q_cthm;
      res.SUP=q_coth(x.INF)*q_cthp;

#ifdef FILIB_EXTENDED
      // this may be the case for x.INF < q_ctht
      if (Double::isNaN(res.SUP))
	res.SUP = Double::POS_INFTY();
      // this may be the case for x.SUP < q_ctht
      if (Double::isNaN(res.INF))
	res.INF = Double::MAX();
#endif
      
    }  
   if (res.INF<1) res.INF=1.0;
 }

 else   
 {
#ifdef FILIB_EXTENDED
   return Interval::ENTIRE();
#else
   res=q_abortr2(INV_ARG,&x.INF,&x.SUP,21);  /* invalid argument */
#endif

 }
 return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif































