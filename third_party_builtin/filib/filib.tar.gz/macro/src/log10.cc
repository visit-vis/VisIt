/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval log10(Interval x)
{
#ifdef FILIB_EXTENDED
  static Interval LOG10_DOMAIN(0, Double::POS_INFTY());
  x = intersect(x, LOG10_DOMAIN);
  if (x.isEmpty())
    return Interval::EMPTY();
#endif

  Interval res;
  if (x.isPoint()) { 
    res.INF=q_lg10(x.INF);

#ifdef FILIB_EXTENDED
    if (Double::isNaN(res.INF))
      res = Interval::NEG_INFTY();
    else
#endif

      {
	if (res.INF>=0) {
	  res.SUP=res.INF*q_l10p;
	  res.INF*=q_l10m;
	}
	else {
	  res.SUP=res.INF*q_l10m;
	  res.INF*=q_l10p;
	}
      }
  }

  else {
    res.INF=q_lg10(x.INF);
    if (res.INF>=0)
      res.INF*=q_l10m;
    else
      res.INF*=q_l10p;

#ifdef FILIB_EXTENDED
    if (x.SUP == Double::POS_INFTY())
      res.SUP = Double::POS_INFTY();
    else
#endif
      {
	res.SUP=q_lg10(x.SUP);
	if (res.SUP>=0)
	  res.SUP*=q_l10p;
	else
	  res.SUP*=q_l10m;
      }
    
#ifdef FILIB_EXTENDED
    if (Double::isNaN(res.INF))
      res.INF = Double::NEG_INFTY();
    if (Double::isNaN(res.SUP))
      res.SUP = Double::POS_INFTY();
#endif
    
  }   
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
