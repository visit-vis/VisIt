#include <config.h>

#ifdef FILIB_STD_HEADERS
  #include <iostream>
  using namespace std;
#else
  #include <iostream.h>
#endif

#include "config.h"
#include "ieee.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

// -----------------------------------------------------------------------
// Internal functions to compute special numbers
// -----------------------------------------------------------------------
double Double::computeMin() 
{
  a_diee f;
  f.ieee.sign  = 0x0;
  f.ieee.expo  = 0x0;
  f.ieee.mant0 = 0x0;
  f.ieee.mant1 = 0x1;
  return f.f;
}

double Double::computeMinNorm() 
{
  a_diee f;
  f.ieee.sign  = 0x0;
  f.ieee.expo  = 0x1;
  f.ieee.mant0 = 0x0;
  f.ieee.mant1 = 0x0;
  return f.f;
}

double Double::computeMax() 
{
  a_diee f;
  f.ieee.sign  = 0x0;
  f.ieee.expo  = 0x7FE;
  f.ieee.mant0 = 0xFFFFF;
  f.ieee.mant1 = 0xFFFFFFFF;
  return f.f;
}

double Double::computePosInf() 
{
  a_diee f;
  f.ieee.sign  = 0x0;
  f.ieee.expo  = 0x7FF;
  f.ieee.mant0 = 0x0;
  f.ieee.mant1 = 0x0;
  return f.f;
}

double Double::computeNegInf() 
{
  a_diee f;
  f.ieee.sign  = 0x1;
  f.ieee.expo  = 0x7FF;
  f.ieee.mant0 = 0x0;
  f.ieee.mant1 = 0x0;
  
  return f.f;
}

double Double::computeQNaN() 
{
  a_diee f;
  f.ieee.sign  = 0x0;
  f.ieee.expo  = 0x7FF;
  f.ieee.mant0 = 0x80000;
  f.ieee.mant1 = 0x0;
  return f.f;
}

// ----------------------------------------------------------------------- 
// pred/succ table stuff
// -----------------------------------------------------------------------
#ifdef FILIB_PRED_SUCC_TABLES

Double::PredSuccTable::PredSuccTable() 
{
  a_diee f;
  f.ieee.sign  = 0;
  f.ieee.mant0 = 0;
  f.ieee.mant1 = 0;

  ULP = new double[2048];
  for( int i=0; i<2048; i++ ) {
    f.ieee.expo = i;
    ULP[i] = Double::ulp(f.f);
    
    //cout << i << ": \t";
    //Double::bitImage(ULP[i], cout);
    //cout << endl;
  }
}

Double::PredSuccTable::~PredSuccTable() 
{
  delete [] ULP;
}

Double::PredSuccTable Double::psTable;

#endif

// -----------------------------------------------------------------------
// Platform dependent code for FPU initialization
// -----------------------------------------------------------------------

Double::FPUStartUp::FPUStartUp() 
{
#ifdef __i386__
#if defined(__GNUC__) || defined(__KCC)
  //
  // Mark C. Miller, Thu Dec  7 17:19:46 PST 2006
  // This asm line is insidius. It changes FPU behavior permanently
  // and for the entire executable, not just the execution of methods in
  // this library. It happens during the link/load of the library and so
  // any executable just including it on the link line will be irrecovably
  // changed. No method is provided to undue it.
  //
  // set FPU control to double precision, rounding to nearest, no interrupts
  //asm("fldcw %0" : : "m" (0x027F) );
#endif 
#endif // __i386__
}

Double::FPUStartUp startup;

// -----------------------------------------------------------------------
// Instantiation of static members of class Double
// -----------------------------------------------------------------------
double Double::min     = computeMin();  
double Double::minNorm = computeMinNorm();  
double Double::max     = computeMax();
double Double::posInf  = computePosInf();
double Double::negInf  = computeNegInf();
double Double::qNaN    = computeQNaN();

// -----------------------------------------------------------------------
// I/O
// -----------------------------------------------------------------------
void Double::print(double x, ostream &os) 
{
  if (x == NEG_INFTY())
    os << "-INF";
  else if (x == POS_INFTY())
    os << "+INF";
  else if (isNaN(x))
    os << "NaN";
  else
    os << x;
}

void Double::bitImage(double d, ostream &os) 
{
  basicBitImage(d, os);
  os << endl;
}

void Double::basicBitImage(double d, ostream &os) 
{
  a_diee f;
  f.f = d;

  int i;

  os << (f.ieee.sign == 1 ? '1' : '0') << ':';
  
  i = 11;
  while (i--)
      os << ((f.ieee.expo & (1 << i)) ? '1' : '0');
  os << ':';
  
  i = 20;
  while (i--)
      os << ((f.ieee.mant0 & (1 << i)) ? '1' : '0');
  
  i = 32;
  while (i--)
      os << ((f.ieee.mant1 & (1 << i)) ? '1' : '0');
}
template <>
double constructFromBitSet<double>(std::istream & in) throw(std::runtime_error)
{
	std::vector<unsigned char> signBit  = readBitSet<1>(in);
	readChar<':'>(in);
	std::vector<unsigned char> expBits  = readBitSet<11>(in);
	readChar<':'>(in);
	std::vector<unsigned char> mantBits = readBitSet<52>(in);
	
	unsigned int sign  = signBit[0];
	unsigned int exp   = 0;
	
	for ( int i = 0; i < 11; ++i )
	{
		exp <<= 1;
		exp |= expBits[i];
	}

	unsigned int mant0 = 0;

	for ( int i = 0; i < 20; ++i )
	{
		mant0 <<= 1;
		mant0 |= mantBits[i];
	}
	
	unsigned int mant1 = 0;

	for ( int i = 20; i < 52; ++i )
	{
		mant1 <<= 1;
		mant1 |= mantBits[i];
	}

	return Double::compose(sign,exp,mant0,mant1);
}

template<>
int whitespace<char>::isSpace(int arg)
{
	return isspace(arg);
}

#ifdef FILIB_NAMESPACES
}
#endif












