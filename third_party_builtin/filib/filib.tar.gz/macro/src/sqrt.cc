/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval sqrt(Interval x)
{
#ifdef FILIB_EXTENDED
  static Interval SQRT_DOMAIN(0, Double::POS_INFTY());
  x = intersect(x, SQRT_DOMAIN);
  if (x.isEmpty())
    return Interval::EMPTY();
#else
  if (x.INF < 0.0 || Double::isNaN(x.INF) || Double::isNaN(x.SUP))
    return q_abortr2(INV_ARG, &x.INF, &x.SUP, 0);
#endif

    Interval res;
    if (x.isPoint()) { 
	if (x.INF==0)
	    res.INF=res.SUP=0;
	else { 
	    res.INF=::sqrt(x.INF); 
	    res.SUP=r_succ(res.INF);
	    res.INF=r_pred(res.INF);
	}
    }
    else {
#ifdef FILIB_EXTENDED
      if (x.INF <= 0)
	res.INF = 0;
#else      
      if (x.INF == 0) 
	res.INF = 0;
#endif
      else 
	res.INF=r_pred(::sqrt(x.INF));
      
      res.SUP = x.SUP == 0 ? 0 : r_succ(::sqrt(x.SUP));
    }   
    return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif






