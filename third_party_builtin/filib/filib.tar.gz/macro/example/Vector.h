#ifndef VECTOR_H
#define VECTOR_H

#include <iostream.h>
#include <assert.h>

// ---------------
// class Vector<T>
// ---------------
template <class T>
class Vector
{
public:
  typedef T value_type;
  
  Vector(unsigned int length)
    : n(length)
  {
    assert (data = new T[n]);
  }

  Vector(const Vector<T> &x) 
  {
    n = x.n;
    assert (data = new T[n]);
    for (int i=0; i<n; i++)
      data[i] = x.data[i];
  }

  ~Vector()
  {
    delete [] data;
  }
  
  Vector<T> &operator =(const Vector<T> &x) 
  {
    if (&x != this) {
      if (n != x.n) {
	delete [] data;
	n = x.n;
	assert(data = new T[n]);
      }
      for (int i=0; i<n; i++)
	data[i] = x.data[i];
    }
    return *this;
  }

  T &operator [](unsigned int i)
  {
    assert (i<n);
    return data[i];
  }

  const T &operator[](unsigned int i) const
  {
    assert (i<n);
    return data[i];
  }

  unsigned int size() const
  {
    return n;
  }

  friend ostream &operator <<(ostream &os, const Vector<T> &v)
  {
    for (unsigned int i=0; i<v.size(); i++) 
      os << const_cast<T&>(v[i]) << endl;
    os << endl;

    return os;
  }

protected:
  unsigned int n;
  T *data;
};

#endif


















