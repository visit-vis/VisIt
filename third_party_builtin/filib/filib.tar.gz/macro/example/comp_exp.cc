/*********************************************************************/
/*                                                                   */
/*   Example: comp_exp.cc  (Computation of the exponential function) */
/*          (For copyright and info's see file "fi_lib.h")           */
/*                                                                   */
/*********************************************************************/

#include <iostream.h>
#include "Interval.h"

/* --- main program ------------------------------------------------------ */

int main()
{
  Interval x;

  Interval::precision(8);
 
  cout << endl;
  cout << "Computation of the exponential function in C++ with fi_lib++" << endl;
  cout << "=============================================================" << endl;
  cout << endl;
  cout << "Input interval argument (e.g. '[1, 1]' or '[1.01, 1.02]')" << endl;
  cout << "x = ";
  cin >> x;  
  cout << "Argument x = " << x << endl;
  cout << "    exp(x) = " << exp(x) << endl;
  cout << endl;

  return 0;
}

