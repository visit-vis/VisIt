#ifndef _XINTERVAL_H
#define _XINTERVAL_H

#include "ieee.h"

//namespace xinewton
//{

// forward declarations for KCC :-( 
template <class T> 
class XInterval;

template <class T>
XInterval<T> operator %(T, T);

template <class T>
XInterval<T> operator -(double, XInterval<T>);

 

enum XIKindType {xiFinite, xiPlusInfty, xiMinusInfty, xiDouble, xiEmpty};

template <class I>
class XInterval {                  
public: 
  XIKindType  kind;                
  double    inf, sup;

  XInterval()
    : inf(0.0), sup(0.0), kind(xiFinite) 
  {
  }
  
  XInterval(XIKindType k, double x, double y)
    : kind(k), inf(x), sup(y)
  {
  }
  
  friend XInterval operator%<> (I A, I B);
  friend XInterval operator-<> (double a, XInterval B );
};


//----------------------------------------------------------------------------
// Extended interval division 'A / B' where 0 in 'B' is allowed.
//----------------------------------------------------------------------------

template <class Interval>
inline
XInterval<Interval> operator% (Interval A, Interval B)
{
  Interval  c;
  XInterval<Interval> Q;

  if ( in(0.0, B) ) {
    if ( in(0.0, A) ) {
      Q.kind = xiDouble;                  // Q = [-oo,+oo] = [-oo,0] v [0,+oo]
      Q.sup  = 0.0;                       //----------------------------------
      Q.inf  = 0.0;
    }
    else if ( B == 0.0 ) {                                          // Q = [/]
      Q.kind = xiPlusInfty;                                         //--------
      Q.inf  = Double::pred(sup(A)/inf(B));
    }
    else if ( (sup(A) < 0.0) && (sup(B) == 0.0) ) {         // Q = [Q.inf,+oo]
      Q.kind = xiPlusInfty;                                 //----------------
      Q.inf  = Double::pred(sup(A)/inf(B));
    }
    else if ( (sup(A) < 0.0) && (inf(B) < 0.0) && (sup(B) > 0.0) ) {
      Q.kind = xiDouble;                      // Q = [-oo,Q.sup] v [Q.inf,+oo]
      Q.sup  = Double::succ(sup(A)/sup(B));   //------------------------------
      Q.inf  = Double::pred(sup(A)/inf(B));
    }
    else if ( (sup(A) < 0.0) && (inf(B) == 0.0) ) {         // Q = [-oo,Q.sup]
      Q.kind = xiMinusInfty;                                //----------------
      Q.sup  = Double::succ(sup(A)/sup(B));
    }
    else if ( (inf(A) > 0.0) && (sup(B) == 0.0) ) {         // Q = [-oo,Q.sup]
      Q.kind = xiMinusInfty;                                //----------------
      Q.sup  = Double::succ(inf(A)/inf(B));
    }
    else if ( (inf(A) > 0.0) && (inf(B) < 0.0) && (sup(B) > 0.0) ) {
      Q.kind = xiDouble;                      // Q = [-oo,Q.sup] v [Q.inf,+oo]
      Q.sup  = Double::succ(inf(A)/inf(B));   //------------------------------
      Q.inf  = Double::pred(inf(A)/sup(B));
    }
    else { // if ( (Inf(A) > 0.0) && (Inf(B) == 0.0) )
      Q.kind = xiPlusInfty;                                 // Q = [Q.inf,+oo]
      Q.inf  = Double::pred(inf(A)/sup(B));                 //----------------
    }
  } // in(0.0,B)
  else {  // !in(0.0,B)
    c = A / B;                                            // Q = [C.inf,C.sup]
    Q.kind = xiFinite;                                    //------------------
    Q.inf  = inf(c);
    Q.sup  = sup(c);
  }

  return Q;
} 

//----------------------------------------------------------------------------
// Subtraction of an extended interval 'B' from a double value 'a'.
//----------------------------------------------------------------------------

template <class Interval>
inline
XInterval<Interval> operator- (double a, XInterval<Interval> B)
{
  XInterval<Interval> D;

  switch (B.kind) {
    case xiFinite   : D.kind = xiFinite;                  // D = [D.inf,D.sup]
                      D.inf  = Double::pred(a-B.sup);     //------------------
                      D.sup  = Double::succ(a-B.inf);
                      break;
    case xiPlusInfty: D.kind = xiMinusInfty;                  // D = [inf,+oo]
                      D.sup  = Double::succ(a-B.inf);         //--------------
                      break;
    case xiMinusInfty:D.kind = xiPlusInfty;                   // D = [-oo,sup]
                      D.inf  = Double::pred(a-B.sup);         //--------------
                      break;
    case xiDouble    :D.kind = xiDouble;       // D = [-oo,D.sup] v [D.inf,+oo]
                      D.inf  = Double::pred(a-B.sup);//------------------------
                      D.sup  = Double::succ(a-B.inf);
                      if (D.inf < D.sup) D.inf = D.sup;
                      break;
    case xiEmpty    : D.kind = xiEmpty;                             // D = [/]
                      D.inf  = Double::pred(a-B.sup);               //--------
                      break;
  } // switch
  return D;
}

//----------------------------------------------------------------------------
// Intersection of an interval 'X' and an extended interval 'Y'. The result
// is given as a pair of intervals V1 and V2, where one or both of them can 
// be empty intervals. The kind of the result is indicated by the return value
// of extIntersect:
//
// - eiSingleInterval: V1 is the result of the intersection, V2 is empty
// - eiDoubleInterval: both V1 and V2 are not empty
// - eiEmptyInterval:  the intersection is empty
//
// Note: 'empty intervals' are not produced explicitly. 
//----------------------------------------------------------------------------

enum ExtIntersectInfo {eiSingleInterval, eiDoubleInterval, eiEmptyInterval};

template <class Interval>
inline
ExtIntersectInfo extIntersect(Interval X, XInterval<Interval> Y, 
			      Interval &V1, Interval &V2)
{
  Interval H;
  
  ExtIntersectInfo info = eiEmptyInterval;
  
  switch (Y.kind) {
     case xiFinite   : // [X.inf,X.sup] & [Y.inf,Y.sup]
                       //------------------------------
                       H = Interval(Y.inf,Y.sup);
                       if ( !disjoint(X,H) ) {
			 V1 = intersect(X, H);
			 info = eiSingleInterval;
		       }
		       break;
    case xiPlusInfty: // [X.inf,X.sup] & [Y.inf,+oo]
                      //----------------------------
                      if (sup(X) >= Y.inf) {
                        if (inf(X) > Y.inf)
                          V1 = X;
                        else
                          V1 = Interval(Y.inf,sup(X));
			info = eiSingleInterval;
		      }
                      break;
    case xiMinusInfty:// [X.inf,X.sup] & [-oo,Y.sup]
                      //----------------------------
                      if (Y.sup >= inf(X)) {
                        if (sup(X)<Y.sup)
                          V1 = X;
                        else
                          V1 = Interval(inf(X),Y.sup);
			info = eiSingleInterval;
		      }
                      break;
    case xiDouble   : if ( (inf(X) <= Y.sup) && (Y.inf <= sup(X)) ) {
                        V1 = Interval(inf(X),Y.sup);    // X & [-oo,Y.sup]
                        V2 = Interval(Y.inf,sup(X));    // X & [Y.inf,+oo]
			info = eiDoubleInterval;
                      }
                      else if (Y.inf <= sup(X)){ // [X.inf,X.sup] & [Y.inf,+oo]
                        if (inf(X) >= Y.inf)     //----------------------------
                          V1 = X;
                        else
                          V1 = Interval(Y.inf,sup(X));
			info = eiSingleInterval;
		      }
                      else if (inf(X) <= Y.sup){// [X.inf,X.sup] & [-oo,Y.sup]
                        if (sup(X) <= Y.sup)    //----------------------------
                          V1 = X;
                        else
			  V1 = Interval(inf(X),Y.sup);
			info = eiSingleInterval;
		      }
                      break;
    case xiEmpty    : break;                           // [X.inf,X.sup] ** [/]
  } // switch                                          //---------------------

  return info;
}


//}

#endif




