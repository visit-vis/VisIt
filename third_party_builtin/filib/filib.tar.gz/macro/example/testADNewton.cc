#include <iomanip>
#include <vector>
#include <functional>

#include "../bench/Timer.h"

#include "xinewton.h"
#include "Interval.h"
#include "autodiff.h"

using namespace xinewton;
using namespace std;


template<>
class MCT<Interval, Interval>
{
public:
  typedef Interval value_type;
};

template<>
class MCT<Interval, double>
{
public:
  typedef Interval value_type;
};


template<>
class MCT<double, Interval>
{
public:
  typedef Interval value_type;
};

template<> 
class TypePrinter<Interval>
{
public:
  static void printType(ostream &os) 
  {
    os << "Interval";
  }
};

  

template<class Arg, class Result, class Expr>
class ETUnFun: public unary_function<Arg, Result>
{
  Expr expr;
  
public:
  ETUnFun(Expr expr_): expr(expr_) { }

  result_type operator()(argument_type x) 
  {
    return expr.eval(x);
  }
};

template<class Arg, class Result, class Expr>
class ETUnFunDeriv: public unary_function<Arg, Result>
{
  Expr expr;
  
public:
  ETUnFunDeriv(Expr expr_): expr(expr_) { }

  result_type operator()(argument_type x) 
  {
    return expr.evalDeriv(x);
  }
};



template <class Expr>
ETUnFun<typename Expr::value_type, typename Expr::value_type, Expr>
genFun(const Expr expr) 
{
  typedef typename Expr::value_type value_type;
  return ETUnFun<value_type, value_type, Expr>(expr);
}

template <class Expr>
ETUnFunDeriv<typename Expr::value_type, typename Expr::value_type, Expr>
genDeriv(const Expr expr) 
{
  typedef typename Expr::value_type value_type;
  return ETUnFunDeriv<value_type, value_type, Expr>(expr);
}


varType(Interval, ivar);
varType(double, dvar);


#define FUN0 (sqr(x) - 3.0*x)
#define FUN1 (power(x,4) - 12.0*power(x,3) + 47.0*sqr(x) - 60.0*x)
#define FUN2 (power(x,3) - 2.0*sqr(x) - 5.0*x + 6.0)
#define FUN3 (cosh(x)+10*sqr(x)*sqr(sin(x))-34)
#define FUN4 (sqr(sin(x)) - cos(sqr(x)))
#define FUN5 (power(x,7)-power(x,4)-12.0)
#define FUN6 ((power(x,4)-10.0*power(x,3)-13.0*sqr(x)+118.0*x+120.0)/(sqr(x)+2.0))
#define FUN7 ((sqr(x)-1.0)/(sqr(x)+1.0))

// real zero at x = -1.16715
#define FUN8 (0.33*power(x,3))

int main() 
{
  Interval::precision(5);
  cout << setprecision(5);


  XINewton<Interval> newton0;
  XINewton<Interval> newton1;
  XINewton<Interval> newton2;
  XINewton<Interval> newton3;
  XINewton<Interval> newton4;
  XINewton<Interval> newton5;
  XINewton<Interval> newton6;
  XINewton<Interval> newton7;
  
  ivar x;

  Interval xxx = FUN8.evalDeriv(Interval(1.0));
  cout << xxx << endl;
  xxx.bitImage(cout);
  
  Timer timer;

  timer.Start();
  for (int i=0; i<10000; i++) {
    //newton0.allZeros(genFun(FUN0), genDeriv(FUN0), Interval(-100, 100), 1e-15);
    newton1.allZeros(genFun(FUN1), genDeriv(FUN1), Interval(-100, 100), 1e-15);
    //newton2.allZeros(genFun(FUN2), genDeriv(FUN2), Interval(-100, 100), 1e-15);
    //newton3.allZeros(genFun(FUN3), genDeriv(FUN3), Interval(-100, 100), 1e-15);
    //newton4.allZeros(genFun(FUN4), genDeriv(FUN4), Interval(-10, 10), 1e-15);
    //newton5.allZeros(genFun(FUN5), genDeriv(FUN5), Interval(-100, 100), 1e-15);
    //newton6.allZeros(genFun(FUN8), genDeriv(FUN8), Interval(-100, 100), 1e-15);
    //newton7.allZeros(genFun(FUN7), genDeriv(FUN7), Interval(-100, 100), 1e-15); 
  }
  
  timer.Stop();
  
  
  //newton0.printZeros();
  newton1.printZeros();
  //newton2.printZeros();
  //newton3.printZeros();
  //newton4.printZeros();
  //newton5.printZeros();
  //newton6.printZeros();
  //newton7.printZeros();
  
  cout << timer.SecsElapsed() << " sec." << endl;

  return 0;
}






