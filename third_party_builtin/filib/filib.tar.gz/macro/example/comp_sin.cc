/*********************************************************************/
/*                                                                   */
/*   Example: comp_sin.cc (Computation of the sine function)         */
/*          (For copyright and info's see file "fi_lib.h")           */
/*                                                                   */
/*********************************************************************/

#include<iostream.h>
#include"Interval.h"

/* --- main program ------------------------------------------------------ */

int main()
{
  Interval x;

  Interval::precision(15);

  cout << endl;
  cout << "Computation of the sine function in C++ with fi_lib++" << endl;
  cout << "=====================================================" << endl;
  cout << endl;
  cout << "Insert an interval argument (e.g. '[1, 1]' or '[1.01, 1.02]')" << endl;
  cout << "x = ";
  cin >> x;
  cout << "Argument x = " << x << endl;
  cout << "    cos(x) = " << cos(x) << endl;
  cout << endl;

  return 0;
}
