#include <iomanip>
#include <vector>
#include <iostream>

#include "xinewton.h"
#include "Interval.h"

#include "../bench/Timer.h"

using namespace xinewton;


Interval f0(Interval x) {
  return sqr(x)-3.0*x;
}

Interval df0(Interval x) {
  return 2.0*x - 3.0;
}


// zeros at 0, 3, 4 and 5 (see C-XSC Toolbox p.111)
Interval f1(Interval x) {
  return power(x,4) - 12.0*power(x,3) + 47.0*sqr(x) - 60.0*x;
}

Interval df1(Interval x) {
  return 4.0*power(x, 3) - 36.0*sqr(x) + 94.0*x - 60.0;
}


// Zeros at -2, 1 and 3
Interval f2(Interval x) {
  return power(x,3) - 2*sqr(x) - 5*x + 6;
}

Interval df2(Interval x) {
  return 3*sqr(x) - 4*x - 5;
}


Interval f3(Interval x) {
  return ( cosh(x)+10*sqr(x)*sqr(sin(x))-34 );
}

Interval df3(Interval x) {
  return( sinh(x)+20*x*sqr(sin(x))+20*sqr(x)*sin(x)*cos(x) );
}


Interval f4(Interval x) {
  return sqr(sin(x)) - cos(sqr(x));  
}

Interval df4(Interval x) {
  return 2*cos(x)*sin(x) + 2*x*sin(sqr(x));
}


Interval f5(Interval x) {
  return power(x,7)-power(x,4)-12.0;
}

Interval df5(Interval x) {
  return 7*power(x,6)-4*power(x,3);
}

Interval f6(Interval x) {
  return (power(x,4)-10.0*power(x,3)-13.0*sqr(x)+118.0*x+120.0)/(sqr(x)+2.0);
}



Interval df6(Interval x) {
  return (4.0*power(x,3)-30.0*sqr(x)-26*x+118 - ((power(x,4)-10.0*power(x,3)-13.0*sqr(x)+118.0*x+120.0)/(sqr(x)+2.0))*2*x)/(sqr(x)+2);
}

// algebraisch vereinfachte Form:
//  Interval df6(Interval x) {
//    return (2*power(x,5)-10.0*power(x,4)+8.0*power(x,3)-178.0*sqr(x)-292.0*x+236.0)/(power(x,4)+4.0*sqr(x)+4.0);
//  }



Interval f7(Interval x) {
  return (sqr(x)-1.0)/(sqr(x)+1.0);
}

Interval df7(Interval x) {
  return (2.0*x - (sqr(x)-1.0)/(sqr(x)+1.0) * 2.0*x) / (sqr(x)+1.0);
}

int main() 
{
  using std::cout;

  Interval::precision(15);
  cout << setprecision(15);

  XINewton<Interval> newton0;
  XINewton<Interval> newton1;
  XINewton<Interval> newton2;
  XINewton<Interval> newton3;
  XINewton<Interval> newton4;
  XINewton<Interval> newton5;
  XINewton<Interval> newton6;
  XINewton<Interval> newton7;
  

  Timer timer;
  
  timer.Start();
  for (int i=0; i<10000; i++) {
    //newton0.allZeros(f0, df0, Interval(-100, 100), 1e-15);
    newton1.allZeros(f1, df1, Interval(-100, 100), 1e-15);
    //newton2.allZeros(f2, df2, Interval(-100, 100), 1e-15);
    //newton3.allZeros(f3, df3, Interval(-100, 100), 1e-15);
    //newton4.allZeros(f4, df4, Interval(-10, 10), 1e-15);
    //newton5.allZeros(f5, df5, Interval(-100, 100), 1e-15);
    //newton6.allZeros(f6, df6, Interval(-100, 100), 1e-15);
    //newton7.allZeros(f7, df7, Interval(-100, 100), 1e-15);
  }
    
  timer.Stop();

  //newton0.printZeros();
  newton1.printZeros();
  //newton2.printZeros();
  //newton3.printZeros();
  //newton4.printZeros();
  //newton5.printZeros();
  //newton6.printZeros();
  //newton7.printZeros();

  cout << timer.SecsElapsed() << " sec." << endl;

  return 0;
}




