/*                                                                           
**  fi_lib++  --- A fast interval library (Version 2.0)                     
**                                                                  
**  Copyright (C) 2001:                                                        
**                                                     
**  Werner Hofschuster, Walter Kraemer                               
**  Wissenschaftliches Rechnen/Softwaretechnologie (WRSWT)  
**  Universitaet Wuppertal, Germany                                           
**  Michael Lerch, German Tischler, Juergen Wolff von Gudenberg       
**  Institut fuer Informatik                                         
**  Universitaet Wuerzburg, Germany                                           
** 
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Library General Public
**  License as published by the Free Software Foundation; either
**  version 2 of the License, or (at your option) any later version.
**
**  This library is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
**  Library General Public License for more details.
**
**  You should have received a copy of the GNU Library General Public
**  License along with this library; if not, write to the Free
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
*/
#if ! defined(INTERVAL)
#define INTERVAL

#include <stdexcept>
#include <iostream>
#include <string>
#include <cmath>
#include <functional>
#include <algorithm>
#include <exception>

#include <fp_traits/fp_traits.hpp>
#include <ieee/primitive.hpp>
 
namespace filib
{
	template <typename N, rounding_strategy K>
	class interval;

	template < typename N, rounding_strategy K > interval<N,K> operator+  (
		interval<N,K> const & a,
		interval<N,K> const & b);
	template < typename N, rounding_strategy K > interval<N,K> operator+  (
		interval<N,K> const & a,
		N const & b);
	template < typename N, rounding_strategy K > interval<N,K> operator+  (
		N const & b,
		interval<N,K> const & a);

	template < typename N, rounding_strategy K > interval<N,K> operator-  (
		interval<N,K> const & a, 
		interval<N,K> const & b);
	template < typename N, rounding_strategy K > interval<N,K> operator-  (
		interval<N,K> const & a, 
		N const & b);
	template < typename N, rounding_strategy K > interval<N,K> operator-  (
		N const & b,
		interval<N,K> const & a);

	template < typename N, rounding_strategy K > interval<N,K> cancel (
		interval<N,K> const & a, 
		interval<N,K> const & b);

	template < typename N, rounding_strategy K > interval<N,K> operator*  (
		interval<N,K> const & a,
		interval<N,K> const & b);
	template < typename N, rounding_strategy K > interval<N,K> operator*  (
		interval<N,K> const & a,
		N const & b);
	template < typename N, rounding_strategy K > interval<N,K> operator*  (
		N const & b,
		interval<N,K> const & a);
		
	template < typename N, rounding_strategy K > interval<N,K> operator/  (
		interval<N,K> const & a,
		interval<N,K> const & b);
	template < typename N, rounding_strategy K > interval<N,K> operator/  (
		interval<N,K> const & a,
		N const & b);
	template < typename N, rounding_strategy K > interval<N,K> operator/  (
		N const & b,
		interval<N,K> const & a);

	/**
	 inf(a) == a.inf()
	 */
	template < typename N, rounding_strategy K > N const & inf (interval<N,K> const &);
	/**
	 sup(a) == a.sup()
	 */
	template < typename N, rounding_strategy K > N const & sup (interval<N,K> const &);
	/**
	 inf(a) == a.inf()
	 */
	template < typename N, rounding_strategy K > N inf_by_value (interval<N,K> const &);
	/**
	 sup(a) == a.sup()
	 */
	template < typename N, rounding_strategy K > N sup_by_value (interval<N,K> const &);
	/**
	 isPoint(a) == a.isPoint()
	 */
	template < typename N, rounding_strategy K > bool isPoint (interval<N,K> const &);	
	
	#if defined(FILIB_EXTENDED)
	/**
	 isInfinite(a) == a.isInfinite()
	 */
	template < typename N, rounding_strategy K > bool isInfinite (interval<N,K> const &);
	/**
	 isInfinite(a) == a.isInfinite()
	 */
	template < typename N, rounding_strategy K > bool isEmpty (interval<N,K> const &);			
	#endif
	
	/**
	 hasUlpAcc(a,n) == a.hasUlpAcc(n)
	 */
	template < typename N, rounding_strategy K > bool hasUlpAcc (interval<N,K> const &, unsigned int const &);
	/**
	 mid(a) == a.mid()
	 */
	template < typename N, rounding_strategy K > N mid(interval<N,K> const &);
	/**
	 diam(a) == a.diam()
	 */
	template < typename N, rounding_strategy K > N diam(interval<N,K> const &);
	template < typename N, rounding_strategy K > N width(interval<N,K> const &);
	/**
	 relDiam(a) == a.relDiam()
	 */
	template < typename N, rounding_strategy K > N relDiam(interval<N,K> const &);
	/**
	 rad(a) == a.rad()
	 */
	template < typename N, rounding_strategy K > N rad(interval<N,K> const &);
	/**
	 mig(a) == a.mig()
	 */
	template < typename N, rounding_strategy K > N mig(interval<N,K> const &);
	/**
	 mag(a) == a.mag()
	 */
	template < typename N, rounding_strategy K > N mag(interval<N,K> const &);
	/**
	 same as a.abs()
	 */
	template < typename N, rounding_strategy K > interval<N,K> abs(interval<N,K> const &);
	/**
	 Same as x.imin(y)
	*/
	template < typename N, rounding_strategy K > interval<N,K> imin(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.imax(y)
	*/
	template < typename N, rounding_strategy K > interval<N,K> imax(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.dist(y)
	*/
	template < typename N, rounding_strategy K > N dist(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.blow(eps)
	*/
	template < typename N, rounding_strategy K > interval<N,K> blow(interval<N,K> const & x, N const & eps);
	/**
	 Same as x.intersect(y)
	*/
	template < typename N, rounding_strategy K > interval<N,K>
	intersect(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.hull(y)
	*/
	template < typename N, rounding_strategy K > interval<N,K>
	hull(interval<N,K> const & x, interval<N,K> const & y);
	template < typename N, rounding_strategy K > interval<N,K>
	interval_hull(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as y.hull(x)
	*/
	template < typename N, rounding_strategy K > interval<N,K>
	hull(N const & x, interval<N,K> const & y);
	template < typename N, rounding_strategy K > interval<N,K>
	interval_hull(N const & x, interval<N,K> const & y);
	/**
	 Returns the convex hull of two double numbers x and y.

	 Special cases in the extended system:
	 <UL>
	 <LI> hull(x, y) == [ EMPTY ] for x == y == NaN
	 </UL>
	*/
	template < typename N, rounding_strategy K > interval<N,K>
	hull(N const & x, N const & y);
	template < typename N, rounding_strategy K > interval<N,K>
	interval_hull(N const & x, N const & y);
	/**
	 Same as x.disjoint(y)
	*/
	template < typename N, rounding_strategy K >
	bool disjoint(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Returns true iff double number x is contained in interval y
	
	 Special cases in the extended system:
	 <UL>
	 <LI> in(x, y) == false for x == NaN or y == [ EMPTY ]
	 </UL>
	*/
	template < typename N, rounding_strategy K >
	bool in(N const & x, interval<N,K> const & y);
	/**
	 Same as x.interior(y)
	*/
	template < typename N, rounding_strategy K >
	bool interior(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.proper_subset(y)
	*/
	template < typename N, rounding_strategy K >
	bool proper_subset(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.subset(y)
	*/
	template < typename N, rounding_strategy K >
	bool subset(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Returns true iff interval x is a subset of interval y.
	 @see #subset
	*/
	template < typename N, rounding_strategy K >
	bool operator <=(interval<N,K> const & x, interval<N,K> const & y);
 	/**
	 Same as x.proper_superset(y)
	*/
	template < typename N, rounding_strategy K >
	bool proper_superset(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.superset(y)
	*/
	template < typename N, rounding_strategy K >
	bool superset(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Returns true iff this interval x is a superset of interval y.
	 @see #superset
	*/
	template < typename N, rounding_strategy K >
	bool operator >=(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.seq(y)
	*/
	template < typename N, rounding_strategy K >
	bool seq(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Returns true iff intervals x and y are set-equal.
	 @see #seq
	*/
	template < typename N, rounding_strategy K >	
	bool operator ==(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.sne(y)
	*/
	template < typename N, rounding_strategy K >	
	bool sne(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Returns true iff interval x is set-not-equal to interval y.
	 @see #sne
	*/
	template < typename N, rounding_strategy K >	
	bool operator !=(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.sge(y)
	*/
	template < typename N, rounding_strategy K >	
	bool sge(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.sgt(y)
	*/
	template < typename N, rounding_strategy K >	
	bool sgt(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.sle(y)
	*/
	template < typename N, rounding_strategy K >	
	bool sle(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.slt(y)
	*/
	template < typename N, rounding_strategy K >	
	bool slt(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.ceq(y)
	*/
	template < typename N, rounding_strategy K >	
	bool ceq(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.cne(y)
	*/
	template < typename N, rounding_strategy K >	
	bool cne(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.cge(y)
	*/
	template < typename N, rounding_strategy K >	
	bool cge(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.cgt(y)
	*/
	template < typename N, rounding_strategy K >	
	bool cgt(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.cle(y)
	*/
	template < typename N, rounding_strategy K >	
	bool cle(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.clt(y)
	*/
	template < typename N, rounding_strategy K >	
	bool clt(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.peq(y)
	*/
	template < typename N, rounding_strategy K >	
	bool peq(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.pne(y)
	*/
	template < typename N, rounding_strategy K >	
	bool pne(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.pge(y)
	*/
	template < typename N, rounding_strategy K >	
	bool pge(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.pgt(y)
	*/
	template < typename N, rounding_strategy K >	
	bool pgt(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.ple(y)
	*/
	template < typename N, rounding_strategy K >	
	bool ple(interval<N,K> const & x, interval<N,K> const & y);
	/**
	 Same as x.plt(y)
	*/
	template < typename N, rounding_strategy K >	
	bool plt(interval<N,K> const & x, interval<N,K> const & y);

	/**
	 overload for stream o
	 */
	template < typename N, rounding_strategy K >
	std::ostream & operator <<(
		std::ostream & out,
		interval<N,K> const & a);
	template < typename N, rounding_strategy K >
	std::ostream & corebench_out(
		std::ostream & out,
		interval<N,K> const & a);
	/**
	 overload for stream i
	 */
	template < typename N, rounding_strategy K >
	std::istream & operator >>(
		std::istream & out,
		interval<N,K> & a)
	throw(interval_io_exception)
	;

	/**
	 Returns an interval enclosure of the inverse cosine of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> acos(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the inverse hyperbolic cosine of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> acosh(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the inverse cotangent of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> acot(interval<N,K> const & x);
  
	/**
	 Returns an interval enclosure of the inverse hyperbolic cotangent of 
	 the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> acoth(interval<N,K> const & x);
  
	/**
	 Returns an interval enclosure of the inverse sine of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> asin(interval<N,K> const & x);
	
	/**
	 Returns an interval enclosure of the inverse hyperbolic sine of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> asinh(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the inverse tangent of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> atan(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the inverse hyperbolic tangent of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> atanh(interval<N,K> const & x);
  
	/**
	 Returns an interval enclosure of the cosine of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K>  cos(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the hyperbolic cosine of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> cosh(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the cotangent of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K>  cot(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the hyperbolic cotangent of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> coth(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the exponential of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K>  exp(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the exponential (base 10) of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> exp10(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the exponential (base 2) of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> exp2(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of exp(x)-1
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> expm1(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the natural logarithm of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K>  log(interval<N,K> const & x);
  
	/**
	 Returns an interval enclosure of the logarithm (base 10) of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> log10(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of log(1+x).
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> log1p(interval<N,K> const & x);
  
	/**
	 Returns an interval enclosure of the logarithm (base 2) of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> log2(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of x^n.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> pow(interval<N,K> const & x, int const &);

	/**
	 Returns an interval enclosure of x^y = exp(y*log(x)).
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> power(interval<N,K> const & x, interval<N,K> const & y);

	/**
	 Returns an interval enclosure of the sine of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K>  sin(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the hyperbolic sine of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> sinh(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of x^2.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K>  sqr(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the square root of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> sqrt(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the tangent of the interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K>  tan(interval<N,K> const & x);

	/**
	 Returns an interval enclosure of the hyperbolic tangent of the 
	 interval x.
	*/
	template < typename N, rounding_strategy K >
	interval<N,K> tanh(interval<N,K> const & x);

	/**
	 template interval class
	 
	 template arguments:
	  N: arithmetic type
	  K: see rounding_control
	 */
	template <typename N = double, rounding_strategy K = native_switched >
	class interval
	{
		private:
			/* inner class for initialization of fp unit */
			struct interval_inner
			{
				interval_inner();
				inline void nop() const {}
			};

			static const interval_inner static_init;

		protected:
			/**
			 lower interval limit (infimum)
			 */
			N INF;
			/**
			 upper interval limit (supremum)
			 */
			N SUP;
	
		public:
			typedef N value_type;
			static const rounding_strategy rounding_type = K;
			typedef fp_traits<N,K> traits_type;

			/**
			 provided for internal reasons,
			 speed up construction where we don't
			 need the usual sanity checks
			 */
			inline explicit interval(
				N const & rl, N const & ru, char const &);

			inline interval(
				std::string const & infs, std::string const & sups)
			throw(interval_io_exception);

			#if defined(FILIB_EXTENDED)
			/**
			 check for infinity (?)
			 */
			inline void checkInf();
			#endif
			/**
			 default constructor,
			 don't use it if you are not the STL
			 */
			inline interval();

			/**
			 constructor for point interval
			 rp: point
			 */
			inline interval(N const & rp);

			/**
			 constructor by values
			 rl: infimum
			 ru: supremum
			 */
			inline interval(N const & rl, N const & ru);

			/**
			 copy constructor
			 */
			inline interval(interval<N,K> const & o);

			/**
			 destructor
			 */
			inline ~interval();

			/**
			 assignment operator
			 */
			inline interval<N,K> & operator= (interval<N,K> const & o);

			/**
			 unary operator +
			 */
			inline interval<N,K> const & operator+() const;

			/**
			 unary operator -
			 */
			inline interval<N,K> operator-() const;

			/**
			 return infimum
			 */
			inline N const & inf() const;

			/**
			 return supremum
			 */
			inline N const & sup() const;

			/**
			 unary +=
			 */
			inline interval<N,K> & operator +=(interval<N,K> const & o);

			/**
			 unary += for number
			 */
			inline interval<N,K> & operator +=(N const & a);

			/**
			 unary -=
			 */
			inline interval<N,K> & operator -=(interval<N,K> const & o);

			/**
			 unary -= for number
			 */
			inline interval<N,K> & operator -=(N const & a);

			/**
			 unary operator*=
			 */
			inline interval<N,K> & operator *= (interval<N,K> const & a);

			/**
			 unary operator *= for point
			 */
			inline interval<N,K> & operator *=(N const & a);

			/**
			 unary operator /=
			 */
			inline interval<N,K> & operator /= (interval<N,K> const & a);
			/**
			 unary operator /= for point
			 */
			inline interval<N,K> & operator/= (N const & a);

			/**
			 is this interval empty ?	
			 */
			#if defined(FILIB_EXTENDED)
			inline bool isEmpty() const;
			inline bool isInfinite() const;
			static inline interval<N,K> EMPTY();
			static inline interval<N,K> ENTIRE();
			static inline interval<N,K> NEG_INFTY();
			static inline interval<N,K> POS_INFTY();
			#endif

			static inline interval<N,K> ZERO();
			static inline interval<N,K> ONE();
			static inline interval<N,K> PI();

			inline bool isPoint() const;

			/**
			 Returns true iff this interval has an ulp accuracy of n, i.e. a.inf()
			 and a.sup() have a distance of at most n machine numbers.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.hasUlpAcc(n) == false for x == [ EMPTY ] or any infinite interval
			 </UL>
 			 */
			bool hasUlpAcc(unsigned int const & n) const;
			/**
			 true <-> defined(FILIB_EXTENDED)
			 */
			static bool isExtended();

			/**
			 Returns an approximation of the midpoint of this interval, i.e.
			
			 x.mid == (x.inf() + x.sup()) / 2.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.mid() == NaN for x == [ EMPTY ]
			 <LI> x.mid() == 0.0 for x == [ ENTIRE ]
			 <LI> x.mid() == +INF for x == [ +INF ] or x = [ a, +INF ]
			 <LI> x.mid() == -INF for x == [ -INF ] or x = [ -INF, a]
			 </UL>
			*/
			N mid() const;
 			/**
			 Returns an upper bound for the diameter (width) of this interval, i.e.
			
			 a.diam() == a.sup()-a.inf()
			
			 Special cases in the extended system:
			 <UL>
			 <LI> a.diam() == NaN for a == [ EMPTY ]
			 <LI> a.diam() == +INF for any infinite interval
			 </UL>
			*/
			N diam() const;
			N width() const;

			/**
			 Returns an upper bound for the relative diameter (width) of this
			 interval, i.e.
			
			 a.relDiam == a.diam() if a.mig() is less than the smallest normalized
			 number
			
			 a.relDiam == a.diam() / a.mig() else
			
			 Special cases in the extended system:
			 <UL>
			 <LI> a.relDiam() == NaN for a == [ EMPTY ]
			 <LI> a.relDiam() == +INF for any infinite interval
			 </UL>			
			*/
			N relDiam() const;

			/**
			 Returns an upper bound for the radius of this interval, i.e.
			
			 a.rad() = (a.sup() - a.inf()) / 2
			
			 Special cases in the extended system:
			 <UL>
			 <LI> a.rad() == NaN for a == [ EMPTY ]
			 <LI> a.rad() == +INF for any infinite interval
			 </UL>
			*/
			N rad() const;

			/**
			 Returns the mignitude of this interval, i.e.
			
			 a.mig() == min{abs(y) : y in x }
			
			 Special cases in the extended system:
			 <UL>
			 <LI> a.mig() == NaN for a == [ EMPTY ]
			 </UL>
			*/
			N mig() const;

			/**
			 Returns the magnitude of this interval, i.e.
			
			 a.mag() == max{abs(y) : y in a }
			
			 Special cases in the extended system:
			 <UL>
			 <LI> a.mag() == NaN for a == [ EMPTY ]
			 <LI> a.mag() == +INF for any infinite interval
			 </UL>
			*/
			N mag() const;

 			/**
			 Returns the interval of absolute values of this interval, i.e.
			
			 a.abs() == [ a.mig(), a.mag() ]
			
			 Special cases in the extended system:
			 <UL>
			 <LI> a.abs() == [ EMPTY ] for a == [ EMPTY ]
			 <LI> a.abs() == [ +INF ] for a == [ +/- INF ]
			 </UL>
			*/
			interval<N,K> abs() const;

			/**
			 Returns an enclosure for the range of minima of this interval and the
			 interval x, i.e.
			
			 x.min(y) == { z : z == min(a, b) : a in x, b in y }
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.min(y) == [ EMPTY ] for x == [ EMPTY ] and y == [ EMPTY ]
			 </UL>
			*/
			interval<N,K> imin(interval<N,K> const & x) const;

			/**
			 Returns an enclosure for the range of maxima of this interval and the
			 interval x, i.e.
			
			 x.max(y) == { z : z == max(a, b) : a in x, b in y }
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.max(y) == [ EMPTY ] for x == [ EMPTY ] and y == [ EMPTY ]
			 </UL>
			*/
			interval<N,K> imax(interval<N,K> const & x) const;

			/**
			 Returns an upper bound for the Hausdorff distance of this interval
			 and the interval x, i.e.
			
			 x.dist(y) == max{ abs(x.inf()-y.inf()), abs(x.sup() - y.sup()) }
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.dist(y) == NaN for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			N dist(interval<N,K> const & x) const;

			/**
			 Returns this interval inflated by eps, i.e.
			
			 x.blow(eps) == (1 + eps)*x - eps*x
			*/
			interval<N,K> blow(N const & eps) const;

 			/**
			 Returns the intersection of this interval and the interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.intersect(y) == [ EMPTY ] iff x and y are disjoint
			 </UL>
			*/
			interval<N,K> intersect(interval<N,K> const & x) const;
 
			/**
			 Returns the convex hull of this interval and the interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.hull(y) == [ EMPTY ] for x == y == [ EMPTY ]
			 </UL>
			*/
			interval<N,K> hull(interval<N,K> const & x) const;
			interval<N,K> interval_hull(interval<N,K> const & x) const;

			/**
			 Returns the convex hull of this interval and the double x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.hull(y) == [ EMPTY ] for x == [ EMPTY ] and y == NaN
			 </UL>
			*/
			interval<N,K> hull(N const & x) const;
			interval<N,K> interval_hull(N const & x) const;

			/**
			 Returns true iff this interval and interval x are disjoint., i.e.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.disjoint(y) == true for x or y == [ EMPTY ]
			 </UL>
			*/
			bool disjoint(interval<N,K> const & x) const;

			/**
			 Returns true iff double number x is contained in this interval.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.contains(y) == false for x == [ EMPTY ] or y == NaN
			 </UL>
			*/
			bool contains(N x) const;

			/**
			 Returns true iff this interval is in interior of interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.interior(y) == true for x == [ EMPTY ]
			 </UL>
			*/
			bool interior(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is a proper subset of interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.proper_subset(y) == true for x == [ EMPTY ] and y != [ EMPTY ]
			 </UL>
			*/
			bool proper_subset(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is a subset of interval x.
			 Special cases in the extended system:
			
			 <UL>
			 <LI> x.subset(y) == true for x == [ EMPTY ]
			 </UL>
			*/
			bool subset(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is a proper superset of interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.proper_superset(y) == true for x != [ EMPTY ] and y == [ EMPTY ]
			 </UL>
			*/
			bool proper_superset(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is a superset of interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.superset(y) == true for y == [ EMPTY ]
			 </UL>
			*/
			bool superset(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is set-equal to interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.seq(y) == true for x == y == [ EMPTY ]
			 </UL>
			*/
			bool seq(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is set-not-equal to interval x.
			*/
			bool sne(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is set-greater-or-equal to
			 interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.sge(y) == true for x == y == [ EMPTY ]
			 </UL>
			*/
			bool sge(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is set-greater than interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.sgt(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool sgt(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is set-less-or-equal to
			 interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.sle(y) == true for x == y == [ EMPTY ]
			 </UL>
			*/
			bool sle(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is set-less than interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.slt(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool slt(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is certainly-equal to interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.ceq(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool ceq(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is certainly-not-equal to interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.cne(y) == true for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool cne(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is certainly-greater-or-equal to
			 interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.cge(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool cge(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is certainly-greater than interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.cgt(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>a
			*/
			bool cgt(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is certainly-less-or-equal to
			 interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.cle(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool cle(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is certainly-less than interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.clt(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool clt(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is possibly-equal to interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.peq(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool peq(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is possibly-not-equal to interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.pne(y) == true for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool pne(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is possibly-greater-or-equal to
			 interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.pge(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool pge(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is possibly-greater than interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.pgt(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool pgt(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is possibly-less-or-equal to
			 interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.ple(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool ple(interval<N,K> const & x) const;

			/**
			 Returns true iff this interval is possibly-less than interval x.
			
			 Special cases in the extended system:
			 <UL>
			 <LI> x.plt(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
			 </UL>
			*/
			bool plt(interval<N,K> const & x) const;

			/**
			 print a binary representation of the interval
			 */
			std::ostream & bitImage(std::ostream & os) const;
			/**
			 print a hex representation of the interval
			 */
			std::ostream & hexImage(std::ostream & os) const;

			#if 0
			friend 
			filib::interval<N,K> 
				filib::operator+ <N,K> 
			(
				filib::interval<N,K> const & a,
				filib::interval<N,K> const & b
			);
			#endif

			#if 0
			friend interval<N,K> operator+ <N,K> (
				interval<N,K> const & a,
				N const & b);
			friend interval<N,K> operator+ <N,K> (
				N const & b,
				interval<N,K> const & a);
			#endif

			/**
			 get current output precision
			 */
			static int const & precision();
			/**
			 set output precision and return old precision
			 */
			static int precision (int const &);
			/*
			 amin, compute min(|INF|,|SUP|)
			 */
			inline N amin() const;
			/*
			 amax, compute max(|INF|,|SUP|)
			 */
			inline N amax() const;

			static interval<N,K> readBitImage(std::istream &) 
				throw(interval_io_exception);
			static interval<N,K> readHexImage(std::istream &) 
				throw(interval_io_exception);
	};

	template <typename N, rounding_strategy K>
	typename interval<N,K>::interval_inner const interval<N,K>::static_init;
}

#include <interval/tools.icc>
#include <interval/interval.icc>
#include <interval/filib.hpp>
#include <interval/interval_fo.hpp>

#endif
