#if ! defined(STRTOD_H)
extern "C" double bsd_strtod(const char *s00, char **se);
extern "C" char *bsd__dtoa(double d, int mode, int ndigits, int *decpt, int *sign, char **rve, char **resultp);
#endif
