#include "Interval.h"
#include "autodiff.h"


template<>
class MCT<Interval, Interval>
{
public:
  typedef Interval value_type;
};

template<>
class MCT<Interval, double>
{
public:
  typedef Interval value_type;
};


template<>
class MCT<double, Interval>
{
public:
  typedef Interval value_type;
};

template<> 
class TypePrinter<Interval>
{
public:
  static void printType(ostream &os) 
  {
    os << "Interval";
  }
};


inline double sqr(double x) 
{
  return x*x;
}


varType(Interval, ivar);
varType(double, dvar);


int main() 
{
  Interval a(-0.1, 0.1);
  
  ivar x; 
  dvar y,z;
  

  cout << (y).evalDeriv(a) << endl;
  
  
  (((x-1.0)*a) / -(a-sqr(x)+1.5/x)).evalDeriv(1.0);
  (((x-1.0)*a) / -(a-sqr(x)+1.5/x)).evalDeriv(a);
  (((y-1.0)*a) / -(a-sqr(y)+1.5/y)).evalDeriv(1.0);
  (((y-1.0)*a) / -(a-sqr(y)+1.5/y)).evalDeriv(a);

  return 0;
}
