//
// TODO
//
// Def.Param. f�r ForwardContainer = vector<Interval>
//
// Interface f�r allZeros so, da� autodiff verwendendet werden kann, aber 
// gleichzeitig auch Fkt.zeiger
//
//

#ifndef _XINEWTON_H
#define _XINEWTON_H

#include <stack>
#include <vector>

#include "xinterval.h"

namespace xinewton 
{

// -------------------------------------------------------------------------
// DEBUGGING
// 
// If XINEWTON_DEBUG is defined, details of the computations in
// allZeros is written to the file 'xinewto.deb'
// -------------------------------------------------------------------------
#ifdef XINEWTON_DEBUG
#include <fstream>
ofstream dout("xinewton.deb");
#endif



// -------------------------------------------------------------------------
// Class Enclosure<Interval>
//
// Class to describe general enclosures.
// -------------------------------------------------------------------------
template <typename Interval>
class Enclosure 
{
public:
  Interval x;  // the enclosure
  bool unique; // uniqueness information
};



// -------------------------------------------------------------------------
// Function verificationStep(f, df, zero)
//
// Try to verify a found enclosure 'zero'.
// -------------------------------------------------------------------------
template <class UnaryFunction1, 
          class UnaryFunction2,
          class Interval>
void verificationStep(UnaryFunction1 f, UnaryFunction2 df,
		      Enclosure<Interval> &zero) 
{
  const int kmax = 10; 
  int k = 0;

  Interval xIn = zero.x;
  Interval xOld, dfx;
  
  double c;
  double eps = 0.25;
  
  while (!zero.unique && k < kmax) {
    xOld = blow(zero.x, eps);
    dfx = df(zero.x); 
    if (in(0.0, dfx)) 
      break;
    k++;
    c = mid(xOld);
    zero.x = c - f(c) / dfx;
    if (disjoint(zero.x, xOld)) 
      break;
    zero.unique = interior(zero.x, xOld);
    zero.x = intersect(zero.x, xOld);
    if (zero.x == xOld) 
      eps=eps*8.0;
  }
  
  if (!zero.unique) 
    zero.x = xIn;
}



// -------------------------------------------------------------------------
// Function tryBisect(x, y, c) 
//
// Try to bisect interval 'x' at its midpoint 'c'. Returns true iff the 
// bisection was actually performed.
//
// The bisection
//   x = [ inf(x), c ]
//   y = [ c, sup(x) ]
// is performed only if c lies in the interior of x.
// -------------------------------------------------------------------------

template <class Interval>
bool tryBisect(Interval &x, Interval &y, double c) {
  if (c == x.inf() || c == x.sup())
    return false;
  else {
    y = Interval(c, x.sup());
    x = Interval(x.inf(), c);
    return true;
  }
}



// -------------------------------------------------------------------------
// Function allZeros(f, df, x, eps, list, maxZeros)
//
// Takes an interval function 'f' and its derivative 'df' and tries to 
// enclose all zeros of 'f' in the start interval 'x'. The enclosures are 
// stored in increasing order in 'list'. The relative accuracy of the 
// method is given by the parameter 'eps'. An upper bound 'maxZeros' of 
// zeros to be found can be given.
//
// The function returns an error code:
//   xinNoError: no error occured.
//   xinNotAllZerosFound: method stopped due to the user limit 'maxZeros'.
//   xinAccuracyUnfeasable: the given accuracy could not be reached.
// Several errors are combined with logical and.
// -------------------------------------------------------------------------

enum XINewtonError { xinNoError, xinNotAllZerosFound, 
		     xinAccuracyUnfeasable };


template <class UnaryFunction1, 
          class UnaryFunction2, 
          class Interval, 
          class ForwardContainer>
XINewtonError allZeros(UnaryFunction1 f, UnaryFunction2 df,
		       Interval x, double eps,
		       ForwardContainer &list,
		       unsigned int maxZeros = UINT_MAX) 
{
#ifdef XINEWTON_DEBUG
  dout << endl
       << "----------------------" << endl
       << "Start of newton method" << endl
       << "----------------------" << endl << endl;
#endif

  XINewtonError errorCode = xinNoError;

  bool stop, maxAccuracy;

  unsigned int numZeros = 0;

  Interval V1, V2;
  ExtIntersectInfo info;  
  XInterval<Interval> z;
  double c;

  Enclosure<Interval> zero;
  bool unique;

  // initialize stack of work intervals with starting interval x
  stack<Interval> work;
  work.push(x);

  // adjust eps if necessary
  if (eps <= 0.0) {
    eps = 1e-15;

#ifdef XINEWTON_DEBUG
    dout << "eps <= 0.0 ! Adjusting it to 1e-15." << endl << endl;
#endif
  
  }
  
  
  // main loop
  while (!work.empty()) {

    if (numZeros == maxZeros) {
      
#ifdef XINEWTON_DEBUG
      dout << "Maximum number of " << maxZeros << " zeros reached. " 
	   << "Method stopped." << endl << endl;
#endif    

      errorCode = xinNotAllZerosFound;
      break;
    }
    

    stop = false;
    maxAccuracy = false;
    unique = false;

#ifdef XINEWTON_DEBUG
    bool stagnated = false;
#endif
    
    // get next interval from stack
    x = work.top();
    work.pop();

#ifdef XINEWTON_DEBUG
    dout << endl
	 << endl << "New search interval from stack" << endl
	 << "------------------------------" << endl
	 << "x = " << x << endl;
    x.bitImage(dout);
    dout << endl;
#endif

    // Newton iteration
    while (in(0.0, f(x)) && relDiam(x) > eps && !stop && !maxAccuracy) {
	
      // Newton step
      c = mid(x);
      z = c - f(c) % df(x);
      info = extIntersect(x, z, V1, V2);

#ifdef XINEWTON_DEBUG
      dout << endl << "Next Newton step:" << endl
	   << "-----------------" << endl
	   << "x        = " << x << endl
	   << "mid(x)   = " << c << endl;
      Double::bitImage(c, dout);
      dout << "f(mid(x))= " << f(c) << endl
	   << "df(x)    = " << df(x) << endl
	   << "N(x) & x = V1 | V2 with" << endl
	   << "V1       = ";
      if (info == EmptyIntv)
	dout << "[ EMPTY ]" << endl;
      else
	dout << V1 << endl;
      dout << "V2       = ";
      if (info != DoubleIntv)
	dout << "[ EMPTY ]" << endl;
      else
	dout << V2 << endl;
#endif

      // stagnation => try bisection
      if (info != eiEmptyInterval) {
	if (V1 == x) {

#ifdef XINEWTON_DEBUG
	  stagnated = true;
#endif
	  maxAccuracy = !tryBisect(V1, V2, c);
	  if (!maxAccuracy)
	    info = eiDoubleInterval;
	}

	else if (info != eiSingleInterval && V2 == x) {

#ifdef XINEWTON_DEBUG
	  stagnated = true;
#endif

	  maxAccuracy = !tryBisect(V2, V1, c);
	  if (!maxAccuracy)
	    info = eiDoubleInterval;
	}
      }
	
      else {

	// V1 and V2 are empty. Nevertheless, x may contain a zero, if x
	// is (partially) outside the domain of f 
	  
	if (in(0.0, f(x))) {
	  // Try bisection then.
	    
#ifdef XINEWTON_DEBUG
	  dout << endl 
	       << "V1 and V2 are empty, but 0.0 in f(x). Trying bisection."
	       << endl;
#endif	    

	  V1 = x;
	  if (tryBisect(V1, V2, c)) {
	    info = eiDoubleInterval;

#ifdef XINEWTON_DEBUG
	    dout << endl
		 << "Bisection succsessfull. New values:" << endl
		 << "V1 = " << V1 << endl 
		 << "V2 = " << V2 << endl;
#endif

	  }
	  else
	    maxAccuracy = true;
	}
      }
	

#ifdef XINEWTON_DEBUG
      if (stagnated)
	dout << endl 
	     <<"Newton iteration stagnated. Trying bisection." << endl;
#endif

      // stop iteration if maximum accuracy is reached
      if (maxAccuracy) {
#ifdef XINEWTON_DEBUG
	dout << endl
	     << "STOP: bisection not successfull because maximum accuracy "
	     << "is reached." << endl;
	stagnated = false;
#endif
	errorCode = xinAccuracyUnfeasable;
	continue;
      }

      else {

#ifdef XINEWTON_DEBUG
	if (stagnated) {
	  dout << endl
	       << "Bisection successfull. New values:" << endl
	       << "V1 = " << V1 << endl 
	       << "V2 = " << V2 << endl;
	  stagnated = false;
	}
#endif
	  
      }
	
      if (info == eiEmptyInterval) {
	// both V1 and V2 are empty !
	stop = true;

#ifdef XINEWTON_DEBUG
	dout << endl 
	     << "STOP: no zero found since both V1 and V2 are empty." 
	     << endl << "f(x) = " << f(x)
	     << endl;
#endif	  

      }

      else {
	if (info == eiDoubleInterval) {

#ifdef XINEWTON_DEBUG
	  dout << endl 
	       << "Pushing V2 on work stack." << endl;
	    
#endif

	  work.push(V2);
	  unique = false;
	}

	else 
	  unique = unique || interior(V1, x);
	  
	x = V1;
      }
	
#ifdef XINEWTON_DEBUG
      if (relDiam(x) <= eps)
	dout << endl 
	     << "STOP: desired accuracy reached." << endl;
#endif

    }
      
    // if a zero was found, add to the list 
    if (!stop && in(0.0, f(x))) {

#ifdef XINEWTON_DEBUG
      dout << endl
	   << "Zero found in x = " << x << endl;
      x.bitImage(dout);
      dout << "f(x) = " << f(x) << endl;
#endif

      zero.x = x;
      zero.unique = unique;
	
      if (list.empty()) {
	list.push_back(zero);
	numZeros++;

#ifdef XINEWTON_DEBUG
	dout << endl << "First zero in list." << endl;
#endif
      }
	
      else {

#ifdef XINEWTON_DEBUG
	dout << endl << "Trying to absorb new zero." << endl;
#endif
	  
	// try to absorb x by the last element in list
	if (!disjoint(list.back().x, zero.x)) {
	  list.back().x = hull(list.back().x, zero.x);
	  list.back().unique = false;
	    
#ifdef XINEWTON_DEBUG
	  dout << "Absorbed." << endl
	       << "new last zero: " << list.back().x << endl;
#endif
	}
	  
	else {
	  list.push_back(zero);
	  numZeros++;

#ifdef XINEWTON_DEBUG
	  dout << endl << "Not absorbed." << endl;
#endif

	}
	  
      }
    }

#ifdef XINEWTON_DEBUG
    else 
      dout << endl
	   << x << " contains no zero." << endl;
#endif

  }

  // verification
  typename ForwardContainer::iterator iter = list.begin();
  while (iter != list.end()) {
    if (!iter->unique) 
      verificationStep(f, df, *iter);
    iter++;
  }

  return errorCode;
}


// -------------------------------------------------------------------------
// Function reduceEnclosures(list, redList)
//
// Takes a 'list' of enclosures and produces a reduced list 'redList' in  
// which redundant enclosures are removed.
// A unique enclosure x is redundant if there exists a unique enclosure y
// and y is a subset of x.
//
// The function returns the number of unique enclosures in 'redList'.
// -------------------------------------------------------------------------  
template <class List>
int reduceEnclosures(const List &list, List &redList) 
{
  int unique = 0;

  typename List::const_iterator iter, redIter;
 
  bool isSuperSet;
  
  iter = list.begin();
  while (iter != list.end()) {
    if (iter->unique) {
      isSuperSet = false;
      redIter = list.begin();
      while (redIter != list.end()) {
	if (redIter != iter && redIter->unique)
	  isSuperSet = isSuperSet || superset(iter->x, redIter->x);
	redIter++;
      }
      if (!isSuperSet) {
	redList.push_back(*iter);
	unique++;
      }
    }
    else 
      redList.push_back(*iter);
    iter++;
  }

  return unique;
}


template <class Interval>
class XINewton 
{
public:
  typedef std::vector<Enclosure<Interval> > EnclosureList;

  // ----------------------------------------------------------------------
  // Default ctor
  // ----------------------------------------------------------------------
  XINewton() 
    : errorCode(xinNoError), unique(0) { }

  // ----------------------------------------------------------------------
  // Computes all zeros of an interval function 'f' with derivative 'df'
  // in the interval 'start' with relative accuracy 'eps'.
  // ----------------------------------------------------------------------
  template<class UnaryFunction1, class UnaryFunction2>
  void allZeros(UnaryFunction1 f, UnaryFunction2 df, 
		Interval start, double eps = 1e-15,
		unsigned int maxZeros = UINT_MAX) 
  {
    list.clear();
    EnclosureList tmpList;
    errorCode = xinewton::allZeros(f, df, start, eps, tmpList, maxZeros);
    unique = reduceEnclosures(tmpList, list);
  }

  // ----------------------------------------------------------------------
  // Returns the list of computed enclosures.
  // ----------------------------------------------------------------------
  EnclosureList &getEnclosures()
  {
    return list;
  }

  // ----------------------------------------------------------------------
  // Returns the number of computed enclosures.
  // ----------------------------------------------------------------------
  int getNumEnclosures() 
  {
    return list.size();
  }
  
  // ----------------------------------------------------------------------
  // Returns the number of computed unique enclosures.
  // ----------------------------------------------------------------------
  int getNumUniqueEnclosures() 
  {
    return unique;
  }
  
  // ----------------------------------------------------------------------
  // Prints the computed enclosures.
  // ----------------------------------------------------------------------
  void printZeros(bool showBits = false, ostream &os = cout) const 
  {
    vector<Enclosure<Interval> >::const_iterator iter;
    
    os << endl;

    int i=1;
    for (iter = list.begin(); iter != list.end(); iter++) {
      os << i++ << ": " << iter->x;
      os << endl;
      (iter->x).bitImage(os);
      if (iter->unique) 
	os << " contains a unique zero." << endl;
      else 
	os << " may contain a zero." << endl;
    }
    cout << endl;
    printDiagnostic(os);
  }

  // ----------------------------------------------------------------------
  // Prints a diagnostic message.
  // ----------------------------------------------------------------------
  void printDiagnostic(ostream &os = cout) const
  {
    os << list.size() << " enclosure(s) computed." << endl;
    
    if (list.size() == 0)
      os << endl 
	 << "The function is prooved to contain no zero "
	 << "in the search interval." << endl;
    else
      os << unique << " prooved unique zero(s) found." << endl;
    
    if (errorCode & xinNotAllZerosFound)
      os << endl 
	 << "Not all zeros were found due to the given user limit." << endl;
    if (errorCode & xinAccuracyUnfeasable)
      os << endl 
	 <<"The given accuracy could not be reached for all enclosures."
	 << endl;
    
    os  << endl;
  }

private:
  EnclosureList list;
  XINewtonError errorCode;
  int unique;  
  
};


  
  
}



#endif
