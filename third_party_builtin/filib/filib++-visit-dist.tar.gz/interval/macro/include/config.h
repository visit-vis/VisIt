#ifndef _FILIB_CONFIG_H
#define _FILIB_CONFIG_H

// -----------------------------------------------------------------------
// Specifiy the endianess of your machine. PC's usually are little endian
// and workstations big endian.
// -----------------------------------------------------------------------
#define	FILIB_LITTLE_ENDIAN	1234
#define	FILIB_BIG_ENDIAN	4321

// for PC's
#define FILIB_BYTE_ORDER FILIB_LITTLE_ENDIAN

// for workstations 
//#define FILIB_BYTE_ORDER FILIB_BIG_ENDIAN

// -----------------------------------------------------------------------
// Define PRED_SUCC_TABLES to make fi_lib++ to use table driven versions
// for pred and succ. In general these are a little bit faster.
// -----------------------------------------------------------------------
//#define FILIB_PRED_SUCC_TABLES

// -----------------------------------------------------------------------
// Define FILIB_EXTENDED to use the extended interval system ("Simple" 
// system). Otherwise error messages will be launched in indeterminate
// cases (see also FILIB_EXIT_ON_ERROR).
// In the extended system the special intervals [ EMPTY ], [ ENTIRE ],
// [ -INF ] and [ +INF ] are provided.
// -----------------------------------------------------------------------
#if defined(FILIB_EXTENDED)
#undef FILIB_EXTENDED
#endif

#if ! defined(FILIB_COMPILE_NO_EXTENDED)
#define FILIB_EXTENDED
#else
#warning "Explicitely compiling non-extended."
#endif

// -----------------------------------------------------------------------
// Define FILIB_NATIVE_ROUNDING to use native directed rounding instead
// of portable "rounding" via pred()/succ().
// Native rounding is provided only for a limited range of machines and
// compilers (see file include/rounding.h).
// ----------------------------------------------------------------------- 
#define FILIB_NATIVE_ROUNDING 

// Define FILIB_NO_ROUNDING to test the achievable performance for rounde operations
#define FILIB_NO_ROUNDING

// Define FILIB_ONESIDE  global setting of rone directed rounding mode
//#define FILIB_ONESIDED


// -----------------------------------------------------------------------
// Define FILIB_ENSURE_ROUND_NEAR to ensure rounding to nearest after
// each interval operation. This makes sense only if native rounding is
// chosen.
// -----------------------------------------------------------------------
//#define FILIB_ENSURE_ROUND_NEAR
 
// -----------------------------------------------------------------------
// Define FILIB_MULT_ROUNDING to use portable directed rounding by
//  multiplication with pred(1) succ(1). round to nearest is mandatory for
//  this mode
#define FILIB_MULT_ROUNDING 

// -----------------------------------------------------------------------
// Define FILIB_INLINE_ARITH if interval arithmetic operators should be 
// expanded inline.
// -----------------------------------------------------------------------
#define FILIB_INLINE_ARITH

// -----------------------------------------------------------------------
// Define FILIB_INLINE_ALL if all interval functions should be expanded 
// inline, including arithmetic operations.
// -----------------------------------------------------------------------
#define FILIB_INLINE_ALL

// -----------------------------------------------------------------------
// Define FILIB_INTERVAL_BY_VALUE if interval arguments should be passed 
// to methods and functions of the library by value. 
// If FILIB_INTERVAL_BY_VALUE is not defined, intervals arguments will be
// passed by const &.  
// -----------------------------------------------------------------------
#define FILIB_INTERVAL_BY_VALUE

// -----------------------------------------------------------------------
// Define FILIB_USE_LIBI77_IO if the runtime library of the interval GNU
// Fortan compiler should be used for interval I/O.
// (See http://www.eecs.lehigh.edu/~mschulte/compiler)
// In addition, the environment variable FILIB_FORTRANIO must be defined
// to correctly link to libI77.a which is expected to be found in the lib
// subdirectory. 
// -----------------------------------------------------------------------
//#define FILIB_USE_LIBI77_IO


// -----------------------------------------------------------------------
// Define FILIB_EXIT_ON_ERROR if the library should exit on errors (e.g. 
// division by zero) in non-extended mode. (There are no error situations
// in extended mode.) If FILIB_EXIT_ON_ERROR is not defined, only 
// diagnostic messages will be given in exceptional situations. The result
// of an operation is undefined in this case and should not be used for
// further computations. Thus FILIB_EXIT_ON_ERROR is recommended for non-
// extended mode.
// -----------------------------------------------------------------------
#define FILIB_EXIT_ON_ERROR

// -----------------------------------------------------------------------
// Define FILIB_STD_HEADERS if the compiler uses the C++ standard header 
// file names, e.g. <iostream> instead of <iostream.h>. 
// -----------------------------------------------------------------------
#define FILIB_STD_HEADERS


// -----------------------------------------------------------------------
// Define FILIB_NAMESPACES if all interval stuff should be placed in 
// namespace filib.
// -----------------------------------------------------------------------
#define FILIB_NAMESPACES


#endif







