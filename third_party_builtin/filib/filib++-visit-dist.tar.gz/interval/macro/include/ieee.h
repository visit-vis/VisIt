#ifndef _FILIB_IEEE_H
#define _FILIB_IEEE_H

#include "config.h"
#include "global.h"

#include <iostream>
#include <string>
#include <exception>
#include <stdexcept>
#include <vector>

#ifdef FILIB_STD_HEADERS
#include <iosfwd>
#else
#include <iostream.h>
#endif

#ifdef FILIB_NAMESPACES
namespace filib
{
#endif

class Double
{
public:
  // -----------------------------------------------------------------------
  // Special numbers
  // -----------------------------------------------------------------------
  static double MIN()
  {
    return min;
  }
  
  static double MIN_NORM() 
  {
    return minNorm;
  }
  
  static double MAX()
  {
      return max;
  }

  static double POS_INFTY() 
  {
    return posInf;
  }
  
  static double NEG_INFTY() 
  {
    return negInf;
  }

  static double QUIET_NAN() 
  {
    return qNaN;
  }

  // -----------------------------------------------------------------------
  // Tests
  // -----------------------------------------------------------------------
  static bool isInfinite(double x) 
  {
    a_diee y;
    y.f = x;
    return y.ieee.expo == 0x7FF && y.ieee.mant0 == 0 && y.ieee.mant1 == 0;
  }
  
  static bool isNaN(double x) 
  {
    return x != x;
    
//  #ifdef __KCC
//      // workaround for optimization bug in KCC 3.4; 
//      // x != x will be optimized away !
//      a_diee y;
//      y.f = x;
//      return y.ieee.expo == 0x7FF && (y.ieee.mant0 != 0 || y.ieee.mant1 != 0);
//  #else
//      return x != x;
//  #endif
  }

  static bool isRegular(double x) 
  {
    return !(isInfinite(x) || isNaN(x));
  }
  
  // -----------------------------------------------------------------------
  // Utility functions
  // -----------------------------------------------------------------------
  static int sign(double x) 
  {
    a_diee y;
    y.f = x;
    return y.ieee.sign;
  }
  
  static double abs(double x) 
  {
    a_diee y;
    y.f = x;
    y.ieee.sign = 0;
    x = y.f;

    return x;
  }

  static double compose(unsigned int sign, unsigned int expo,
			unsigned int mantUpper, unsigned int mantLower)
  {
    a_diee f;
    f.ieee.sign  = sign;
    f.ieee.expo  = expo;
    f.ieee.mant0 = mantUpper;
    f.ieee.mant1 = mantLower;

    return f.f;
  }

  static void decompose(double x,
			unsigned int &sign, unsigned int &expo,
			unsigned int &mantUpper, unsigned int &mantLower)
  {
    a_diee f;
    f.f = x;
    sign      = f.ieee.sign;
    expo      = f.ieee.expo;
    mantUpper = f.ieee.mant0;
    mantLower = f.ieee.mant1;
  }

  static double ulp(double x) {
      if (isInfinite(x))
        return POS_INFTY();
      if (isNaN(x))
	return x;

      a_diee ulpx;
      ulpx.f = x;
      ulpx.ieee.sign = 0;
      
      // x is zero or denormalized
      if (ulpx.ieee.expo == 0) {
	ulpx.ieee.mant0 = 0;
	ulpx.ieee.mant1 = 1;
	return ulpx.f;
      }
      
      // non-underflow case
      if (ulpx.ieee.expo > 52) {
	ulpx.ieee.expo -= 52;
        ulpx.ieee.mant0 = 0;
	ulpx.ieee.mant1 = 0;
	return ulpx.f;
      }

      // underflow
      int n = 52-ulpx.ieee.expo;
      ulpx.ieee.expo = 0;
      if (n < 20) {
	ulpx.ieee.mant0 = (0x80000 >> n);
	ulpx.ieee.mant1 = 0;
      }
      else {
	ulpx.ieee.mant0 = 0;
	ulpx.ieee.mant1 = (0x80000000 >> (n-20));
      }
      return ulpx.f;
  }

  // -----------------------------------------------------------------------
  // I/O
  // -----------------------------------------------------------------------
  static void print(double x, std::ostream &os);
  static void bitImage(double x, std::ostream &os);
  
  // -----------------------------------------------------------------------
  // predecessor and successor of a number
  // -----------------------------------------------------------------------

    // modified version of pred from original fi_lib
  static double basic_pred(double y) 
  {  
    a_diee su;
    
    su.f=y;
    if (su.ieee.sign==1) {   /*  y < 0 */
      if (su.ieee.expo != 2047)
	if (su.ieee.mant1==0xffffffff) { 
	  su.ieee.mant1=0; 
	  if (su.ieee.mant0==0xfffff) { 
	    su.ieee.mant0=0; 
	    su.ieee.expo++;
	  } else { 
	    su.ieee.mant0++;
	  }
	} else { 
	  su.ieee.mant1++;
	}
    }
    
    else {                 /* y >= 0 */
      if (su.ieee.expo != 2047) {
	if (su.ieee.sign==0 && su.ieee.expo==0 & su.ieee.mant0==0 && su.ieee.mant1==0) {
	  su.ieee.sign=1;
	  su.ieee.mant1=1;
	} 
	else {
	  if (su.ieee.mant1==0) { 
	    su.ieee.mant1=0xffffffff; 
	    if (su.ieee.mant0==0) {
	      su.ieee.mant0=0xfffff; 
	      su.ieee.expo--;
	    } else { 
	      su.ieee.mant0--;
	    }
	  } else { 
	    su.ieee.mant1--;
	  }
	}
      }
      else if (su.ieee.mant0 == 0 && su.ieee.mant1 == 0) {
	// y == +inf
	su.ieee.expo = 2046;
	su.ieee.mant0 = 0xfffff;
	su.ieee.mant1 = 0xffffffff;
      }
    }
    
    return su.f;
  }
  
  // modified version of succ from original fi_lib
  static double basic_succ(double y)
  {
    a_diee su;
    
    su.f=y;
    if (su.ieee.sign==0) {   /*  y >= 0 */
      if (su.ieee.expo!=2047) {
	if (su.ieee.mant1==0xffffffff) { 
	  su.ieee.mant1=0; 
	  if (su.ieee.mant0==1048575) { 
	    su.ieee.mant0=0; 
	    su.ieee.expo++;
	  } else { 
	    su.ieee.mant0++;
	  }
	} else { 
	  su.ieee.mant1++;
	}
      }
    } else {                  /* y < 0 */
      if (su.ieee.expo!=2047) {
	if (su.ieee.sign==1 && su.ieee.expo==0 & su.ieee.mant0==0 && su.ieee.mant1==0) {
	  su.ieee.sign=0;
	  su.ieee.mant1=1;
	} else {
	  if (su.ieee.mant1==0) { 
	    su.ieee.mant1=0xffffffff; 
	    if (su.ieee.mant0==0) { 
	      su.ieee.mant0=1048575; 
	      su.ieee.expo--;
	    } else { 
	      su.ieee.mant0--;
	    }
	  } else { 
	    su.ieee.mant1--;
	  }
	}
      }
      else if (su.ieee.mant0 == 0 && su.ieee.mant1 == 0) {
	// y == -inf
	su.ieee.expo = 2046;
	su.ieee.mant0 = 0xfffff;
	su.ieee.mant1 = 0xffffffff;
      }
      
    }
    
    return su.f;
  }
  

#ifdef FILIB_PRED_SUCC_TABLES
  static double pred(double x)
  { 
    a_diee f;
    f.f = x;

    unsigned int index = f.ieee.expo;

    if (f.ieee.sign == 0) {
      if (f.ieee.mant1 == 0 && f.ieee.mant0 == 0)
	if (f.ieee.expo == 2047)
	  // special case: positive infinity
	  return MAX();
	else if (f.ieee.expo != 0)
	  // special case: positive powers of 2
	  index--;
    }
     
    else if (f.ieee.expo == 0x7FE && f.ieee.mant0 == 0xFFFFF 
	     && f.ieee.mant1 == 0xFFFFFFFF)
      // special case: -max
      return NEG_INFTY();
    
    return x-psTable.ULP[index];
  }
  
  static double succ(double x)
  { 
    a_diee f;
    f.f = x;

    unsigned int index = f.ieee.expo;

    if (f.ieee.sign == 1) {
      if (f.ieee.mant1 == 0 && f.ieee.mant0 == 0)
	if (f.ieee.expo == 2047)
	  // special case: negative infinity
	  return -MAX();
	else if (f.ieee.expo != 0)
	  // special case: positive powers of 2
	  index--;
    }
    
    else if (f.ieee.expo == 0x7FE && f.ieee.mant0 == 0xFFFFF 
	     && f.ieee.mant1 == 0xFFFFFFFF)
      // special case: max
      return POS_INFTY();
    
    return x+psTable.ULP[index];
  }
#else

  static double pred(double x) 
  {
    return basic_pred(x);
  }

  static double succ(double x) 
  {
    return basic_succ(x);
  }
#endif  

  // -----------------------------------------------------------------------
  // Platform dependent code for FPU initialization
  // -----------------------------------------------------------------------
  
  class FPUStartUp 
  {
  public:
    FPUStartUp();
  };
  
  

private:
  friend class Interval;

  static double min, minNorm, max, posInf, negInf, qNaN;

  static double computeMin();
  static double computeMinNorm();
  static double computeMax();
  static double computePosInf();
  static double computeNegInf();
  static double computeQNaN();

  static FPUStartUp startup;

  static void basicBitImage(double d, std::ostream &os);

  // -----------------------------------------------------------------------
  // pred/succ stuff
  // -----------------------------------------------------------------------

  // for table version of pred and succ
#ifdef FILIB_PRED_SUCC_TABLES
  class PredSuccTable 
  {
  public:
    PredSuccTable();
    ~PredSuccTable();
    double *ULP;
  };
  
  static PredSuccTable psTable;
  
  friend class PredSuccTable;
#endif

};

// for compatibility with original fi_lib

#define q_pred(x) Double::pred(x)
#define q_succ(x) Double::succ(x)
#define r_pred(x) Double::pred(x)
#define r_succ(x) Double::succ(x)


template<size_t n0>
std::vector<unsigned char> readBitSet(std::istream & in) throw(std::runtime_error)
{
	std::vector<unsigned char> s;
	size_t n = n0;

	while ( n-- )
	{
		char c = in.get();
		
		if ( in.good() )
		{
			if ( c == '0' )
				s.push_back(0);
			else if ( c == '1' )
				s.push_back(1);
			else
			{
				in.putback(c);
				throw std::runtime_error("unexpected character while reading bitstring");
			}
		}
		else
			throw std::runtime_error("stream bad while reading bitstring");
	}
	
	return s;
}

template <char c0>
void readChar(std::istream& in) throw(std::runtime_error)
{
	char c = in.get();
		
	if ( c != c0 )
	{
		in.putback(c);
		throw std::runtime_error("unexpected char in readChar");
	}
}


template <typename N>
N constructFromBitSet(std::istream & in) throw(std::runtime_error)
{
	throw std::runtime_error("constructFromBitSet() called for unsupported type");
}

template<typename WS>
void eatWS(std::istream & in)
{
	char c = in.get();

	while ( in.good()  && WS::isSpace(c) )
		c = in.get();

	in.putback(c);
}


template<typename T>
struct whitespace
{
	static int isSpace(int);
};

template <>
double constructFromBitSet<double>(std::istream & in) throw(std::runtime_error);
template<>
int whitespace<char>::isSpace(int arg);

#ifdef FILIB_NAMESPACES
}
#endif

#endif
  







