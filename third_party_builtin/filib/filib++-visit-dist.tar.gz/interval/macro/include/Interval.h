#ifndef _FILIB_INTERVAL_H
#define _FILIB_INTERVAL_H

#include "config.h"

#ifdef FILIB_STD_HEADERS
  #include <iosfwd>
  #include <algorithm> // min, max
#else
  #include <iostream.h>

  template <class T>
  inline const T& min(const T& a, const T& b) {
    return b < a ? b : a;
  }

  template <class T>
  inline const T& max(const T& a, const T& b) {
    return  a < b ? b : a;
  }
#endif


#include "ieee.h"
#include "rounding.h"


#ifdef FILIB_INTERVAL_BY_VALUE
  #define INTV_ARG Interval
#else
  #define INTV_ARG const Interval &
#endif

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

/**
 * Class for representation of intervals X = [a, b]. a and b are double 
 * precision floation point numbers with a <= b. 
 *
 * Two different interval systems can be used:
 *
 * The elements of the regular interval system (IR) are intervals with regular 
 * IEEE floating point number bounds. An infinite interval or an interval
 * with NaN as one of its bounds doesn't belong to this system and indicates 
 * an exeptional situation. Arithmetic on these intervals is undefined and
 * can cause the library to stop with an error message.    
 *
 * In the closed ("extended") interval system (IR*) the set of regular 
 * intervals IR is extended by infinite intervals and the empty interval.
 * All arithmetic operations and mathematical functions are closed on IR*.
 * For details see the paper 
 * <a href="http://www.mscs.mu.edu/~globsol/Papers/supersetec.ps">
 * Interval Arithmetic Specification</a> by Chiriaev and Walster. The 
 * implementation is following this supersetecification.  
 * The extended interval system is used by defining the makro FILIB_EXTENDED.
 * Three supersetecial intervals are supported in the extended system:
 * <UL>
 * <LI> [ EMPTY ], represented as [ NaN, NaN ]
 * <LI> [ -INF ], represented as [ -INF, -MAX ]
 * <LI> [ +INF ], represented as [ MAX, +INF] 
 * </UL>
 * where MAX is the largest regular floating point number. All interval 
 * operations are guaranteed to produce results consistent with these 
 * representations.
 * 
 * Independent of the interval system, two different types of directed
 * roundings can be used.
 *
 * A portable version simulates directed rounding by using functions for  
 * computing the predecessor and the successor of a floating point number. 
 * This is essentially the semantics of the ANSI-C library fi_lib.  
 *
 * Native (machine and compiler dependent) rounding can be activated by 
 * defining the makro FILIB_NATIVE_ROUNDING. It is generally faster and 
 * yields sharper results. At the moment, only Intel-PC's running Linux and
 * GNU C++, EGCS or KAI C++ are supported.
 *
 * The semantics of the original fi_lib is obtained if neither 
 * FILIB_EXTENDED nor FILIB_NATIVE_ROUNDING is defined.
 */

class Interval 
{
  double INF;
  double SUP;

  // private, unchecked constructors for internal use 
  Interval(bool, bool, bool) { }

  Interval(double x, double y, bool) 
    : INF(x), SUP(y) { }
      
  
#ifdef FILIB_EXTENDED
  void checkInf();
#endif
  
public:

  // -----------------------------------------------------------------------
  // Constructors
  // -----------------------------------------------------------------------

  /**
   * Constructs a point interval.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> if x == +INF then [ +INF ] is constructed
   * <LI> if x == -INF then [ -INF ] is constructed
   * <LI> if x == NaN then [ EMPTY ] is constructed
   * </UL>
   */
  Interval(double x = 0.0);
    
  /**
   * Constructs the interval [inf, sup]. 
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> if inf == sup == -INF the interval [ -INF ] is constructed
   * <LI> if inf == sup == +INF the interval [ +INF ] is constructed
   * <LI> if inf < sup then the interval [ EMPTY ] is constructed
   * <LI> if inf == NaN or sup == NaN then [ EMPTY ] is constructed
   * </UL>
   *
   * @param inf The infimum of the interval to be constructed.
   * @param sup The supremum of the interval to be constructed.
   */
  Interval(double inf, double sup);
  
  // -----------------------------------------------------------------------
  // Interval bounds 
  // -----------------------------------------------------------------------

  /**
   * Returns the infimum of this interval. 
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.inf() == NaN for x == [ EMPTY ] 
   * <LI> x.inf() == MAX_DOUBLE for x == [ +INF ]
   * </UL> 
   */
  double inf() const;

  /**
   * Same as x.inf()
   */
  friend
  double inf(INTV_ARG x);
  
  /**
   * Returns the supremum of this interval. 
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.sup() == NaN for x == [ EMPTY ] 
   * <LI> x.sup() == MAX_DOUBLE for x == [ +INF ]
   * </UL> 
   */
  double sup() const;

  /**
   * Same as x.sup()
   */
  friend
  double sup(INTV_ARG x);

  // -----------------------------------------------------------------------
  // Info functions 
  // -----------------------------------------------------------------------

  /**
   * Returns true iff this interval is a point interval, i.e. inf() == sup().
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.isPoint() == false for x == [ EMPTY ] 
   * </UL> 
   */
  bool isPoint() const;

  /**
   * Same as x.isPoint()
   */
  friend
  bool isPoint(INTV_ARG x);


#ifdef FILIB_EXTENDED

  /**
   * Returns true if this == [ EMPTY ]. Only supported in the extended 
   * system.
   */
  bool isEmpty() const;

  /**
   * Same as x.isEmpty(). Only supported in the extended system.
   */
  friend
  bool isEmpty(INTV_ARG x);

  /**
   * Return true if either x.inf() or x.sup() is infinite. Only supported 
   * in the extended system.
   */
  bool isInfinite() const;
  
  /**
   * Same as x.isInfinite(). Only supported in the extended system.
   */
  friend
  bool isInfinite(INTV_ARG x);
#endif

  /**
   * Returns true iff this interval has an ulp accuracy of n, i.e. x.inf() 
   * and x.sup() have a distance of at most n machine numbers.  
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.hasUlpAcc(n) == false for x == [ EMPTY ] or any infinite interval 
   * </UL> 
   */
  bool hasUlpAcc(unsigned int n) const;

  /**
   * Same as x.hasUlpAcc()
   */
  friend
  bool hasUlpAcc(INTV_ARG x, unsigned int n);

  /**
   * Returns true iff the extended system is currently used.
   */
  static bool isExtended();
  
  // -----------------------------------------------------------------------
  // Utility functions 
  // -----------------------------------------------------------------------
 
  /**
   * Returns an approximation of the midpoint of this interval, i.e.
   * 
   * x.mid == (x.inf() + x.sup()) / 2.
   * 
   * Special cases in the extended system:
   * <UL>
   * <LI> x.mid() == NaN for x == [ EMPTY ] 
   * <LI> x.mid() == 0.0 for x == [ ENTIRE ]
   * <LI> x.mid() == +INF for x == [ +INF ] or x = [ a, +INF ]
   * <LI> x.mid() == -INF for x == [ -INF ] or x = [ -INF, a]
   * </UL> 
   */
  double mid() const;

  /**
   * Same as x.mid()
   */
  friend
  double mid(INTV_ARG x);

  /**
   * Returns an upper bound for the diameter (width) of this interval, i.e.
   * 
   * x.diam() == x.sup()-x.inf()
   * 
   * Special cases in the extended system:
   * <UL>
   * <LI> x.diam() == NaN for x == [ EMPTY ] 
   * <LI> x.diam() == +INF for any infinite interval
   * </UL> 
   */
  double diam() const;

  /**
   * Same as x.diam()
   */
  friend 
  double diam(INTV_ARG x);

  /**
   * Returns an upper bound for the relative diameter (width) of this 
   * interval, i.e.
   * 
   * x.relDiam == x.diam() if x.mig() is less than the smallest normalized 
   * number
   *
   * x.relDiam == x.diam() / x.mig() else
   * 
   * Special cases in the extended system:
   * <UL>
   * <LI> x.relDiam() == NaN for x == [ EMPTY ] 
   * <LI> x.relDiam() == +INF for any infinite interval
   * </UL>
   *  
   */
  double relDiam() const;

  /**
   * Same as x.relDiam()
   */
  friend 
  double relDiam(INTV_ARG x);

  /**
   * Returns an upper bound for the radius of this interval, i.e.
   *
   * x.rad() = (x.sup() - x.inf()) / 2
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.rad() == NaN for x == [ EMPTY ] 
   * <LI> x.rad() == +INF for any infinite interval
   * </UL>
   */
  double rad() const;

  /**
   * Same as x.rad()
   */
  friend
  double rad(INTV_ARG x);

  /**
   * Returns the mignitude of this interval, i.e.
   *
   * x.mig() == min{abs(y) : y in x }
   * 
   * Special cases in the extended system:
   * <UL>
   * <LI> x.mig() == NaN for x == [ EMPTY ] 
   * </UL>
   */
  double mig() const;

  /**
   * Same as x.mig()
   */
  friend 
  double mig(INTV_ARG x);

  /** 
   * Returns the magnitude of this interval, i.e.
   *
   * x.mag() == max{abs(y) : y in x }
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.mag() == NaN for x == [ EMPTY ] 
   * <LI> x.mag() == +INF for any infinite interval
   * </UL>
   */
  double mag() const;

  /**
   * Same as x.mag()
   */
  friend
  double mag(INTV_ARG x);

  /**
   * Returns the interval of absolute values of this interval, i.e.
   *
   * x.abs() == [ x.mig(), x.mag() ]
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.abs() == [ EMPTY ] for x == [ EMPTY ] 
   * <LI> x.abs() == [ +INF ] for x == [ +/- INF ]
   * </UL>
   */
  Interval abs() const;

  /**
   * Same as x.abs()
   */
  friend
  Interval abs(INTV_ARG x);

  /**
   * Returns an enclosure for the range of minima of this interval and the 
   * interval x, i.e.
   *
   * x.min(y) == { z : z == min(a, b) : a in x, b in y }
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.min(y) == [ EMPTY ] for x == [ EMPTY ] and y == [ EMPTY ] 
   * </UL>
   */
  Interval imin(INTV_ARG x) const;

  /**
   * Same as x.imin(y)
   */
  friend
  Interval imin(INTV_ARG x,  INTV_ARG y);

  /**
   * Returns an enclosure for the range of maxima of this interval and the 
   * interval x, i.e.
   *
   * x.max(y) == { z : z == max(a, b) : a in x, b in y }
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.max(y) == [ EMPTY ] for x == [ EMPTY ] and y == [ EMPTY ]
   * </UL>
   */
  Interval imax(INTV_ARG x) const;

  /**
   * Same as x.imax(y)
   */
  friend
  Interval imax(INTV_ARG x,  INTV_ARG y);

  /**
   * Returns an upper bound for the Hausdorff distance of this interval 
   * and the interval x, i.e.
   *
   * x.dist(y) == max{ abs(x.inf()-y.inf()), abs(x.sup() - y.sup()) }
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.dist(y) == NaN for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  double dist(INTV_ARG x) const;

  /**
   * Same as x.dist(y)
   */
  friend
  double dist(INTV_ARG x, INTV_ARG y);

  /**
   * Returns this interval inflated by eps, i.e.
   *
   * x.blow(eps) == (1 + eps)*x - eps*x
   */
  Interval blow(double eps) const;

  /**
   * Same as x.blow(eps)
   */
  friend
  Interval blow(INTV_ARG x, double eps);

  // -----------------------------------------------------------------------
  // Set operations
  // -----------------------------------------------------------------------

  /** 
   * Returns the intersection of this interval and the interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.intersect(y) == [ EMPTY ] iff x and y are disjoint
   * </UL>
   */
  Interval intersect(INTV_ARG x) const;

  /**
   * Same as x.intersect(y)
   */
  friend
  Interval intersect(INTV_ARG x, INTV_ARG y);

  /**
   * Returns the convex hull of this interval and the interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.hull(y) == [ EMPTY ] for x == y == [ EMPTY ]
   * </UL>
   */
  Interval hull(INTV_ARG x) const;

  /**
   * Same as x.hull(y)
   */
  friend
  Interval hull(INTV_ARG x, INTV_ARG y);
  
  /**
   * Returns the convex hull of this interval and the double x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.hull(y) == [ EMPTY ] for x == [ EMPTY ] and y == NaN
   * </UL>
   */
  Interval hull(double x) const;

  /**
   * Same as x.hull(y)
   */
  friend
  Interval hull(INTV_ARG x, double y);

  /**
   * Same as y.hull(x)
   */
  friend
  Interval hull(double x, INTV_ARG y);

  /**
   * Returns the convex hull of two double numbers x and y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> hull(x, y) == [ EMPTY ] for x == y == NaN
   * </UL>
   */
  friend
  Interval hull(double x, double y);

  // -----------------------------------------------------------------------
  // Set relations
  // -----------------------------------------------------------------------
  
  /**
   * Returns true iff this interval and interval x are disjoint., i.e.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.disjoint(y) == true for x or y == [ EMPTY ]
   * </UL>
   */
  bool disjoint(INTV_ARG x) const;

  /**
   * Same as x.disjoint(y)
   */
  friend
  bool disjoint(INTV_ARG x, INTV_ARG y);
  
  /**
   * Returns true iff double number x is contained in this interval.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.contains(y) == false for x == [ EMPTY ] or y == NaN
   * </UL>
   */
  bool contains(double x) const;

  /**
   * Returns true iff double number x is contained in interval y
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> in(x, y) == false for x == NaN or y == [ EMPTY ] 
   * </UL>
   */
  friend
  bool in(double x, INTV_ARG y);
  
  /** 
   * Returns true iff this interval is in interior of interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.interior(y) == true for x == [ EMPTY ] 
   * </UL>
   */
  bool interior(INTV_ARG x) const;

  /**
   * Same as x.interior(y)
   */
  friend
  bool interior(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is a proper subset of interval x.
   * 
   * Special cases in the extended system:
   * <UL>
   * <LI> x.proper_subset(y) == true for x == [ EMPTY ] and y != [ EMPTY ] 
   * </UL>
   */
  bool proper_subset(INTV_ARG x) const;

  /**
   * Same as x.proper_subset(y)
   */
  friend
  bool proper_subset(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is a subset of interval x.
   * Special cases in the extended system:
   *
   * <UL>
   * <LI> x.subset(y) == true for x == [ EMPTY ] 
   * </UL>   
   */
  bool subset(INTV_ARG x) const;
  
  /**
   * Same as x.subset(y)
   */
  friend
  bool subset(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff interval x is a subset of interval y.
   * @see #subset
   */
  friend
  bool operator <=(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is a proper superset of interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.proper_superset(y) == true for x != [ EMPTY ] and y == [ EMPTY ] 
   * </UL>
   */
  bool proper_superset(INTV_ARG x) const;

  /**
   * Same as x.proper_superset(y)
   */
  friend
  bool proper_superset(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is a superset of interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.superset(y) == true for y == [ EMPTY ] 
   * </UL>
   */
  bool superset(INTV_ARG x) const;
  
  /**
   * Same as x.superset(y)
   */
  friend
  bool superset(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval x is a superset of interval y.
   * @see #superset
   */
  friend
  bool operator >=(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is set-equal to interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.seq(y) == true for x == y == [ EMPTY ] 
   * </UL>
   */
  bool seq(INTV_ARG x) const;
  
  /**
   * Same as x.seq(y)
   */
  friend
  bool seq(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff intervals x and y are set-equal.
   * @see #seq
   */
  friend
  bool operator ==(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is set-not-equal to interval x.
   */
  bool sne(INTV_ARG x) const;

  /**
   * Same as x.sne(y)
   */ 
  friend
  bool sne(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff interval x is set-not-equal to interval y.
   * @see #sne
   */  
  friend
  bool operator !=(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is set-greater-or-equal to 
   * interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.sge(y) == true for x == y == [ EMPTY ] 
   * </UL>
   */
  bool sge(INTV_ARG x) const;

  /**
   * Same as x.sge(y)
   */ 
  friend
  bool sge(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is set-greater than interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.sgt(y) == false for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool sgt(INTV_ARG x) const;
  
  /**
   * Same as x.sgt(y)
   */ 
  friend
  bool sgt(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is set-less-or-equal to 
   * interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.sle(y) == true for x == y == [ EMPTY ] 
   * </UL>
   */
  bool sle(INTV_ARG x) const;

  /**
   * Same as x.sle(y)
   */
  friend
  bool sle(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is set-less than interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.slt(y) == false for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool slt(INTV_ARG x) const;
  
  /**
   * Same as x.slt(y)
   */
  friend
  bool slt(INTV_ARG x, INTV_ARG y);

  // -----------------------------------------------------------------------
  // Certainly relations
  // -----------------------------------------------------------------------
  
  /**
   * Returns true iff this interval is certainly-equal to interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.ceq(y) == false for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool ceq(INTV_ARG x) const;

  /**
   * Same as x.ceq(y)
   */
  friend
  bool ceq(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is certainly-not-equal to interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.cne(y) == true for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool cne(INTV_ARG x) const;

  /**
   * Same as x.cne(y)
   */
  friend
  bool cne(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is certainly-greater-or-equal to 
   * interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.cge(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  bool cge(INTV_ARG x) const;

  /**
   * Same as x.cge(y)
   */ 
  friend
  bool cge(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is certainly-greater than interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.cgt(y) == false for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool cgt(INTV_ARG x) const;

  /**
   * Same as x.cgt(y)
   */
  friend
  bool cgt(INTV_ARG x, INTV_ARG y);
  
  /**
   * Returns true iff this interval is certainly-less-or-equal to 
   * interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.cle(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  bool cle(INTV_ARG x) const;

  /**
   * Same as x.cle(y)
   */
  friend
  bool cle(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is certainly-less than interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.clt(y) == false for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool clt(INTV_ARG x) const;

  /**
   * Same as x.clt(y)
   */
  friend
  bool clt(INTV_ARG x, INTV_ARG y);

  // -----------------------------------------------------------------------
  // Possibly relations
  // -----------------------------------------------------------------------
  
  /**
   * Returns true iff this interval is possibly-equal to interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.peq(y) == false for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool peq(INTV_ARG x) const;

  /**
   * Same as x.peq(y)
   */
  friend
  bool peq(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is possibly-not-equal to interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.pne(y) == true for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool pne(INTV_ARG x) const;

  /**
   * Same as x.pne(y)
   */
  friend
  bool pne(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is possibly-greater-or-equal to 
   * interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.pge(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  bool pge(INTV_ARG x) const;

  /**
   * Same as x.pge(y)
   */
  friend
  bool pge(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is possibly-greater than interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.pgt(y) == false for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool pgt(INTV_ARG x) const;

  /**
   * Same as x.pgt(y)
   */
  friend
  bool pgt(INTV_ARG x, INTV_ARG y);
  
  /**
   * Returns true iff this interval is possibly-less-or-equal to 
   * interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.ple(y) == false for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  bool ple(INTV_ARG x) const;

  /**
   * Same as x.ple(y)
   */
  friend
  bool ple(INTV_ARG x, INTV_ARG y);

  /**
   * Returns true iff this interval is possibly-less than interval x.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x.plt(y) == false for x == [ EMPTY ] or y == [ EMPTY ] 
   * </UL>
   */
  bool plt(INTV_ARG x) const;

  /**
   * Same as x.plt(y)
   */
  friend
  bool plt(INTV_ARG x, INTV_ARG y);

  // -----------------------------------------------------------------------
  // Arithmetic operations
  // -----------------------------------------------------------------------
  
  /**
   * Unary operator +. Returns this interval.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> +x == [ EMPTY ] for x == [ EMPTY ]
   * </UL>
   */
  const Interval &operator +() const; 

  /** 
   * Unary operator -. Returns this interval multiplied by -1.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> -x == [ EMPTY ] for x == [ EMPTY ]
   * </UL>
   */
  Interval operator -() const; 

  /**
   * Adds interval x to this interval and returns the sum.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x += y == [ EMPTY ] for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  Interval &operator +=(INTV_ARG x);

  /**
   * Adds double number x to this interval and returns the sum.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x += y == [ EMPTY ] for x == [ EMPTY ] or y == NaN
   * </UL>
   */
  Interval &operator +=(double x); 

  /**
   * Subtracts interval x from this interval and returns the difference.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x -= y == [ EMPTY ] for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  Interval &operator -=(INTV_ARG x); 

  /**
   * Subtracts double number x from this interval and returns the difference.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x -= y == [ EMPTY ] for x == [ EMPTY ] or y == NaN
   * </UL>
   */
  Interval &operator -=(double x); 

  /**
   * Multiplies this interval by interval x and returns the product.
   *
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x *= y == [ EMPTY ] for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  Interval &operator *=(INTV_ARG x);


  /**
   * Multiplies this interval by double number x and returns the product.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x *= y == [ EMPTY ] for x == [ EMPTY ] or y == NaN
   * </UL>
   */
  Interval &operator *=(double x); 
  
  /**
   * Divides this interval by interval x and returns the quotient.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x /= y == [ EMPTY ] for x == [ EMPTY ] or y == [ EMPTY ]
   * <LI> x /= y == [ ENTIRE ] if y contains 0
   * </UL>
   */
  Interval &operator /=(INTV_ARG x); 

  /**
   * Divides this interval by double number x and returns the quotient.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x /= y == [ EMPTY ] for x == [ EMPTY ] or y == NaN
   * <LI> x /= y == [ ENTIRE ] if y == 0
   * </UL>
   */
  Interval &operator /=(double x); 

  /**
   * Returns x + y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x + y == [ EMPTY ] for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  friend Interval operator +(INTV_ARG x, INTV_ARG y);
  
  /**
   * Returns x + y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x + y == [ EMPTY ] for x == [ EMPTY ] or y == NaN
   * </UL>
   */
  friend Interval operator +(INTV_ARG x, double y); 

  /**
   * Returns x + y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x + y == [ EMPTY ] for x == NaN or y == [ EMPTY ]
   * </UL>
   */
  friend Interval operator +(double x, INTV_ARG y); 

  /**
   * Returns x - y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x - y == [ EMPTY ] for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  friend Interval operator -(INTV_ARG x, INTV_ARG y); 

  /**
   * Returns x - y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x - y == [ EMPTY ] for x == [ EMPTY ] or y == NaN
   * </UL>
   */
  friend Interval operator -(INTV_ARG x, double y);

  /**
   * Returns x - y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x - y == [ EMPTY ] for x == NaN or y == [ EMPTY ]
   * </UL>
   */
  friend Interval operator -(double x, INTV_ARG y);

  /**
   * Returns x * y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x * y == [ EMPTY ] for x == [ EMPTY ] or y == [ EMPTY ]
   * </UL>
   */
  friend Interval operator *(INTV_ARG x, INTV_ARG y);

  /**
   * Returns x * y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x * y == [ EMPTY ] for x == [ EMPTY ] or y == NaN
   * </UL>
   */
  friend Interval operator *(INTV_ARG x, double y); 

  /**
   * Returns x * y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x * y == [ EMPTY ] for x == NaN or y == [ EMPTY ]
   * </UL>
   */
  friend Interval operator *(double x, INTV_ARG y); 

  /**
   * Returns x / y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x / y == [ EMPTY ] for x == [ EMPTY ] or y == [ EMPTY ]
   * <LI> x / y == [ ENTIRE ] if y contains 0
   * </UL>
   */
  friend Interval operator /(INTV_ARG x, INTV_ARG y); 

  /**
   * Returns x / y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x / y == [ EMPTY ] for x == [ EMPTY ] or y == NaN
   * <LI> x / y == [ ENTIRE ] if y == 0
   * </UL>
   */
  friend Interval operator /(INTV_ARG x, double y); 

  /**
   * Returns x / y.
   *
   * Special cases in the extended system:
   * <UL>
   * <LI> x / y == [ EMPTY ] for x == NaN or y == [ EMPTY ]
   * <LI> x / y == [ ENTIRE ] if y contains 0
   * </UL>
   */
  friend Interval operator /(double x, INTV_ARG y);

  
  // -----------------------------------------------------------------------
  // Elementary functions
  // -----------------------------------------------------------------------

  /**
   * Returns an interval enclosure of the inverse cosine of the interval x.
   */
  friend Interval acos(Interval x);

  /**
   * Returns an interval enclosure of the inverse hyperbolic cosine of the 
   * interval x.
   */
  friend Interval acosh(Interval x);

  /**
   * Returns an interval enclosure of the inverse cotangent of the 
   * interval x.
   */
  friend Interval acot(Interval x);
  
  /**
   * Returns an interval enclosure of the inverse hyperbolic cotangent of 
   * the interval x.
   */
  friend Interval acoth(Interval x);
  
  /**
   * Returns an interval enclosure of the inverse sine of the interval x.
   */
  friend Interval asin(Interval x);

  /**
   * Returns an interval enclosure of the inverse hyperbolic sine of the 
   * interval x.
   */
  friend Interval asinh(Interval x);

  /**
   * Returns an interval enclosure of the inverse tangent of the interval x.
   */
  friend Interval atan(Interval x);

  /**
   * Returns an interval enclosure of the inverse hyperbolic tangent of the 
   * interval x.
   */
  friend Interval atanh(Interval x);
  
  /**
   * Returns an interval enclosure of the cosine of the interval x.
   */
  friend Interval  cos(Interval x);

  /**
   * Returns an interval enclosure of the hyperbolic cosine of the interval x.
   */
  friend Interval cosh(Interval x);

  /**
   * Returns an interval enclosure of the cotangent of the interval x.
   */
  friend Interval  cot(Interval x);

  /**
   * Returns an interval enclosure of the hyperbolic cotangent of the 
   * interval x.
   */
  friend Interval coth(Interval x);

  /**
   * Returns an interval enclosure of the exponential of the interval x.
   */
  friend Interval  exp(Interval x);

  /**
   * Returns an interval enclosure of the exponential (base 10) of the 
   * interval x.
   */
  friend Interval exp10(Interval x);

  /**
   * Returns an interval enclosure of the exponential (base 2) of the 
   * interval x.
   */
  friend Interval exp2(Interval x);

  /**
   * Returns an interval enclosure of exp(x)-1
   */
  friend Interval expm1(Interval x);

  /**
   * Returns an interval enclosure of the natural logarithm of the 
   * interval x.
   */
  friend Interval  log(Interval x);
  
  /**
   * Returns an interval enclosure of the logarithm (base 10) of the 
   * interval x.
   */
  friend Interval log10(Interval x);

  /**
   * Returns an interval enclosure of log(1+x).
   */
  friend Interval log1p(Interval x);
  
  /**
   * Returns an interval enclosure of the logarithm (base 2) of the 
   * interval x.
   */
  friend Interval log2(Interval x);

  /**
   * Returns an interval enclosure of x^n.
   */
  friend Interval power(Interval x, int);

  /**
   * Returns an interval enclosure of x^y = exp(y*log(x)).
   */
  friend Interval pow(Interval x, Interval y);

  /**
   * Returns an interval enclosure of the sine of the interval x.
   */
  friend Interval  sin(Interval x);

  /**
   * Returns an interval enclosure of the hyperbolic sine of the interval x.
   */
  friend Interval sinh(Interval x);

  /**
   * Returns an interval enclosure of x^2.
   */
  friend Interval  sqr(Interval x);

  /**
   * Returns an interval enclosure of the square root of the interval x.
   */
  friend Interval sqrt(Interval x);

  /**
   * Returns an interval enclosure of the tangent of the interval x.
   */
  friend Interval  tan(Interval x);

  /**
   * Returns an interval enclosure of the hyperbolic tangent of the 
   * interval x.
   */
  friend Interval tanh(Interval x);
    
  // -----------------------------------------------------------------------
  // I/O
  // -----------------------------------------------------------------------

  /**
   * Sets the precision of the output format. The bounds of the interval are
   * outwards to the given number of decimal digits. The default value is 3.
   */
  static int precision(int decimals);
  static int precision();

  /**
   * Prints an outwardly rounded decimal representation of interval x to the
   * given output stream.
   *
   * The implementation uses the VE edit descriptor from the runtime system 
   * of the <a href="http://www.eecs.lehigh.edu/~mschulte/compiler">
   * Interval-Enhanced GNU Fortan compiler</a>.
   *
   * In the extended system the supersetecial intervals [ EMPTY], [ ENTIRE ],
   * [ -INF ] and [ +INF ] are considered. 
   *
   * @see #precision
   */
  friend std::ostream &operator <<(std::ostream &os, INTV_ARG x);

  /**
   * Reads an interval in decimal representation from the given input stream. 
   * The input can take one of the following forms:
   * <UL>
   * <LI> "[x, y]"
   * <LI> "[x]"
   * <LI> "x"
   * </UL>
   * The resulting interval is guaranteed to contain the decimal 
   * representation.
   *
   * The implementation uses the runtime system of the 
   * <a href="http://www.eecs.lehigh.edu/~mschulte/compiler">
   * Interval-Enhanced GNU Fortan compiler</a>.
   *
   * Special intervals in the extended system are not yet considered.
   */
  friend std::istream &operator >>(std::istream &is, Interval &x);
  
  /**
   * Prints a binary representation of this interval to the given output 
   * stream.
   */
  void bitImage(std::ostream &os) const;
     
  // -----------------------------------------------------------------------
  // Special numbers
  // -----------------------------------------------------------------------
#ifdef FILIB_EXTENDED
  /**
   * Returns the empty interval. Only supported in the extended system.
   */
  static Interval EMPTY();
     
  /**
   * Returns the entire interval: [ ENTIRE ] = [ -INF, +INF ]. Only 
   * supported in the extended system.
   */
  static Interval ENTIRE();
  
  /**
   * Returns the interval [ -INF ]. Only supported in the extended system.
   */
  static Interval NEG_INFTY();
   
  /**
   * Returns the interval [ +INF ]. Only supported in the extended system.
   */
  static Interval POS_INFTY();

#endif
  /**
   * Returns the interval [0, 0]. 
   */
  static Interval ZERO();

  /**
   * Returns the interval [1, 1]. 
   */
  static Interval ONE();

  /**
   * Returns an interval enclosing pi. 
   */
  static Interval PI();

private:
   // supersetecial constants
#ifdef FILIB_EXTENDED
  static Interval empty;
  static Interval entire;
  static Interval ninf;
  static Interval pinf;
#endif
  static Interval zero;
  static Interval one;
  static Interval pi;
  static Interval e;


  // number of decimals for output
  static int dec; 

};

#ifdef FILIB_NAMESPACES
}
#endif


// include inline code if supersetecified in config.h

#if defined(FILIB_INLINE_ALL)
#include "Interval.icc"
#include "IntvAri.icc"
#elif defined(FILIB_INLINE_ARITH)
#include "IntvAri.icc"
#endif


#endif
    
    

   
