/*********************************************************************/
/*                                                                   */
/*   fi_lib  --- A fast interval library (Version 1.1)               */
/*                                                                   */
/*  Authors:                                                         */
/*  --------                                                         */
/*  Werner Hofschuster, Walter Kraemer                               */
/*  Institut fuer Wissenschaftliches Rechnen                         */
/*           und  Mathematische Modellbildung (IWRMM)    and         */
/*  Institut fuer Angewandte Mathematik                              */
/*  Universitaet Karlsruhe (TH)                                      */
/*                                                                   */
/*  Disclaimer:                                                      */
/*  -----------                                                      */
/*  This Library is distributed in the hope that it will be useful,  */
/*  but WITHOUT ANY WARRANTY; without even the implied warranty of   */
/*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.             */
/*  Neither the Institut fuer Angewandte Mathematik nor any other    */
/*  facility are responsible for this software. This software does   */
/*  not grant for anything and you can't make the autors responsible */
/*  for any possible damages or errors!                              */
/*                                                                   */
/*  Copyright:                                                       */
/*  ----------                                                       */
/*  This package is proprietary of the authors. It may be freely     */
/*  distributed but must not be changed or used for commercial       */
/*  purposes without permission of the authors.                      */
/*                                                                   */
/*********************************************************************/

#ifndef _FILIB_GLOBAL_H
#define _FILIB_GLOBAL_H

# include "config.h"

#ifdef FILIB_STD_HEADERS
  #include <cmath>
#else
  #include <math.h>
#endif


#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif  

/*********************************************************************/
/* replacement for function ldexp form math.h (libm.a)               */
/*********************************************************************/

#define POWER2(x,k) {if (x!=0) {a_diee *test=(a_diee *) &x; test->ieee.expo+=k;}}               /* only for normalised numbers ! */

/*********************************************************************/
/* replacement for function frexp form math.h (libm.a)               */
/*********************************************************************/

#define FREXPO(x,k) {if (x!=0) {a_diee *test=(a_diee *) &x; k=test->ieee.expo;} else k=0;}                          /* only for normalised numbers ! */
 
/*********************************************************************/
/* first 24 bits of a double value ( cut / round )                   */
/*********************************************************************/

#define CUT24(x) (float)(x)

/*********************************************************************/
/* assignment double -> long int                                     */
/*********************************************************************/

#define CUTINT(x) (long int)(x)

/*********************************************************************/
/* data type union to access sign, mantisse, exponent                */
/*********************************************************************/

union a_diee 
{
  double f;
#ifdef IS_64_BIT
  long l;
#endif
  struct 
  {
#if (FILIB_BYTE_ORDER == FILIB_LITTLE_ENDIAN)
    unsigned int mant1 :32;
    unsigned int mant0 :20;
    unsigned int expo  :11;
    unsigned int sign  : 1;
#else
    unsigned int sign  : 1;
    unsigned int expo  :11;
    unsigned int mant0 :20;
    unsigned int mant1 :32;
#endif
  } ieee;
};
  
/*********************************************************************/
/* error handling                                                    */
/*********************************************************************/

#define INV_ARG 1            /* for error handling: invalid argument */
#define OVER_FLOW 2          /* for error handling: overflow         */
#define DIV_ZERO 3           /* for error handling: division by zero */

/*********************************************************************/
/* constants for the elementary functions                            */
/*********************************************************************/

extern double q_ln2h;
extern double q_l10i;
extern double q_l2i;
extern double q_l10;
extern double q_l2;
extern double q_p2h;
extern double q_p2mh;
extern double q_mine;
extern double q_minr;
extern double q_pi;
extern double q_piha;
extern double q_pih[7];
extern double q_pi2i;
extern double q_pi2p[3];
extern double q_pi2d;
extern double q_pi2u;
extern double q_sqra;
extern double q_ctht;

extern double q_ext1;
extern double q_ext2;
extern double q_ex2a;
extern double q_ex2b;
extern double q_ex2c;
extern double q_ext3;
extern double q_ext4;
extern double q_ext5;
extern double q_extm;
extern double q_extn;
extern double q_exil;
extern double q_exl1;
extern double q_exl2;
extern double q_e10i;
extern double q_e1l1;
extern double q_e1l2;
extern double q_exa[5];
extern double q_exb[9];
extern double q_exc[7];
extern double q_exd[7];
extern double q_exld[32];
extern double q_extl[32];

extern double q_exem;
extern double q_exep;
extern double q_exmm;
extern double q_exmp;

extern double q_snhm;
extern double q_snhp;
extern double q_cshm;
extern double q_cshp;
extern double q_cthm;
extern double q_cthp;
extern double q_tnhm;
extern double q_tnhp;

extern double q_lgt1;
extern double q_lgt2;
extern double q_lgt3;
extern double q_lgt4;
extern double q_lgt5;
extern double q_lgt6;
extern double q_lgb[2];
extern double q_lgc[4];
extern double q_lgld[129];
extern double q_lgtl[129];

extern double q_logm;
extern double q_logp;
extern double q_lgpm;
extern double q_lgpp;
extern double q_sqtm;
extern double q_sqtp;

extern double q_atna[7];
extern double q_atnb[8];
extern double q_atnc[7];
extern double q_atnd[6];
extern double q_atnt;

extern double q_asnm;
extern double q_asnp;
extern double q_acsm;
extern double q_acsp;
extern double q_actm;
extern double q_actp;
extern double q_atnm;
extern double q_atnp;

extern double q_csnm;
extern double q_csnp;
extern double q_ccsm;
extern double q_ccsp;
extern double q_cctm;
extern double q_cctp;
extern double q_ctnm;
extern double q_ctnp;

extern double q_sinc[6];
extern double q_sins[6];
extern double q_sint[5];

extern double q_sinm;
extern double q_sinp;
extern double q_cosm;
extern double q_cosp;
extern double q_cotm;
extern double q_cotp;
extern double q_tanm;
extern double q_tanp;

extern double q_lg2m;
extern double q_lg2p;
extern double q_l10m;
extern double q_l10p;
extern double q_e2em;
extern double q_e2ep;
extern double q_e10m;
extern double q_e10p;

extern double q_at3i;

/*********************************************************************/
/* functions for internal use only                                   */
/*********************************************************************/

class Interval;

// error handling for non-extended mode 
double q_abortr1(int n, const double *x, int fctn);
Interval q_abortr2(int n, const double *x1, const double *x2, int fctn);
double q_abortnan(int n, const double *x, int fctn);
double q_abortdivd(int n, const double *x);
Interval q_abortdivi(int n, const double *x1, const double *x2);

Interval errorIntersect(Interval x, Interval y);
  

double q_ep1(double x);
double q_epm1(double x);
double q_cth1(double x);
double q_log1(double x);
double q_l1p1(double x);
double q_atn1(double x);
double q_sin1(double x, long int k);
double q_cos1(double x, long int k);
double q_rtrg(double x, long int k);
double q_r2tr(double r, long int k);

/*********************************************************************/
/*               prototypes for library functions                    */
/*********************************************************************/

double q_sqr(double x);
double q_sqrt(double x);
double q_exp(double x);
double q_expm(double x);
double q_sinh(double x);
double q_cosh(double x);
double q_coth(double x);
double q_tanh(double x);
double q_log(double x);
double q_lg1p(double x);
double q_asnh(double x);
double q_acsh(double x);
double q_acth(double x);
double q_atnh(double x);
double q_asin(double x);
double q_acos(double x);
double q_acot(double x);
double q_atan(double x);
double q_sin(double x);
double q_cos(double x);
double q_cot(double x);
double q_tan(double x);
double q_exp2(double x);
double q_ex10(double x);
double q_log2(double x);
double q_lg10(double x);
double q_comp(int s, double m, int e);
double q_cmps(double m, int e);
int q_sign(double x);
double q_mant(double x);
double q_mnts(double x);
int q_expo(double x);

#ifdef FILIB_NAMESPACES
}
#endif

#endif
