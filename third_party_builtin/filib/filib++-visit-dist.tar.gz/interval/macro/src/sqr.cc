/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval sqr(Interval x)
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty()) 
    return Interval::EMPTY();
#endif

  Interval res;
  
  if (x.isPoint()) {
    if (x.INF==0)
      res.INF=res.SUP=0;
    else
#ifndef FILIB_EXTENDED
      if (Double::isNaN(x.INF))
	res = q_abortnan(INV_ARG,&x.INF,1);
      else if ((x.INF<-q_sqra)||(x.INF>q_sqra))
	res = q_abortr1(OVER_FLOW,&x.INF,1);
      else 
#endif

#ifdef FILIB_NATIVE_ROUNDING
	{
	  MUL_DOWN(res.INF, x.INF, x.INF);
	  MUL_UP(res.SUP, x.INF, x.INF);
	  POSS_ROUND_NEAR;
	}
      
#else
	{
	  res.INF=x.INF * x.INF; 
	  res.SUP=r_succ(res.INF);
	  res.INF=r_pred(res.INF);
#ifdef FILIB_EXTENDED
	  res.checkInf();
#endif	  
	}
#endif
    
  }

  else
    {
#ifndef FILIB_EXTENDED
      if (Double::isNaN(x.INF) || Double::isNaN(x.SUP))
	res = q_abortnan(INV_ARG,&x.INF,1);
#endif
      {
	
#ifndef FILIB_EXTENDED
	if ((x.INF<-q_sqra)||(x.SUP>q_sqra))
	  res = q_abortr1(OVER_FLOW,&x.INF,1);
	else 
#endif

#ifdef FILIB_NATIVE_ROUNDING
	  {
	    if (x.INF==0) { 
	      res.INF=0; 
	      MUL_UP(res.SUP, x.SUP, x.SUP); 
	    }
	    else if (x.INF>0) {
	      MUL_DOWN(res.INF, x.INF, x.INF); 
	      MUL_UP(res.SUP, x.SUP, x.SUP); 
	    }
	    else if (x.SUP==0) { 
	      res.INF=0; 
	      MUL_UP(res.SUP, x.INF, x.INF); 
	    }
	    else if (x.SUP<0) { 
	      MUL_DOWN(res.INF, x.SUP, x.SUP); 
	      MUL_UP(res.SUP, x.INF, x.INF); 
	    }
	    else { 
	      res.INF=0;
	      if (-x.INF>x.SUP) 
		MUL_UP(res.SUP, x.INF, x.INF)
	      else              
		MUL_UP(res.SUP, x.SUP, x.SUP)          
	    }
	    
	    POSS_ROUND_NEAR;
	  }
	
#else
	    if (x.INF==0) { 
	      res.INF=0; res.SUP=r_succ(x.SUP*x.SUP); 
	    }
	    else if (x.INF>0) {
	      res.INF=r_pred(x.INF*x.INF); res.SUP=r_succ(x.SUP*x.SUP); 
	    }
	    else if (x.SUP==0) { 
	      res.INF=0; res.SUP=r_succ(x.INF*x.INF); 
	    }
	    else if (x.SUP<0) { 
	      res.INF=r_pred(x.SUP*x.SUP); res.SUP=r_succ(x.INF*x.INF); 
	    }
	    else { 
	      res.INF=0;
	      if (-x.INF>x.SUP) 
		res.SUP=r_succ(x.INF*x.INF);
	      else              
		res.SUP=r_succ(x.SUP*x.SUP);          
	    }
#ifdef FILIB_EXTENDED
	    res.checkInf();
#endif
	    
#endif
	} 
      
    }   
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif








