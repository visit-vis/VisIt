/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval log1p(Interval x)
{
#ifdef FILIB_EXTENDED
  static Interval LOG1P_DOMAIN(-1, Double::POS_INFTY());
  x = intersect(x, LOG1P_DOMAIN);
  if (x.isEmpty())
    return Interval::EMPTY();
#endif
  
  Interval res;
  if (isPoint(x)) { 
    res.INF=q_lg1p(x.INF);

#ifdef FILIB_EXTENDED
    if (Double::isNaN(res.INF))
      res = Interval::NEG_INFTY();
    else
#endif
      {
	if (res.INF>=0) {
	  res.SUP=res.INF*q_lgpp;
	  res.INF*=q_lgpm;
	}
	else {
	  res.SUP=res.INF*q_lgpm;
	  res.INF*=q_lgpp;
	}
      }
  }

  else {
    res.INF=q_lg1p(x.INF);
    if (res.INF>=0)
      res.INF*=q_lgpm;
    else
      res.INF*=q_lgpp;
    
#ifdef FILIB_EXTENDED
    if (x.SUP == Double::POS_INFTY())
      res.SUP = Double::POS_INFTY();
    else
#endif
      
      {
	res.SUP=q_lg1p(x.SUP);
	if (res.SUP>=0)
	  res.SUP*=q_lgpp;
	else
	  res.SUP*=q_lgpm;
      }

#ifdef FILIB_EXTENDED
    if (Double::isNaN(res.INF))
      res.INF = Double::NEG_INFTY();
    if (Double::isNaN(res.SUP))
      res.SUP = Double::POS_INFTY();
#endif    
    
  }   
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
