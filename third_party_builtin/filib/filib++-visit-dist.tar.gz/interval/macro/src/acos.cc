/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval acos(Interval x)
{
#ifdef FILIB_EXTENDED
  static Interval ACOS_DOMAIN(-1, 1);
  x = intersect(x, ACOS_DOMAIN);
  if (x.isEmpty())
      return Interval::EMPTY();
#endif

  Interval res;
  if (x.isPoint())
    { 
          res.INF=q_acos(x.INF);
          res.SUP=res.INF*q_ccsp;
          res.INF*=q_ccsm;
    }
  else
    {
      res.INF=q_acos(x.SUP)*q_ccsm;
      res.SUP=q_acos(x.INF)*q_ccsp;
    }   
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif





