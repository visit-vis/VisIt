/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "ieee.h"
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

double q_cosh(double x)
{
  double res;

  if (Double::isNaN(x))
#ifdef FILIB_EXTENDED
    return Double::QUIET_NAN();
#else
    res=q_abortnan(INV_ARG,&x,19);
#endif

  else 
  {
    if ((x>=-q_ex2c)&&(x<=q_ex2c))
      res=0.5*(q_ep1(x)+q_ep1(-x));
    else if ((x>=-q_ex2a)&&(x<=q_ex2a))
      res=(0.5*q_exp(x))+(0.5*q_exp(-x));
    else 
#ifdef FILIB_EXTENDED
      res = Double::POS_INFTY();
#else    
      res=q_abortr1(OVER_FLOW,&x,19);                 /* Overflow */
#endif
  }

  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
