/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "ieee.h"
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

double q_log2(double x)
{
  double res;

if (Double::isNaN(x))
#ifdef FILIB_EXTENDED
  return Double::QUIET_NAN();
#else 
   res=q_abortnan(INV_ARG,&x,8);
#endif

else
  res=q_log(x)*q_l2i;
 
 return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
