/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval atanh(Interval x)
{
  Interval res;

#ifdef FILIB_EXTENDED
  static Interval ATNH_DOMAIN(-1.0, 1.0);
  x = intersect(x, ATNH_DOMAIN);
  if (x.isEmpty())
    return Interval::EMPTY();
#else
  if (x.INF <= -1 || x.SUP >= 1)
    res=q_abortr2(INV_ARG,&x.INF,&x.SUP,24);  /* invalid argument */
#endif
  
  else {
    if (x.isPoint()) { 
      if (x.INF<0) {
	if (x.INF>-q_minr) {
	  res.INF=r_pred(x.INF);
	  res.SUP=x.INF;
	}
	else {
	  res.INF=q_atnh(x.INF);

#ifdef FILIB_EXTENDED
	  if (Double::isNaN(res.INF))
	    res = Interval::NEG_INFTY();
	  else
#endif
	    {
	      res.SUP=res.INF*q_atnm;
	      res.INF*=q_atnp;
	      if (res.SUP>x.INF) res.SUP=x.INF;
	    } 
	}
      }
      else {
	if (x.INF<q_minr) {         
	  res.INF=x.INF;
	  if (x.INF==0)
	    res.SUP=0; 
	  else
	    res.SUP=r_succ(x.INF);
	}
	else {
	  res.INF=q_atnh(x.INF);
	  
#ifdef FILIB_EXTENDED
	  if (Double::isNaN(res.INF))
	    res = Interval::POS_INFTY();
	  else 
#endif
	    {
	      res.SUP=res.INF*q_atnp;
	      res.INF*=q_atnm;
	      if (res.INF<x.INF) res.INF=x.INF;
	    }
	  
	}
      }
    }
    
    else {
      if (x.INF<0) {
	if (x.INF>-q_minr)
	  res.INF=r_pred(x.INF); 
	else 
	  res.INF=q_atnh(x.INF)*q_atnp;         
      }
      else  /* x.INF>=0 */ {
	if (x.INF<q_minr)
	  res.INF=x.INF;         /* includes the case x.INF=0 */     
	else {  
	  res.INF=q_atnh(x.INF)*q_atnm;
	  if (res.INF<x.INF) 
	    res.INF=x.INF;
	}
      }
      if (x.SUP<=0) {
	if (x.SUP>-q_minr)
	  res.SUP=x.SUP;        /* includes the case x.SUP=0 */
	else {
	  res.SUP=q_atnh(x.SUP)*q_atnm;
	  if (res.SUP>x.SUP) 
	    res.SUP=x.SUP;
	}          
      }
      else  /* x.SUP>0 */ {
	if (x.SUP<q_minr)
	  res.SUP=r_succ(x.SUP);        
	else 
	  res.SUP=q_atnh(x.SUP)*q_atnp;
      }

#ifdef FILIB_EXTENDED
      if (Double::isNaN(res.INF))
	res.INF = Double::NEG_INFTY();
      if (Double::isNaN(res.SUP))
	res.SUP = Double::POS_INFTY();
#endif
    
    }
    
    
  }

  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif









