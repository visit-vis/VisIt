/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "ieee.h"
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

double q_asin(double x)
{
  double res;

    // check argument
  if (Double::isNaN(x))
#ifdef FILIB_EXTENDED
    return Double::QUIET_NAN();
#else  
  res=q_abortnan(INV_ARG,&x,15);
#endif

  else
  {
    if ((x<-1.0)||(1.0<x))
#ifdef FILIB_EXTENDED
      return Double::QUIET_NAN();
#else
      res=q_abortr1(INV_ARG,&x,15);
#endif

    else 
    {
      // main program with diffent cases 
      if (x==-1) res=-q_piha;
      else if (x==1) res=q_piha;
      else if ((-q_atnt<=x)&&(x<=q_atnt)) res=x;
      else res=q_atn1(x/sqrt((1.0+x)*(1.0-x))); 
    }
  }
 
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
