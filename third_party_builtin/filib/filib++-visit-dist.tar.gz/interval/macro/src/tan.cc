/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval tan(Interval x)
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty())
    return Interval::EMPTY();
#endif

  Interval res;
  double h1,h2;
  long int k1,k2,q1;


  if ((x.INF<-q_sint[2])||(x.SUP>q_sint[2]))
#ifdef FILIB_EXTENDED
    res = Interval::ENTIRE();
 #else  
    res=q_abortr2(INV_ARG,&x.INF,&x.SUP,12);  /* abs. argument too big */
#endif
  else
    {
      if (x.isPoint())
	{ 
	  if ((x.INF>=-q_sint[4])&&(x.INF<0))
	    {
	      res.INF=r_pred(x.INF);
	      res.SUP=x.INF;
	    }
	  else if ((x.INF>=0)&&(x.INF<=q_sint[4]))
	    {         
	      res.INF=x.INF;
	      if (x.INF==0)
		res.SUP=0; 
	      else
		res.SUP=r_succ(x.INF);
	    }
	  else
	    {
	      res.INF=q_tan(x.INF);
	      if (res.INF<0)
		{
		  res.SUP=res.INF*q_tanm;
		  res.INF*=q_tanp;
		}
	      else
		{
		  res.SUP=res.INF*q_tanp;
		  res.INF*=q_tanm;
		}
	    }
	}
      else                                      /* x is not a point interval */
	{
          if (x.SUP<0) 
	    {
              h1=x.INF*q_pi2u;
              h2=x.SUP*q_pi2d;
            }
          else
            {
              h1=x.INF*q_pi2d;
	      h2=x.SUP*q_pi2u;
	    }

	  k1=CUTINT(h1);
	  if (k1<0) q1=(k1-1)%2; else q1=k1%2; if (q1<0) q1+=2;

	  k2=CUTINT(h2); 

	  if ((k1==k2) || (q1==1)&(k1==k2-1))
	    {
	      if ((-q_sint[4]<x.INF)&&(x.INF<0))
		res.INF=r_pred(x.INF);
	      else if ((0<=x.INF)&&(x.INF<q_sint[4]))
		res.INF=x.INF;
	      else
		{ 
		  res.INF=q_tan(x.INF);
		  if (res.INF>=0)
		    res.INF*=q_tanm;
		  else
		    res.INF*=q_tanp;
		}

	      if ((-q_sint[4]<x.SUP)&&(x.SUP<=0))
		res.SUP=x.SUP;
	      else if ((0<x.SUP)&&(x.SUP<q_sint[4]))
		res.SUP=r_succ(x.SUP);
	      else
		{ 
		  res.SUP=q_tan(x.SUP);
		  if (res.SUP>=0)
		    res.SUP*=q_tanp;
		  else
		    res.SUP*=q_tanm;
		}
	    }
	  else                                           /* invalid argument */
	    {
#ifdef FILIB_EXTENDED
	      res = Interval::ENTIRE();
#else
	      res=q_abortr2(INV_ARG,&x.INF,&x.SUP,12);
#endif
	    }
	}   
    }
  
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
