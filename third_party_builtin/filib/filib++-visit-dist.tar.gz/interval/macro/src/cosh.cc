/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval cosh(Interval x)
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty()) 
    return Interval::EMPTY();
#endif
  
  Interval res;
  if (x.SUP<0)
    {
      if (x.isPoint())
	{ 
	  res.INF=q_cosh(x.INF);
	  res.SUP=res.INF*q_cshp;
	  res.INF*=q_cshm;
	}
      else
	{
	  res.INF=q_cosh(x.SUP)*q_cshm;
	  res.SUP=q_cosh(x.INF)*q_cshp;
    }
      if (res.INF<1.0) res.INF=1.0;
    }    /* end  if (x.SUP<0) */
  else if (x.INF>0)
    {
      if (x.isPoint())
	{ 
	  res.INF=q_cosh(x.INF);
	  res.SUP=res.INF*q_cshp;
	  res.INF*=q_cshm;
	}
      else
	{
	  res.INF=q_cosh(x.INF)*q_cshm;
	  res.SUP=q_cosh(x.SUP)*q_cshp;
	}  
      if (res.INF<1.0) res.INF=1.0;
    }
  else if (-x.INF>x.SUP)
    {
      res.INF=1.0;
      res.SUP=q_cosh(x.INF)*q_cshp;
    }
  else
    {
      res.INF=1.0;
      res.SUP=q_cosh(x.SUP)*q_cshp;
    }
  
#ifdef FILIB_EXTENDED
  if (res.INF == Double::POS_INFTY())
    res.INF = Double::MAX();
#endif
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
