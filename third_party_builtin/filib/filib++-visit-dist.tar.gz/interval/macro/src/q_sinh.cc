/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "ieee.h"
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

double q_sinh(double x)
{
  double absx, h;
  int sgn;
  double res;

  if (Double::isNaN(x))
#ifdef FILIB_EXTENDED
    return Double::QUIET_NAN();
#else
    res=q_abortnan(INV_ARG,&x,18);
#endif

  else 
  {
    if (x<0) {sgn=-1; absx=-x;}
    else     {sgn=1;  absx=x; }
 
    if (absx>q_ex2a)
#ifdef FILIB_EXTENDED
      return sgn*Double::POS_INFTY();
#else
      res=q_abortr1(OVER_FLOW,&x,18);                 /* Overflow */
#endif
      if (absx<2.5783798e-8) res=x;
      else if (absx>=0.662) 
	{
	  h=q_ep1(absx);
	  res=sgn*0.5*(h-1.0/h);
	}
      else
	{
	  h=q_epm1(absx);
	  res=sgn*0.5*(h+h/(h+1.0));
	}
      
  }
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
