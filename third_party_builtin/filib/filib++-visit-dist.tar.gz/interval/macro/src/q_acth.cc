/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "ieee.h"
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

double q_acth(double x)
{
  double absx, res;
  int sgn;
 
  if (Double::isNaN(x))
#ifdef FILIB_EXTENDED
    return Double::QUIET_NAN();
#else
    res=q_abortnan(INV_ARG,&x,25);
#endif

  else {
    if (x<0) {
      sgn = -1;
      absx=-x;
    } else {
      sgn = 1;
      absx=x;  
    }
  
    if (absx<=1.0) 
#ifdef FILIB_EXTENDED
      return Double::QUIET_NAN();
#else
      res=q_abortr1(INV_ARG,&x,25);
#endif

    res=0.5*q_l1p1(2.0/(absx-1.0));
  }

  return(sgn*res);
}

#ifdef FILIB_NAMESPACES
}
#endif
