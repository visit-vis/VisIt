/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "ieee.h"
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

double q_acsh(double x)
{
  double res;

    // check argument

  if (Double::isNaN(x))
#ifdef FILIB_EXTENDED
    return Double::QUIET_NAN();
#else
    res=q_abortnan(INV_ARG,&x,15);
#endif

  else
  {
    if (x < 1.0)
#ifdef FILIB_EXTENDED
      return Double::QUIET_NAN();
#else
      res=q_abortr1(INV_ARG,&x,23);
#endif
 
    if (x<1.025) res=q_l1p1(x-1+sqrt((x-1)*(x+1)));
    else if (x>1e150) res=q_l2+q_log1(x);
    else         res=q_log1(x+sqrt((x-1)*(x+1)));
  }
  
  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
