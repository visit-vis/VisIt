/*********************************************************************/
/*       fi_lib  --- A fast interval library (Version 1.1)           */
/*        (For copyright and info`s see file "fi_lib.h")             */
/*********************************************************************/

#include "Interval.h" 
#include "global.h"

#ifdef FILIB_NAMESPACES
namespace filib 
{
#endif

Interval cot(Interval x)
{
#ifdef FILIB_EXTENDED
  if (x.isEmpty())
    return Interval::EMPTY();
#endif

  Interval res;
  double h1,h2;
  long int k1,k2,q1;


  if ((x.INF<-q_sint[2])||(x.SUP>q_sint[2]))
#ifdef FILIB_EXTENDED
    res = Interval::ENTIRE();
 #else  
    res=q_abortr2(INV_ARG,&x.INF,&x.SUP,13);  /* abs. argument too big */
#endif

  else
  if (x.isPoint())
    { 

#ifdef FILIB_EXTENDED
      if (x.INF == 0.0)
	return Interval::ENTIRE();
#endif

      res.INF=q_cot(x.INF);

#ifdef FILIB_EXTENDED
      // this may still be the case for |x| < q_minr !
      if (Double::isNaN(res.INF))
	  if (x.INF < 0.0)
	      return Interval::NEG_INFTY();
	  else
	      return Interval::POS_INFTY();
#endif 
     
      if (res.INF<0)
        {
          res.SUP=res.INF*q_cotm;
          res.INF*=q_cotp;
        }
      else
        {
          res.SUP=res.INF*q_cotp;
          res.INF*=q_cotm;
        }
    }
  else if (((x.INF<=0)&(x.SUP>=0))||((x.SUP<0)&(x.SUP>-q_minr))
                          ||((x.INF>0)&&(x.INF<q_minr)))
#ifdef FILIB_EXTENDED
    res = Interval::ENTIRE();
#else
    res=q_abortr2(INV_ARG,&x.INF,&x.SUP,13);  /* Singularitaet */
#endif
  else
    {
      if (x.SUP<0) 
        {
           h1=x.INF*q_pi2u;
           h2=x.SUP*q_pi2d;
        }
      else
        {
           h1=x.INF*q_pi2d;
           h2=x.SUP*q_pi2u;
        }

      k1=CUTINT(h1);
      if (k1<0) q1=(k1-1)%2; else q1=k1%2; if (q1<0) q1+=2;

      k2=CUTINT(h2); 

      if ((k1==k2) || ((q1==0)&&(k1==k2-1)))
       {
         res.INF=q_cot(x.SUP);
         if (res.INF>=0)
           res.INF*=q_cotm;
         else
           res.INF*=q_cotp;
         res.SUP=q_cot(x.INF);
         if (res.SUP>=0)
           res.SUP*=q_cotp;
         else
           res.SUP*=q_cotm;
        }
       else                                          /* invalid argument */
        {
#ifdef FILIB_EXTENDED
	  res = Interval::ENTIRE();
#else
          res=q_abortr2(INV_ARG,&x.INF,&x.SUP,13);
#endif
        }
   }   

  return(res);
}

#ifdef FILIB_NAMESPACES
}
#endif
