/*                                                                           
**  fi_lib++  --- A fast interval library (Version 2.0)                     
**                                                                  
**  Copyright (C) 2001:                                                        
**                                                     
**  Werner Hofschuster, Walter Kraemer                               
**  Wissenschaftliches Rechnen/Softwaretechnologie (WRSWT)  
**  Universitaet Wuppertal, Germany                                           
**  Michael Lerch, German Tischler, Juergen Wolff von Gudenberg       
**  Institut fuer Informatik                                         
**  Universitaet Wuerzburg, Germany                                           
** 
**  This library is free software; you can redistribute it and/or
**  modify it under the terms of the GNU Library General Public
**  License as published by the Free Software Foundation; either
**  version 2 of the License, or (at your option) any later version.
**
**  This library is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
**  Library General Public License for more details.
**
**  You should have received a copy of the GNU Library General Public
**  License along with this library; if not, write to the Free
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
*/
#include <ieee/primitive.hpp>
#include <cmath>
#include <fp_traits/fp_traits.hpp>

//
// Mark C. Miller, Mon Dec 11 15:35:04 PST 2006
// Commented out template<> lines, causing problems with icc compiler
//

//template<>
int filib::fp_traits<double,filib::native_switched>::precision_val = 3;
//template<>
int filib::fp_traits<double,filib::native_directed>::precision_val = 3;
//template<>
int filib::fp_traits<double,filib::multiplicative>::precision_val = 3;
//template<>
int filib::fp_traits<double,filib::no_rounding>::precision_val = 3;
//template<>
int filib::fp_traits<double,filib::native_onesided_switched>::precision_val = 3;
//template<>
int filib::fp_traits<double,filib::native_onesided_global>::precision_val = 3;
//template<>
int filib::fp_traits<double,filib::pred_succ_rounding>::precision_val = 3;
